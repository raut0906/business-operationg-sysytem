"use client";

import { create } from "zustand";

interface AppState {
  token: string | null;
  selectedOrgId: string | null;
  selectedWorkspaceId: string | null;
  setToken: (token: string | null) => void;
  setSelectedOrgId: (id: string | null) => void;
  setSelectedWorkspaceId: (id: string | null) => void;
}

export const useAppStore = create<AppState>((set) => ({
  token: null,
  selectedOrgId: null,
  selectedWorkspaceId: null,
  setToken: (token) => {
    if (typeof window !== "undefined") {
      if (token) window.localStorage.setItem("access_token", token);
      else window.localStorage.removeItem("access_token");
    }
    set({ token });
  },
  setSelectedOrgId: (id) => set({ selectedOrgId: id, selectedWorkspaceId: null }),
  setSelectedWorkspaceId: (id) => set({ selectedWorkspaceId: id }),
}));
