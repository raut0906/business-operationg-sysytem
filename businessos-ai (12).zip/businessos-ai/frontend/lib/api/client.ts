/**
 * Thin typed fetch wrapper around the FastAPI backend.
 *
 * Kept as one file for the whole app; split by domain (auth.ts, workspaces.ts...)
 * once this file exceeds ~300 lines.
 */
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem("access_token");
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string>),
  };
  if (!(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE_URL}${path}`, { ...options, headers });
  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(errorBody.detail || `Request failed with status ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export interface TokenPair {
  access_token: string;
  refresh_token: string;
  token_type: string;
}

export interface Organization {
  id: string;
  name: string;
  slug: string;
  plan: string;
}

export interface Workspace {
  id: string;
  org_id: string;
  name: string;
  slug: string;
}

export interface Dataset {
  id: string;
  workspace_id: string;
  name: string;
  warehouse_table_name: string;
  source_type: string;
  row_count: number;
}

export interface Dashboard {
  id: string;
  workspace_id: string;
  name: string;
  created_by: string;
}

export interface Widget {
  id: string;
  dashboard_id: string;
  dataset_id: string;
  chart_type: string;
  title: string;
  dimension: string | null;
  metric: string | null;
  aggregate: string;
  metric_id?: string | null;
  dimension_id?: string | null;
}

export interface WidgetData {
  widget_id: string;
  chart_type: string;
  title: string;
  data: Array<{ dimension: string; value: number }>;
}

export interface PipelineNode {
  id: string;
  type: "source" | "filter" | "select_columns" | "rename" | "derive" | "aggregate" | "sort" | "dedupe" | "clean" | "join" | "append" | "pivot" | "unpivot" | "normalize";
  config: Record<string, unknown>;
}

export interface Pipeline {
  id: string;
  workspace_id: string;
  name: string;
  nodes: PipelineNode[];
  schedule_cron: string | null;
  is_active: boolean;
  last_run_at: string | null;
}

export interface NodeLog {
  node_id: string;
  node_type: string;
  status: string;
  message: string;
  rows_before: number | null;
  rows_after: number | null;
  duration_ms: number | null;
}

export interface PipelineRun {
  id: string;
  pipeline_id: string;
  status: string;
  started_at: string | null;
  finished_at: string | null;
  rows_processed: number | null;
  output_dataset_id: string | null;
  error_message: string | null;
  logs: NodeLog[];
}

export interface CopilotAskResponse {
  question: string;
  generated_sql: string;
  explanation: string;
  columns: string[];
  rows: Record<string, unknown>[];
}

export interface CopilotSummaryResponse {
  dataset_id: string;
  summary: string;
}

export interface CopilotChartSuggestion {
  chart_type: string;
  dimension: string;
  metric: string;
  aggregate: string;
  reasoning: string;
}

export interface ForecastPoint {
  period: string;
  value: number;
  lower_bound: number | null;
  upper_bound: number | null;
}

export interface ForecastResponse {
  method: string;
  history: ForecastPoint[];
  forecast: ForecastPoint[];
  warning: string | null;
}

export interface ModelCandidate {
  algorithm: string;
  metrics: Record<string, unknown>;
}

export interface MLModel {
  id: string;
  workspace_id: string;
  dataset_id: string;
  name: string;
  model_type: "regression" | "classification" | "clustering";
  algorithm: string;
  target_column: string | null;
  feature_columns: string[];
  metrics: Record<string, unknown>;
  feature_importance: Record<string, number>;
  candidates: ModelCandidate[];
  status: string;
  error_message: string | null;
}

export interface Supplier {
  id: string;
  workspace_id: string;
  name: string;
  contact_email: string | null;
  lead_time_days: number;
}

export interface Warehouse {
  id: string;
  workspace_id: string;
  name: string;
  location: string | null;
}

export interface Product {
  id: string;
  workspace_id: string;
  sku: string;
  name: string;
  category: string | null;
  unit_cost: number;
  unit_price: number;
  reorder_point: number;
  safety_stock: number;
  reorder_quantity: number | null;
  supplier_id: string | null;
}

export interface OrderLine {
  product_id: string;
  quantity: number;
  unit_cost?: number | null;
  unit_price?: number | null;
}

export interface PurchaseOrder {
  id: string;
  workspace_id: string;
  supplier_id: string;
  status: string;
  lines: OrderLine[];
}

export interface SalesOrder {
  id: string;
  workspace_id: string;
  customer_name: string;
  status: string;
  lines: OrderLine[];
}

export interface StockLevel {
  product_id: string;
  warehouse_id: string;
  quantity_on_hand: number;
}

export interface InventoryValue {
  product_id: string;
  warehouse_id: string;
  quantity_on_hand: number;
  unit_cost: number;
  inventory_value: number;
}

export interface ABCAnalysisRow {
  product_id: string;
  annual_usage_value: number;
  cumulative_pct: number;
  product_class: string;
}

export interface ReorderSuggestion {
  product_id: string;
  quantity_on_hand: number;
  reorder_point: number;
  suggested_order_quantity: number;
}

export interface DatabaseConnector {
  id: string;
  workspace_id: string;
  name: string;
  dialect: "sqlite" | "postgresql" | "mysql";
  status: string;
  last_error: string | null;
  last_synced_at: string | null;
}

export interface ConnectorTableSchema {
  table_name: string;
  columns: { name: string; type: string }[];
}

export interface Metric {
  id: string;
  workspace_id: string;
  dataset_id: string;
  name: string;
  expression: string;
  format: "currency" | "number" | "percent";
  description: string | null;
}

export interface Dimension {
  id: string;
  workspace_id: string;
  dataset_id: string;
  name: string;
  column: string;
  description: string | null;
}

export interface RowLevelPolicy {
  id: string;
  workspace_id: string;
  dataset_id: string;
  max_role: number;
  filter_expression: string;
  description: string | null;
}

export interface ColumnLevelPolicy {
  id: string;
  workspace_id: string;
  dataset_id: string;
  max_role: number;
  column_name: string;
  access_type: "full" | "masked" | "hidden";
}

export interface SecuredPreview {
  columns: string[];
  rows: Record<string, unknown>[];
  row_count: number;
  policies_applied: string[];
}

export const api = {
  auth: {
    register: (email: string, password: string, full_name?: string) =>
      request("/api/v1/auth/register", { method: "POST", body: JSON.stringify({ email, password, full_name }) }),
    login: (email: string, password: string) =>
      request<TokenPair>("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),
    me: () => request("/api/v1/auth/me"),
  },
  organizations: {
    list: () => request<Organization[]>("/api/v1/organizations"),
    create: (name: string) =>
      request<Organization>("/api/v1/organizations", { method: "POST", body: JSON.stringify({ name }) }),
  },
  workspaces: {
    list: (orgId: string) => request<Workspace[]>(`/api/v1/organizations/${orgId}/workspaces`),
    create: (orgId: string, name: string) =>
      request<Workspace>(`/api/v1/organizations/${orgId}/workspaces`, {
        method: "POST",
        body: JSON.stringify({ name }),
      }),
  },
  datasets: {
    list: (workspaceId: string) => request<Dataset[]>(`/api/v1/workspaces/${workspaceId}/datasets`),
    upload: (workspaceId: string, name: string, file: File) => {
      const form = new FormData();
      form.append("file", file);
      return request<Dataset>(
        `/api/v1/workspaces/${workspaceId}/datasets?name=${encodeURIComponent(name)}`,
        { method: "POST", body: form }
      );
    },
    preview: (workspaceId: string, datasetId: string) =>
      request(`/api/v1/workspaces/${workspaceId}/datasets/${datasetId}/preview`),
  },
  pipelines: {
    list: (workspaceId: string) => request<Pipeline[]>(`/api/v1/workspaces/${workspaceId}/pipelines`),
    create: (workspaceId: string, name: string, nodes: PipelineNode[], scheduleCron?: string) =>
      request<Pipeline>(`/api/v1/workspaces/${workspaceId}/pipelines`, {
        method: "POST",
        body: JSON.stringify({ name, nodes, schedule_cron: scheduleCron || null }),
      }),
    update: (workspaceId: string, pipelineId: string, patch: Partial<Pipeline>) =>
      request<Pipeline>(`/api/v1/workspaces/${workspaceId}/pipelines/${pipelineId}`, {
        method: "PATCH",
        body: JSON.stringify(patch),
      }),
    delete: (workspaceId: string, pipelineId: string) =>
      request<void>(`/api/v1/workspaces/${workspaceId}/pipelines/${pipelineId}`, { method: "DELETE" }),
    run: (workspaceId: string, pipelineId: string, outputDatasetName: string) =>
      request<PipelineRun>(`/api/v1/workspaces/${workspaceId}/pipelines/${pipelineId}/run`, {
        method: "POST",
        body: JSON.stringify({ output_dataset_name: outputDatasetName }),
      }),
    listRuns: (workspaceId: string, pipelineId: string) =>
      request<PipelineRun[]>(`/api/v1/workspaces/${workspaceId}/pipelines/${pipelineId}/runs`),
  },
  copilot: {
    ask: (workspaceId: string, datasetId: string, question: string) =>
      request<CopilotAskResponse>(`/api/v1/workspaces/${workspaceId}/copilot/ask`, {
        method: "POST",
        body: JSON.stringify({ dataset_id: datasetId, question }),
      }),
    summary: (workspaceId: string, datasetId: string) =>
      request<CopilotSummaryResponse>(`/api/v1/workspaces/${workspaceId}/copilot/summary/${datasetId}`),
    chartSuggestion: (workspaceId: string, datasetId: string) =>
      request<CopilotChartSuggestion>(`/api/v1/workspaces/${workspaceId}/copilot/chart-suggestion/${datasetId}`),
  },
  security: {
    listRowPolicies: (workspaceId: string) =>
      request<RowLevelPolicy[]>(`/api/v1/workspaces/${workspaceId}/security/row-policies`),
    createRowPolicy: (workspaceId: string, datasetId: string, maxRole: number, filterExpression: string, description?: string) =>
      request<RowLevelPolicy>(`/api/v1/workspaces/${workspaceId}/security/row-policies`, {
        method: "POST",
        body: JSON.stringify({ dataset_id: datasetId, max_role: maxRole, filter_expression: filterExpression, description }),
      }),
    deleteRowPolicy: (workspaceId: string, policyId: string) =>
      request<void>(`/api/v1/workspaces/${workspaceId}/security/row-policies/${policyId}`, { method: "DELETE" }),
    listColumnPolicies: (workspaceId: string) =>
      request<ColumnLevelPolicy[]>(`/api/v1/workspaces/${workspaceId}/security/column-policies`),
    createColumnPolicy: (
      workspaceId: string,
      datasetId: string,
      maxRole: number,
      columnName: string,
      accessType: "full" | "masked" | "hidden"
    ) =>
      request<ColumnLevelPolicy>(`/api/v1/workspaces/${workspaceId}/security/column-policies`, {
        method: "POST",
        body: JSON.stringify({ dataset_id: datasetId, max_role: maxRole, column_name: columnName, access_type: accessType }),
      }),
    deleteColumnPolicy: (workspaceId: string, policyId: string) =>
      request<void>(`/api/v1/workspaces/${workspaceId}/security/column-policies/${policyId}`, { method: "DELETE" }),
    securedPreview: (workspaceId: string, datasetId: string) =>
      request<SecuredPreview>(`/api/v1/workspaces/${workspaceId}/security/datasets/${datasetId}/secured-preview`),
  },
  semantic: {
    listMetrics: (workspaceId: string) => request<Metric[]>(`/api/v1/workspaces/${workspaceId}/semantic/metrics`),
    createMetric: (
      workspaceId: string,
      datasetId: string,
      name: string,
      expression: string,
      format: "currency" | "number" | "percent",
      description?: string
    ) =>
      request<Metric>(`/api/v1/workspaces/${workspaceId}/semantic/metrics`, {
        method: "POST",
        body: JSON.stringify({ dataset_id: datasetId, name, expression, format, description }),
      }),
    evaluateMetric: (workspaceId: string, metricId: string) =>
      request<{ metric_id: string; name: string; value: number; format: string }>(
        `/api/v1/workspaces/${workspaceId}/semantic/metrics/${metricId}/evaluate`
      ),
    deleteMetric: (workspaceId: string, metricId: string) =>
      request<void>(`/api/v1/workspaces/${workspaceId}/semantic/metrics/${metricId}`, { method: "DELETE" }),
    listDimensions: (workspaceId: string) =>
      request<Dimension[]>(`/api/v1/workspaces/${workspaceId}/semantic/dimensions`),
    createDimension: (workspaceId: string, datasetId: string, name: string, column: string, description?: string) =>
      request<Dimension>(`/api/v1/workspaces/${workspaceId}/semantic/dimensions`, {
        method: "POST",
        body: JSON.stringify({ dataset_id: datasetId, name, column, description }),
      }),
  },
  connectors: {
    list: (workspaceId: string) => request<DatabaseConnector[]>(`/api/v1/workspaces/${workspaceId}/connectors`),
    create: (
      workspaceId: string,
      name: string,
      dialect: "sqlite" | "postgresql" | "mysql",
      database: string,
      host?: string,
      port?: number,
      username?: string,
      password?: string
    ) =>
      request<DatabaseConnector>(`/api/v1/workspaces/${workspaceId}/connectors`, {
        method: "POST",
        body: JSON.stringify({ name, dialect, database, host, port, username, password }),
      }),
    test: (workspaceId: string, connectorId: string) =>
      request<DatabaseConnector>(`/api/v1/workspaces/${workspaceId}/connectors/${connectorId}/test`, {
        method: "POST",
      }),
    schema: (workspaceId: string, connectorId: string) =>
      request<{ tables: ConnectorTableSchema[] }>(`/api/v1/workspaces/${workspaceId}/connectors/${connectorId}/schema`),
    sync: (workspaceId: string, connectorId: string, tableName: string, datasetName: string, limit?: number) =>
      request<Dataset>(
        `/api/v1/workspaces/${workspaceId}/connectors/${connectorId}/sync?table_name=${encodeURIComponent(
          tableName
        )}&dataset_name=${encodeURIComponent(datasetName)}${limit ? `&limit=${limit}` : ""}`,
        { method: "POST" }
      ),
    delete: (workspaceId: string, connectorId: string) =>
      request<void>(`/api/v1/workspaces/${workspaceId}/connectors/${connectorId}`, { method: "DELETE" }),
  },
  inventory: {
    suppliers: {
      list: (workspaceId: string) => request<Supplier[]>(`/api/v1/workspaces/${workspaceId}/inventory/suppliers`),
      create: (workspaceId: string, name: string, contactEmail?: string, leadTimeDays?: number) =>
        request<Supplier>(`/api/v1/workspaces/${workspaceId}/inventory/suppliers`, {
          method: "POST",
          body: JSON.stringify({ name, contact_email: contactEmail || null, lead_time_days: leadTimeDays ?? 7 }),
        }),
    },
    warehouses: {
      list: (workspaceId: string) => request<Warehouse[]>(`/api/v1/workspaces/${workspaceId}/inventory/warehouses`),
      create: (workspaceId: string, name: string, location?: string) =>
        request<Warehouse>(`/api/v1/workspaces/${workspaceId}/inventory/warehouses`, {
          method: "POST",
          body: JSON.stringify({ name, location: location || null }),
        }),
    },
    products: {
      list: (workspaceId: string) => request<Product[]>(`/api/v1/workspaces/${workspaceId}/inventory/products`),
      create: (workspaceId: string, product: Partial<Product>) =>
        request<Product>(`/api/v1/workspaces/${workspaceId}/inventory/products`, {
          method: "POST",
          body: JSON.stringify(product),
        }),
    },
    movements: {
      create: (
        workspaceId: string,
        productId: string,
        warehouseId: string,
        quantity: number,
        movementType: string,
        reference?: string
      ) =>
        request(`/api/v1/workspaces/${workspaceId}/inventory/movements`, {
          method: "POST",
          body: JSON.stringify({
            product_id: productId,
            warehouse_id: warehouseId,
            quantity,
            movement_type: movementType,
            reference: reference || null,
          }),
        }),
    },
    purchaseOrders: {
      list: (workspaceId: string) =>
        request<PurchaseOrder[]>(`/api/v1/workspaces/${workspaceId}/inventory/purchase-orders`),
      create: (workspaceId: string, supplierId: string, lines: OrderLine[]) =>
        request<PurchaseOrder>(`/api/v1/workspaces/${workspaceId}/inventory/purchase-orders`, {
          method: "POST",
          body: JSON.stringify({ supplier_id: supplierId, lines }),
        }),
      receive: (workspaceId: string, poId: string, warehouseId: string) =>
        request<PurchaseOrder>(
          `/api/v1/workspaces/${workspaceId}/inventory/purchase-orders/${poId}/receive?warehouse_id=${warehouseId}`,
          { method: "POST" }
        ),
    },
    salesOrders: {
      list: (workspaceId: string) =>
        request<SalesOrder[]>(`/api/v1/workspaces/${workspaceId}/inventory/sales-orders`),
      create: (workspaceId: string, customerName: string, warehouseId: string, lines: OrderLine[]) =>
        request<SalesOrder>(`/api/v1/workspaces/${workspaceId}/inventory/sales-orders`, {
          method: "POST",
          body: JSON.stringify({ customer_name: customerName, warehouse_id: warehouseId, lines }),
        }),
      fulfill: (workspaceId: string, soId: string) =>
        request<SalesOrder>(`/api/v1/workspaces/${workspaceId}/inventory/sales-orders/${soId}/fulfill`, {
          method: "POST",
        }),
    },
    kpis: {
      stockLevels: (workspaceId: string) =>
        request<StockLevel[]>(`/api/v1/workspaces/${workspaceId}/inventory/kpis/stock-levels`),
      inventoryValue: (workspaceId: string) =>
        request<InventoryValue[]>(`/api/v1/workspaces/${workspaceId}/inventory/kpis/inventory-value`),
      abcAnalysis: (workspaceId: string) =>
        request<ABCAnalysisRow[]>(`/api/v1/workspaces/${workspaceId}/inventory/kpis/abc-analysis`),
      reorderSuggestions: (workspaceId: string) =>
        request<ReorderSuggestion[]>(`/api/v1/workspaces/${workspaceId}/inventory/kpis/reorder-suggestions`),
    },
  },
  ml: {
    train: (
      workspaceId: string,
      datasetId: string,
      name: string,
      modelType: "regression" | "classification" | "clustering",
      featureColumns: string[],
      targetColumn?: string,
      nClusters?: number,
      algorithm?: string
    ) =>
      request<MLModel>(`/api/v1/workspaces/${workspaceId}/ml-models`, {
        method: "POST",
        body: JSON.stringify({
          dataset_id: datasetId,
          name,
          model_type: modelType,
          feature_columns: featureColumns,
          target_column: targetColumn || null,
          n_clusters: nClusters || 3,
          algorithm: algorithm || "auto",
        }),
      }),
    list: (workspaceId: string) => request<MLModel[]>(`/api/v1/workspaces/${workspaceId}/ml-models`),
    predict: (workspaceId: string, modelId: string, rows: Record<string, unknown>[]) =>
      request<{ predictions: unknown[] }>(`/api/v1/workspaces/${workspaceId}/ml-models/${modelId}/predict`, {
        method: "POST",
        body: JSON.stringify({ rows }),
      }),
  },
  forecasting: {
    forecast: (
      workspaceId: string,
      datasetId: string,
      dateColumn: string,
      metricColumn: string,
      periods: number,
      freq: "D" | "W" | "M"
    ) =>
      request<ForecastResponse>(`/api/v1/workspaces/${workspaceId}/forecasts`, {
        method: "POST",
        body: JSON.stringify({
          dataset_id: datasetId,
          date_column: dateColumn,
          metric_column: metricColumn,
          periods,
          freq,
        }),
      }),
  },
  reports: {
    /** Returns a Blob (PDF bytes) rather than JSON — caller is responsible for triggering the download. */
    downloadDashboardPdf: async (
      workspaceId: string,
      dashboardId: string,
      includeAiSummary: boolean
    ): Promise<Blob> => {
      const token = getToken();
      const res = await fetch(
        `${API_BASE_URL}/api/v1/workspaces/${workspaceId}/reports/dashboards/${dashboardId}/pdf`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ include_ai_summary: includeAiSummary }),
        }
      );
      if (!res.ok) {
        const errorBody = await res.json().catch(() => ({ detail: res.statusText }));
        throw new Error(errorBody.detail || `Request failed with status ${res.status}`);
      }
      return res.blob();
    },
    /** Returns a Blob (XLSX bytes) rather than JSON — caller is responsible for triggering the download. */
    downloadDashboardXlsx: async (
      workspaceId: string,
      dashboardId: string,
      includeAiSummary: boolean
    ): Promise<Blob> => {
      const token = getToken();
      const res = await fetch(
        `${API_BASE_URL}/api/v1/workspaces/${workspaceId}/reports/dashboards/${dashboardId}/xlsx`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ include_ai_summary: includeAiSummary }),
        }
      );
      if (!res.ok) {
        const errorBody = await res.json().catch(() => ({ detail: res.statusText }));
        throw new Error(errorBody.detail || `Request failed with status ${res.status}`);
      }
      return res.blob();
    },
  },
  dashboards: {
    list: (workspaceId: string) => request<Dashboard[]>(`/api/v1/workspaces/${workspaceId}/dashboards`),
    create: (workspaceId: string, name: string) =>
      request<Dashboard>(`/api/v1/workspaces/${workspaceId}/dashboards`, {
        method: "POST",
        body: JSON.stringify({ name }),
      }),
    addWidget: (workspaceId: string, dashboardId: string, widget: Partial<Widget>) =>
      request<Widget>(`/api/v1/workspaces/${workspaceId}/dashboards/${dashboardId}/widgets`, {
        method: "POST",
        body: JSON.stringify(widget),
      }),
    listWidgets: (workspaceId: string, dashboardId: string) =>
      request<Widget[]>(`/api/v1/workspaces/${workspaceId}/dashboards/${dashboardId}/widgets`),
    getWidgetData: (workspaceId: string, dashboardId: string, widgetId: string) =>
      request<WidgetData>(
        `/api/v1/workspaces/${workspaceId}/dashboards/${dashboardId}/widgets/${widgetId}/data`
      ),
  },
};
