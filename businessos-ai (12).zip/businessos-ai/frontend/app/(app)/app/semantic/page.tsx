"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, Dataset, Dimension, Metric } from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { AppNav } from "@/components/AppNav";

export default function SemanticLayerPage() {
  const router = useRouter();
  const { token, setToken, selectedWorkspaceId } = useAppStore();

  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [dimensions, setDimensions] = useState<Dimension[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [evaluations, setEvaluations] = useState<Record<string, number>>({});

  const [datasetId, setDatasetId] = useState("");
  const [metricName, setMetricName] = useState("");
  const [expression, setExpression] = useState("");
  const [format, setFormat] = useState<"currency" | "number" | "percent">("number");
  const [creatingMetric, setCreatingMetric] = useState(false);

  const [dimName, setDimName] = useState("");
  const [dimColumn, setDimColumn] = useState("");
  const [creatingDim, setCreatingDim] = useState(false);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  function refresh() {
    if (!selectedWorkspaceId) return;
    api.datasets.list(selectedWorkspaceId).then(setDatasets).catch((e) => setError(e.message));
    api.semantic.listMetrics(selectedWorkspaceId).then(setMetrics).catch((e) => setError(e.message));
    api.semantic.listDimensions(selectedWorkspaceId).then(setDimensions).catch((e) => setError(e.message));
  }

  useEffect(refresh, [selectedWorkspaceId]);

  async function createMetric() {
    if (!selectedWorkspaceId || !datasetId || !metricName || !expression) return;
    setCreatingMetric(true);
    setError(null);
    try {
      const metric = await api.semantic.createMetric(selectedWorkspaceId, datasetId, metricName, expression, format);
      setMetrics((prev) => [...prev, metric]);
      setMetricName("");
      setExpression("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create metric");
    } finally {
      setCreatingMetric(false);
    }
  }

  async function evaluateMetric(metric: Metric) {
    if (!selectedWorkspaceId) return;
    setError(null);
    try {
      const result = await api.semantic.evaluateMetric(selectedWorkspaceId, metric.id);
      setEvaluations((prev) => ({ ...prev, [metric.id]: result.value }));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Evaluation failed");
    }
  }

  async function createDimension() {
    if (!selectedWorkspaceId || !datasetId || !dimName || !dimColumn) return;
    setCreatingDim(true);
    setError(null);
    try {
      const dim = await api.semantic.createDimension(selectedWorkspaceId, datasetId, dimName, dimColumn);
      setDimensions((prev) => [...prev, dim]);
      setDimName("");
      setDimColumn("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create dimension");
    } finally {
      setCreatingDim(false);
    }
  }

  function formatValue(value: number, format: string): string {
    if (format === "currency") return `$${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
    if (format === "percent") return `${(value * 100).toFixed(1)}%`;
    return value.toLocaleString(undefined, { maximumFractionDigits: 2 });
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <AppNav />

      {!selectedWorkspaceId && (
        <p className="text-sm text-slate-500">Select a workspace on the Dashboards page first.</p>
      )}

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>
      )}

      {selectedWorkspaceId && (
        <>
          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Define a metric</h2>
            <p className="mb-3 text-xs text-slate-500">
              Formula syntax: aggregate calls (SUM, AVG, COUNT, MIN, MAX) over a column, combined with +, -, *, /.
              e.g. <code className="rounded bg-slate-100 px-1">SUM(revenue) - SUM(cost)</code>
            </p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <select
                value={datasetId}
                onChange={(e) => setDatasetId(e.target.value)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="">Select dataset...</option>
                {datasets.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
              <select
                value={format}
                onChange={(e) => setFormat(e.target.value as typeof format)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="number">Number</option>
                <option value="currency">Currency</option>
                <option value="percent">Percent</option>
              </select>
              <input
                value={metricName}
                onChange={(e) => setMetricName(e.target.value)}
                placeholder="Metric name, e.g. Gross Profit"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <input
                value={expression}
                onChange={(e) => setExpression(e.target.value)}
                placeholder="SUM(revenue) - SUM(cost)"
                className="rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm"
              />
              <button
                onClick={createMetric}
                disabled={creatingMetric || !datasetId || !metricName || !expression}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50 sm:col-span-2"
              >
                {creatingMetric ? "Creating..." : "Create metric"}
              </button>
            </div>
          </section>

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Metrics</h2>
            {metrics.length === 0 ? (
              <p className="text-sm text-slate-400">No metrics defined yet.</p>
            ) : (
              <ul className="space-y-2">
                {metrics.map((m) => (
                  <li key={m.id} className="flex items-center justify-between border-b border-slate-100 py-2">
                    <div>
                      <p className="text-sm font-medium">{m.name}</p>
                      <p className="font-mono text-xs text-slate-500">{m.expression}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      {evaluations[m.id] !== undefined && (
                        <span className="text-sm font-medium text-brand-600">
                          {formatValue(evaluations[m.id], m.format)}
                        </span>
                      )}
                      <button
                        onClick={() => evaluateMetric(m)}
                        className="text-xs font-medium text-brand-500 hover:underline"
                      >
                        Evaluate
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Define a dimension</h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <input
                value={dimName}
                onChange={(e) => setDimName(e.target.value)}
                placeholder="Dimension name, e.g. Region"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <input
                value={dimColumn}
                onChange={(e) => setDimColumn(e.target.value)}
                placeholder="Column name, e.g. region"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <button
                onClick={createDimension}
                disabled={creatingDim || !datasetId || !dimName || !dimColumn}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50 sm:col-span-2"
              >
                {creatingDim ? "Creating..." : "Create dimension"}
              </button>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Dimensions</h2>
            {dimensions.length === 0 ? (
              <p className="text-sm text-slate-400">No dimensions defined yet.</p>
            ) : (
              <ul className="text-sm">
                {dimensions.map((d) => (
                  <li key={d.id} className="flex justify-between border-b border-slate-100 py-1.5">
                    <span className="font-medium">{d.name}</span>
                    <span className="text-slate-400">{d.column}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </div>
  );
}
