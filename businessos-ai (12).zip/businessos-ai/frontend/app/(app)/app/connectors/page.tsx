"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, ConnectorTableSchema, DatabaseConnector } from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { AppNav } from "@/components/AppNav";

export default function ConnectorsPage() {
  const router = useRouter();
  const { token, setToken, selectedWorkspaceId } = useAppStore();

  const [connectors, setConnectors] = useState<DatabaseConnector[]>([]);
  const [selected, setSelected] = useState<DatabaseConnector | null>(null);
  const [tables, setTables] = useState<ConnectorTableSchema[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [dialect, setDialect] = useState<"sqlite" | "postgresql" | "mysql">("sqlite");
  const [name, setName] = useState("");
  const [database, setDatabase] = useState("");
  const [host, setHost] = useState("");
  const [port, setPort] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  function refresh() {
    if (!selectedWorkspaceId) return;
    api.connectors.list(selectedWorkspaceId).then(setConnectors).catch((e) => setError(e.message));
  }

  useEffect(refresh, [selectedWorkspaceId]);

  async function createConnector() {
    if (!selectedWorkspaceId || !name || !database) return;
    setCreating(true);
    setError(null);
    try {
      const connector = await api.connectors.create(
        selectedWorkspaceId,
        name,
        dialect,
        database,
        host || undefined,
        port ? Number(port) : undefined,
        username || undefined,
        password || undefined
      );
      setConnectors((prev) => [...prev, connector]);
      setName("");
      setDatabase("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create connector");
    } finally {
      setCreating(false);
    }
  }

  async function testConnection(connector: DatabaseConnector) {
    if (!selectedWorkspaceId) return;
    setError(null);
    try {
      const updated = await api.connectors.test(selectedWorkspaceId, connector.id);
      setConnectors((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Connection test failed");
    }
  }

  async function browseSchema(connector: DatabaseConnector) {
    if (!selectedWorkspaceId) return;
    setSelected(connector);
    setTables([]);
    setError(null);
    try {
      const result = await api.connectors.schema(selectedWorkspaceId, connector.id);
      setTables(result.tables);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Schema discovery failed");
    }
  }

  async function syncTable(tableName: string) {
    if (!selectedWorkspaceId || !selected) return;
    const datasetName = prompt("Name for the new dataset?", tableName) || tableName;
    try {
      await api.connectors.sync(selectedWorkspaceId, selected.id, tableName, datasetName);
      alert(`Synced '${tableName}' into dataset '${datasetName}'. See it on the Dashboards page.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Sync failed");
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <AppNav />

      {!selectedWorkspaceId && (
        <p className="text-sm text-slate-500">Select a workspace on the Dashboards page first.</p>
      )}

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>
      )}

      {selectedWorkspaceId && (
        <>
          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Add a database connector</h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Connector name"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <select
                value={dialect}
                onChange={(e) => setDialect(e.target.value as typeof dialect)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="sqlite">SQLite</option>
                <option value="postgresql">PostgreSQL</option>
                <option value="mysql">MySQL</option>
              </select>
              <input
                value={database}
                onChange={(e) => setDatabase(e.target.value)}
                placeholder={dialect === "sqlite" ? "File path (e.g. /data/mydb.sqlite)" : "Database name"}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm sm:col-span-2"
              />
              {dialect !== "sqlite" && (
                <>
                  <input
                    value={host}
                    onChange={(e) => setHost(e.target.value)}
                    placeholder="Host"
                    className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                  <input
                    value={port}
                    onChange={(e) => setPort(e.target.value)}
                    placeholder={dialect === "postgresql" ? "Port (default 5432)" : "Port (default 3306)"}
                    className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                  <input
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Username"
                    className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </>
              )}
              <button
                onClick={createConnector}
                disabled={creating || !name || !database}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50 sm:col-span-2"
              >
                {creating ? "Adding..." : "Add connector"}
              </button>
            </div>
          </section>

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Connectors</h2>
            {connectors.length === 0 ? (
              <p className="text-sm text-slate-400">No connectors yet.</p>
            ) : (
              <ul className="space-y-1">
                {connectors.map((c) => (
                  <li key={c.id} className="flex items-center justify-between rounded-lg px-2 py-2 hover:bg-slate-50">
                    <button onClick={() => browseSchema(c)} className="text-left text-sm">
                      <span className="font-medium">{c.name}</span>{" "}
                      <span className="text-slate-400">({c.dialect})</span>{" "}
                      <span
                        className={`ml-2 rounded-full px-2 py-0.5 text-xs ${
                          c.status === "connected"
                            ? "bg-emerald-100 text-emerald-700"
                            : c.status === "failed"
                            ? "bg-red-100 text-red-700"
                            : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {c.status}
                      </span>
                    </button>
                    <button
                      onClick={() => testConnection(c)}
                      className="text-xs font-medium text-brand-500 hover:underline"
                    >
                      Test connection
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {selected && (
            <section className="rounded-xl border border-slate-200 bg-white p-4">
              <h2 className="mb-3 text-sm font-medium text-slate-700">
                Tables in &ldquo;{selected.name}&rdquo;
              </h2>
              {tables.length === 0 ? (
                <p className="text-sm text-slate-400">No tables found (or schema not loaded yet).</p>
              ) : (
                <ul className="space-y-2">
                  {tables.map((t) => (
                    <li key={t.table_name} className="flex items-center justify-between border-b border-slate-100 py-2">
                      <div className="text-sm">
                        <span className="font-medium">{t.table_name}</span>{" "}
                        <span className="text-slate-400">({t.columns.length} columns)</span>
                      </div>
                      <button
                        onClick={() => syncTable(t.table_name)}
                        className="text-xs font-medium text-brand-500 hover:underline"
                      >
                        Sync into a dataset
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          )}
        </>
      )}
    </div>
  );
}
