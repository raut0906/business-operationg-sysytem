"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, Dashboard, Dataset, Dimension, Metric, Organization, Widget, WidgetData, Workspace } from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { WidgetChart } from "@/components/WidgetChart";
import { AppNav } from "@/components/AppNav";

export default function AppPage() {
  const router = useRouter();
  const { token, setToken, selectedOrgId, setSelectedOrgId, selectedWorkspaceId, setSelectedWorkspaceId } =
    useAppStore();

  const [orgs, setOrgs] = useState<Organization[]>([]);
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [dimensions, setDimensions] = useState<Dimension[]>([]);
  const [dashboards, setDashboards] = useState<Dashboard[]>([]);
  const [selectedDashboardId, setSelectedDashboardId] = useState<string | null>(null);
  const [widgets, setWidgets] = useState<Widget[]>([]);
  const [widgetData, setWidgetData] = useState<Record<string, WidgetData>>({});
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  useEffect(() => {
    if (!token) return;
    api.organizations.list().then(setOrgs).catch((e) => setError(e.message));
  }, [token]);

  useEffect(() => {
    if (!selectedOrgId) return;
    api.workspaces.list(selectedOrgId).then(setWorkspaces).catch((e) => setError(e.message));
  }, [selectedOrgId]);

  useEffect(() => {
    if (!selectedWorkspaceId) return;
    api.datasets.list(selectedWorkspaceId).then(setDatasets).catch((e) => setError(e.message));
    api.semantic.listMetrics(selectedWorkspaceId).then(setMetrics).catch((e) => setError(e.message));
    api.semantic.listDimensions(selectedWorkspaceId).then(setDimensions).catch((e) => setError(e.message));
    api.dashboards.list(selectedWorkspaceId).then(setDashboards).catch((e) => setError(e.message));
  }, [selectedWorkspaceId]);

  useEffect(() => {
    if (!selectedWorkspaceId || !selectedDashboardId) return;
    api.dashboards.listWidgets(selectedWorkspaceId, selectedDashboardId).then(async (ws) => {
      setWidgets(ws);
      const dataEntries = await Promise.all(
        ws.map(async (w) => [
          w.id,
          await api.dashboards.getWidgetData(selectedWorkspaceId, selectedDashboardId, w.id),
        ] as const)
      );
      setWidgetData(Object.fromEntries(dataEntries));
    }).catch((e) => setError(e.message));
  }, [selectedWorkspaceId, selectedDashboardId]);

  async function createOrg() {
    const name = prompt("Organization name?");
    if (!name) return;
    const org = await api.organizations.create(name);
    setOrgs((prev) => [...prev, org]);
    setSelectedOrgId(org.id);
  }

  async function createWorkspace() {
    if (!selectedOrgId) return;
    const name = prompt("Workspace name?");
    if (!name) return;
    const ws = await api.workspaces.create(selectedOrgId, name);
    setWorkspaces((prev) => [...prev, ws]);
    setSelectedWorkspaceId(ws.id);
  }

  async function uploadDataset(file: File) {
    if (!selectedWorkspaceId) return;
    const name = file.name.replace(/\.(csv|xlsx|xls)$/i, "");
    try {
      const dataset = await api.datasets.upload(selectedWorkspaceId, name, file);
      setDatasets((prev) => [...prev, dataset]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    }
  }

  async function createDashboard() {
    if (!selectedWorkspaceId) return;
    const name = prompt("Dashboard name?");
    if (!name) return;
    const dashboard = await api.dashboards.create(selectedWorkspaceId, name);
    setDashboards((prev) => [...prev, dashboard]);
    setSelectedDashboardId(dashboard.id);
  }

  async function addWidget() {
    if (!selectedWorkspaceId || !selectedDashboardId || datasets.length === 0) return;

    const useSemanticLayer =
      metrics.length > 0 && dimensions.length > 0
        ? confirm(
            `Use a Semantic Layer metric/dimension instead of raw columns?\n\n` +
              `Metrics available: ${metrics.map((m) => m.name).join(", ")}\n` +
              `Dimensions available: ${dimensions.map((d) => d.name).join(", ")}\n\n` +
              `OK = use semantic layer, Cancel = use raw dataset columns`
          )
        : false;

    if (useSemanticLayer) {
      const metricName = prompt(`Metric name? (${metrics.map((m) => m.name).join(", ")})`);
      const metric = metrics.find((m) => m.name === metricName);
      if (!metric) return;
      const dimensionName = prompt(`Dimension name? (${dimensions.map((d) => d.name).join(", ")})`);
      const dimension = dimensions.find((d) => d.name === dimensionName);
      if (!dimension) return;

      await api.dashboards.addWidget(selectedWorkspaceId, selectedDashboardId, {
        dataset_id: metric.dataset_id,
        chart_type: "bar",
        title: `${metric.name} by ${dimension.name}`,
        metric_id: metric.id,
        dimension_id: dimension.id,
      });
    } else {
      const dataset = datasets[0];
      const dimension = prompt(`Dimension column (from '${dataset.name}')?`);
      const metric = prompt(`Metric column (numeric, from '${dataset.name}')?`);
      if (!dimension || !metric) return;
      await api.dashboards.addWidget(selectedWorkspaceId, selectedDashboardId, {
        dataset_id: dataset.id,
        chart_type: "bar",
        title: `${metric} by ${dimension}`,
        dimension,
        metric,
        aggregate: "SUM",
      });
    }

    const ws = await api.dashboards.listWidgets(selectedWorkspaceId, selectedDashboardId);
    setWidgets(ws);
  }

  async function downloadReport() {
    if (!selectedWorkspaceId || !selectedDashboardId) return;
    try {
      const blob = await api.reports.downloadDashboardPdf(selectedWorkspaceId, selectedDashboardId, false);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `dashboard-report-${selectedDashboardId}.pdf`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Report download failed");
    }
  }

  async function downloadXlsxReport() {
    if (!selectedWorkspaceId || !selectedDashboardId) return;
    try {
      const blob = await api.reports.downloadDashboardXlsx(selectedWorkspaceId, selectedDashboardId, false);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `dashboard-report-${selectedDashboardId}.xlsx`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Report download failed");
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <AppNav />

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">
          {error}
        </div>
      )}

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <section className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-medium text-slate-700">Organization</h2>
            <button onClick={createOrg} className="text-xs font-medium text-brand-500 hover:underline">
              + New
            </button>
          </div>
          <select
            value={selectedOrgId ?? ""}
            onChange={(e) => setSelectedOrgId(e.target.value || null)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">Select organization...</option>
            {orgs.map((o) => (
              <option key={o.id} value={o.id}>
                {o.name}
              </option>
            ))}
          </select>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-medium text-slate-700">Workspace</h2>
            <button
              onClick={createWorkspace}
              disabled={!selectedOrgId}
              className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
            >
              + New
            </button>
          </div>
          <select
            value={selectedWorkspaceId ?? ""}
            onChange={(e) => setSelectedWorkspaceId(e.target.value || null)}
            disabled={!selectedOrgId}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:opacity-40"
          >
            <option value="">Select workspace...</option>
            {workspaces.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </section>
      </div>

      {selectedWorkspaceId && (
        <>
          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-medium text-slate-700">Datasets</h2>
              <label className="cursor-pointer text-xs font-medium text-brand-500 hover:underline">
                + Upload CSV / Excel
                <input
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && uploadDataset(e.target.files[0])}
                />
              </label>
            </div>
            {datasets.length === 0 ? (
              <p className="text-sm text-slate-400">No datasets yet. Upload a CSV or Excel file to get started.</p>
            ) : (
              <ul className="divide-y divide-slate-100 text-sm">
                {datasets.map((d) => (
                  <li key={d.id} className="flex justify-between py-2">
                    <span>{d.name}</span>
                    <span className="text-slate-400">{d.row_count.toLocaleString()} rows</span>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-medium text-slate-700">Dashboards</h2>
              <div className="flex gap-3">
                <button onClick={createDashboard} className="text-xs font-medium text-brand-500 hover:underline">
                  + New dashboard
                </button>
                <button
                  onClick={addWidget}
                  disabled={!selectedDashboardId || datasets.length === 0}
                  className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
                >
                  + Add widget
                </button>
                <button
                  onClick={downloadReport}
                  disabled={!selectedDashboardId}
                  className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
                >
                  Download PDF report
                </button>
                <button
                  onClick={downloadXlsxReport}
                  disabled={!selectedDashboardId}
                  className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
                >
                  Download Excel report
                </button>
              </div>
            </div>
            <select
              value={selectedDashboardId ?? ""}
              onChange={(e) => setSelectedDashboardId(e.target.value || null)}
              className="mb-4 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            >
              <option value="">Select dashboard...</option>
              {dashboards.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>

            {selectedDashboardId && (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {widgets.map((w) => {
                  const data = widgetData[w.id];
                  return (
                    <div key={w.id} className="h-64 rounded-lg border border-slate-200 p-3">
                      <p className="mb-2 text-sm font-medium text-slate-700">{w.title}</p>
                      {data ? (
                        <div className="h-48">
                          <WidgetChart widget={data} />
                        </div>
                      ) : (
                        <p className="text-sm text-slate-400">Loading...</p>
                      )}
                    </div>
                  );
                })}
                {widgets.length === 0 && (
                  <p className="text-sm text-slate-400">No widgets yet. Click "+ Add widget" above.</p>
                )}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}
