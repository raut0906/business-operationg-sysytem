"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, CopilotAskResponse, CopilotChartSuggestion, Dataset } from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { AppNav } from "@/components/AppNav";

export default function CopilotPage() {
  const router = useRouter();
  const { token, setToken, selectedWorkspaceId } = useAppStore();

  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<string | null>(null);
  const [question, setQuestion] = useState("");
  const [askResult, setAskResult] = useState<CopilotAskResponse | null>(null);
  const [summary, setSummary] = useState<string | null>(null);
  const [chartSuggestion, setChartSuggestion] = useState<CopilotChartSuggestion | null>(null);
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  useEffect(() => {
    if (!selectedWorkspaceId) return;
    api.datasets.list(selectedWorkspaceId).then(setDatasets).catch((e) => setError(e.message));
  }, [selectedWorkspaceId]);

  async function handleAsk() {
    if (!selectedWorkspaceId || !selectedDatasetId || !question.trim()) return;
    setLoading("ask");
    setError(null);
    setAskResult(null);
    try {
      const result = await api.copilot.ask(selectedWorkspaceId, selectedDatasetId, question);
      setAskResult(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ask failed");
    } finally {
      setLoading(null);
    }
  }

  async function handleSummary() {
    if (!selectedWorkspaceId || !selectedDatasetId) return;
    setLoading("summary");
    setError(null);
    setSummary(null);
    try {
      const result = await api.copilot.summary(selectedWorkspaceId, selectedDatasetId);
      setSummary(result.summary);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Summary failed");
    } finally {
      setLoading(null);
    }
  }

  async function handleChartSuggestion() {
    if (!selectedWorkspaceId || !selectedDatasetId) return;
    setLoading("chart");
    setError(null);
    setChartSuggestion(null);
    try {
      const result = await api.copilot.chartSuggestion(selectedWorkspaceId, selectedDatasetId);
      setChartSuggestion(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Chart suggestion failed");
    } finally {
      setLoading(null);
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <AppNav />

      {!selectedWorkspaceId && (
        <p className="text-sm text-slate-500">Select a workspace on the Dashboards page first.</p>
      )}

      {selectedWorkspaceId && (
        <>
          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Dataset</h2>
            <select
              value={selectedDatasetId ?? ""}
              onChange={(e) => {
                setSelectedDatasetId(e.target.value || null);
                setAskResult(null);
                setSummary(null);
                setChartSuggestion(null);
              }}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            >
              <option value="">Select dataset...</option>
              {datasets.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </section>

          {error && (
            <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">
              {error}
              {error.toLowerCase().includes("not configured") && (
                <p className="mt-1 text-xs text-red-500">
                  Set AI_PROVIDER + the matching API key env var on the backend to enable Copilot.
                </p>
              )}
            </div>
          )}

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Ask a question</h2>
            <div className="flex gap-2">
              <input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAsk()}
                placeholder="e.g. What is total revenue by region?"
                disabled={!selectedDatasetId}
                className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:opacity-40"
              />
              <button
                onClick={handleAsk}
                disabled={!selectedDatasetId || loading === "ask"}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50"
              >
                {loading === "ask" ? "Thinking..." : "Ask"}
              </button>
            </div>

            {askResult && (
              <div className="mt-4">
                <p className="mb-2 rounded-lg bg-slate-50 px-3 py-2 font-mono text-xs text-slate-600">
                  {askResult.generated_sql}
                </p>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-left text-slate-500">
                      {askResult.columns.map((c) => (
                        <th key={c} className="py-1 pr-3">
                          {c}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {askResult.rows.map((row, i) => (
                      <tr key={i} className="border-b border-slate-100">
                        {askResult.columns.map((c) => (
                          <td key={c} className="py-1 pr-3">
                            {String(row[c])}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-medium text-slate-700">Executive summary</h2>
              <button
                onClick={handleSummary}
                disabled={!selectedDatasetId || loading === "summary"}
                className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
              >
                {loading === "summary" ? "Generating..." : "Generate"}
              </button>
            </div>
            {summary && <p className="text-sm text-slate-700">{summary}</p>}
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-medium text-slate-700">Chart suggestion</h2>
              <button
                onClick={handleChartSuggestion}
                disabled={!selectedDatasetId || loading === "chart"}
                className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
              >
                {loading === "chart" ? "Thinking..." : "Suggest"}
              </button>
            </div>
            {chartSuggestion && (
              <div className="text-sm text-slate-700">
                <p>
                  <span className="font-medium">{chartSuggestion.chart_type}</span> chart:{" "}
                  {chartSuggestion.aggregate}({chartSuggestion.metric}) by {chartSuggestion.dimension}
                </p>
                <p className="mt-1 text-slate-500">{chartSuggestion.reasoning}</p>
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}
