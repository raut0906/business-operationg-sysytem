"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, Dataset, MLModel } from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { AppNav } from "@/components/AppNav";

export default function MLStudioPage() {
  const router = useRouter();
  const { token, setToken, selectedWorkspaceId } = useAppStore();

  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [models, setModels] = useState<MLModel[]>([]);
  const [selectedModel, setSelectedModel] = useState<MLModel | null>(null);

  const [datasetId, setDatasetId] = useState("");
  const [modelName, setModelName] = useState("");
  const [modelType, setModelType] = useState<"regression" | "classification" | "clustering">("regression");
  const [algorithm, setAlgorithm] = useState("auto");
  const [featureColumns, setFeatureColumns] = useState("");
  const [targetColumn, setTargetColumn] = useState("");
  const [nClusters, setNClusters] = useState(3);
  const [training, setTraining] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [predictInput, setPredictInput] = useState("{}");
  const [predictResult, setPredictResult] = useState<unknown[] | null>(null);
  const [predicting, setPredicting] = useState(false);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  useEffect(() => {
    if (!selectedWorkspaceId) return;
    api.datasets.list(selectedWorkspaceId).then(setDatasets).catch((e) => setError(e.message));
    refreshModels();
  }, [selectedWorkspaceId]);

  function refreshModels() {
    if (!selectedWorkspaceId) return;
    api.ml.list(selectedWorkspaceId).then(setModels).catch((e) => setError(e.message));
  }

  useEffect(() => {
    setAlgorithm("auto");
  }, [modelType]);

  const algorithmOptions =
    modelType === "regression"
      ? ["auto", "linear", "random_forest", "gradient_boosting"]
      : modelType === "classification"
      ? ["auto", "logistic", "random_forest", "gradient_boosting"]
      : ["kmeans"];

  async function trainModel() {
    if (!selectedWorkspaceId || !datasetId || !modelName || !featureColumns.trim()) return;
    setTraining(true);
    setError(null);
    try {
      const features = featureColumns.split(",").map((f) => f.trim()).filter(Boolean);
      const model = await api.ml.train(
        selectedWorkspaceId,
        datasetId,
        modelName,
        modelType,
        features,
        modelType !== "clustering" ? targetColumn : undefined,
        nClusters,
        modelType !== "clustering" ? algorithm : undefined
      );
      setModels((prev) => [...prev, model]);
      setSelectedModel(model);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Training failed");
    } finally {
      setTraining(false);
    }
  }

  async function runPredict() {
    if (!selectedWorkspaceId || !selectedModel) return;
    setPredicting(true);
    setError(null);
    setPredictResult(null);
    try {
      const parsed = JSON.parse(predictInput);
      const rows = Array.isArray(parsed) ? parsed : [parsed];
      const result = await api.ml.predict(selectedWorkspaceId, selectedModel.id, rows);
      setPredictResult(result.predictions);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Prediction failed");
    } finally {
      setPredicting(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <AppNav />

      {!selectedWorkspaceId && (
        <p className="text-sm text-slate-500">Select a workspace on the Dashboards page first.</p>
      )}

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>
      )}

      {selectedWorkspaceId && (
        <>
          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Train a model</h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <select
                value={datasetId}
                onChange={(e) => setDatasetId(e.target.value)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="">Select dataset...</option>
                {datasets.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
              <input
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
                placeholder="Model name"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <select
                value={modelType}
                onChange={(e) => setModelType(e.target.value as typeof modelType)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="regression">Regression</option>
                <option value="classification">Classification</option>
                <option value="clustering">Clustering</option>
              </select>
              {modelType !== "clustering" && (
                <select
                  value={algorithm}
                  onChange={(e) => setAlgorithm(e.target.value)}
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                >
                  {algorithmOptions.map((a) => (
                    <option key={a} value={a}>
                      {a === "auto" ? "Auto (try all, compare)" : a.replace("_", " ")}
                    </option>
                  ))}
                </select>
              )}
              <input
                value={featureColumns}
                onChange={(e) => setFeatureColumns(e.target.value)}
                placeholder="Feature columns, comma-separated"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              {modelType !== "clustering" ? (
                <input
                  value={targetColumn}
                  onChange={(e) => setTargetColumn(e.target.value)}
                  placeholder="Target column"
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              ) : (
                <input
                  type="number"
                  min={2}
                  max={20}
                  value={nClusters}
                  onChange={(e) => setNClusters(Number(e.target.value))}
                  placeholder="Number of clusters"
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              )}
              <button
                onClick={trainModel}
                disabled={training || !datasetId || !modelName || !featureColumns.trim()}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50"
              >
                {training ? "Training..." : "Train model"}
              </button>
            </div>
          </section>

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Models</h2>
            {models.length === 0 ? (
              <p className="text-sm text-slate-400">No models trained yet.</p>
            ) : (
              <ul className="space-y-1">
                {models.map((m) => (
                  <li key={m.id}>
                    <button
                      onClick={() => setSelectedModel(m)}
                      className={`w-full rounded-lg px-3 py-2 text-left text-sm ${
                        selectedModel?.id === m.id ? "bg-brand-50 text-brand-600" : "hover:bg-slate-50"
                      }`}
                    >
                      <span className="font-medium">{m.name}</span>{" "}
                      <span className="text-slate-400">
                        ({m.model_type}, {m.algorithm || "..."}, {m.status})
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {selectedModel && (
            <section className="rounded-xl border border-slate-200 bg-white p-4">
              <h2 className="mb-3 text-sm font-medium text-slate-700">{selectedModel.name} details</h2>

              {selectedModel.status === "failed" && (
                <p className="mb-3 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">
                  {selectedModel.error_message}
                </p>
              )}

              <div className="mb-4">
                <p className="mb-1 text-xs font-medium text-slate-500">
                  Metrics {selectedModel.candidates.length > 0 && `(winner: ${selectedModel.algorithm})`}
                </p>
                <pre className="rounded-lg bg-slate-50 p-3 text-xs">
                  {JSON.stringify(selectedModel.metrics, null, 2)}
                </pre>
              </div>

              {selectedModel.candidates.length > 0 && (
                <div className="mb-4">
                  <p className="mb-1 text-xs font-medium text-slate-500">
                    Model comparison (AutoML tried {selectedModel.candidates.length} algorithms)
                  </p>
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-left text-slate-500">
                        <th className="py-1 pr-3">Algorithm</th>
                        <th className="py-1">Metrics</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedModel.candidates.map((c) => (
                        <tr
                          key={c.algorithm}
                          className={`border-b border-slate-100 ${
                            c.algorithm === selectedModel.algorithm ? "bg-brand-50" : ""
                          }`}
                        >
                          <td className="py-1 pr-3 font-medium">
                            {c.algorithm} {c.algorithm === selectedModel.algorithm && "★"}
                          </td>
                          <td className="py-1 text-slate-500">{JSON.stringify(c.metrics)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {Object.keys(selectedModel.feature_importance).length > 0 && (
                <div className="mb-4">
                  <p className="mb-1 text-xs font-medium text-slate-500">Feature importance</p>
                  <ul className="text-sm">
                    {Object.entries(selectedModel.feature_importance)
                      .sort((a, b) => b[1] - a[1])
                      .map(([feature, importance]) => (
                        <li key={feature} className="flex justify-between border-b border-slate-100 py-1">
                          <span>{feature}</span>
                          <span className="text-slate-500">{importance.toFixed(4)}</span>
                        </li>
                      ))}
                  </ul>
                </div>
              )}

              {selectedModel.status === "ready" && selectedModel.model_type !== "clustering" && (
                <div>
                  <p className="mb-1 text-xs font-medium text-slate-500">
                    Predict (JSON object or array of objects with feature columns)
                  </p>
                  <textarea
                    value={predictInput}
                    onChange={(e) => setPredictInput(e.target.value)}
                    rows={3}
                    className="w-full rounded-lg border border-slate-300 px-2 py-1.5 font-mono text-xs"
                  />
                  <button
                    onClick={runPredict}
                    disabled={predicting}
                    className="mt-2 rounded-lg bg-brand-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-brand-600 disabled:opacity-50"
                  >
                    {predicting ? "Predicting..." : "Predict"}
                  </button>
                  {predictResult && (
                    <pre className="mt-2 rounded-lg bg-slate-50 p-3 text-xs">
                      {JSON.stringify(predictResult, null, 2)}
                    </pre>
                  )}
                </div>
              )}
            </section>
          )}
        </>
      )}
    </div>
  );
}
