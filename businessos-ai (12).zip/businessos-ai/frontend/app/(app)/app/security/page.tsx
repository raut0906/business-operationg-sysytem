"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, ColumnLevelPolicy, Dataset, RowLevelPolicy, SecuredPreview } from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { AppNav } from "@/components/AppNav";

const ROLE_LABELS = ["Viewer", "Editor", "Admin", "Owner"];

export default function SecurityPage() {
  const router = useRouter();
  const { token, setToken, selectedWorkspaceId } = useAppStore();

  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [rowPolicies, setRowPolicies] = useState<RowLevelPolicy[]>([]);
  const [columnPolicies, setColumnPolicies] = useState<ColumnLevelPolicy[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [datasetId, setDatasetId] = useState("");
  const [maxRole, setMaxRole] = useState(0);
  const [filterExpr, setFilterExpr] = useState("");
  const [columnName, setColumnName] = useState("");
  const [accessType, setAccessType] = useState<"full" | "masked" | "hidden">("masked");

  const [previewDatasetId, setPreviewDatasetId] = useState("");
  const [preview, setPreview] = useState<SecuredPreview | null>(null);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  function refresh() {
    if (!selectedWorkspaceId) return;
    api.datasets.list(selectedWorkspaceId).then(setDatasets).catch((e) => setError(e.message));
    api.security.listRowPolicies(selectedWorkspaceId).then(setRowPolicies).catch((e) => setError(e.message));
    api.security.listColumnPolicies(selectedWorkspaceId).then(setColumnPolicies).catch((e) => setError(e.message));
  }

  useEffect(refresh, [selectedWorkspaceId]);

  async function createRowPolicy() {
    if (!selectedWorkspaceId || !datasetId || !filterExpr) return;
    try {
      const policy = await api.security.createRowPolicy(selectedWorkspaceId, datasetId, maxRole, filterExpr);
      setRowPolicies((prev) => [...prev, policy]);
      setFilterExpr("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create row policy");
    }
  }

  async function createColumnPolicy() {
    if (!selectedWorkspaceId || !datasetId || !columnName) return;
    try {
      const policy = await api.security.createColumnPolicy(selectedWorkspaceId, datasetId, maxRole, columnName, accessType);
      setColumnPolicies((prev) => [...prev, policy]);
      setColumnName("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create column policy");
    }
  }

  async function deleteRowPolicy(id: string) {
    if (!selectedWorkspaceId) return;
    await api.security.deleteRowPolicy(selectedWorkspaceId, id);
    setRowPolicies((prev) => prev.filter((p) => p.id !== id));
  }

  async function deleteColumnPolicy(id: string) {
    if (!selectedWorkspaceId) return;
    await api.security.deleteColumnPolicy(selectedWorkspaceId, id);
    setColumnPolicies((prev) => prev.filter((p) => p.id !== id));
  }

  async function loadPreview() {
    if (!selectedWorkspaceId || !previewDatasetId) return;
    setError(null);
    try {
      const result = await api.security.securedPreview(selectedWorkspaceId, previewDatasetId);
      setPreview(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Preview failed");
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <AppNav />

      {!selectedWorkspaceId && (
        <p className="text-sm text-slate-500">Select a workspace on the Dashboards page first.</p>
      )}

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>
      )}

      {selectedWorkspaceId && (
        <>
          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Dataset &amp; role scope</h2>
            <p className="mb-3 text-xs text-slate-500">
              A policy applies to any member whose role is at or below the selected level — e.g. "Viewer" means only
              viewers are restricted; editors and above see unrestricted data.
            </p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <select
                value={datasetId}
                onChange={(e) => setDatasetId(e.target.value)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="">Select dataset...</option>
                {datasets.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
              <select
                value={maxRole}
                onChange={(e) => setMaxRole(Number(e.target.value))}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                {ROLE_LABELS.map((label, i) => (
                  <option key={i} value={i}>
                    Applies to: {label} (and below)
                  </option>
                ))}
              </select>
            </div>
          </section>

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Row-level policies</h2>
            <div className="mb-3 flex gap-2">
              <input
                value={filterExpr}
                onChange={(e) => setFilterExpr(e.target.value)}
                placeholder="e.g. region == 'West'"
                className="flex-1 rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm"
              />
              <button
                onClick={createRowPolicy}
                disabled={!datasetId || !filterExpr}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50"
              >
                Add
              </button>
            </div>
            {rowPolicies.length === 0 ? (
              <p className="text-sm text-slate-400">No row-level policies yet.</p>
            ) : (
              <ul className="space-y-1">
                {rowPolicies.map((p) => (
                  <li key={p.id} className="flex items-center justify-between border-b border-slate-100 py-1.5 text-sm">
                    <span>
                      <span className="font-mono text-xs text-slate-600">{p.filter_expression}</span>{" "}
                      <span className="text-slate-400">(applies to {ROLE_LABELS[p.max_role]} and below)</span>
                    </span>
                    <button onClick={() => deleteRowPolicy(p.id)} className="text-xs text-slate-400 hover:text-red-500">
                      remove
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Column-level policies</h2>
            <div className="mb-3 flex gap-2">
              <input
                value={columnName}
                onChange={(e) => setColumnName(e.target.value)}
                placeholder="Column name"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <select
                value={accessType}
                onChange={(e) => setAccessType(e.target.value as typeof accessType)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="masked">Masked</option>
                <option value="hidden">Hidden</option>
                <option value="full">Full</option>
              </select>
              <button
                onClick={createColumnPolicy}
                disabled={!datasetId || !columnName}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50"
              >
                Add
              </button>
            </div>
            {columnPolicies.length === 0 ? (
              <p className="text-sm text-slate-400">No column-level policies yet.</p>
            ) : (
              <ul className="space-y-1">
                {columnPolicies.map((p) => (
                  <li key={p.id} className="flex items-center justify-between border-b border-slate-100 py-1.5 text-sm">
                    <span>
                      <span className="font-medium">{p.column_name}</span>{" "}
                      <span className="text-slate-400">
                        → {p.access_type} (applies to {ROLE_LABELS[p.max_role]} and below)
                      </span>
                    </span>
                    <button
                      onClick={() => deleteColumnPolicy(p.id)}
                      className="text-xs text-slate-400 hover:text-red-500"
                    >
                      remove
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Preview as yourself</h2>
            <div className="mb-3 flex gap-2">
              <select
                value={previewDatasetId}
                onChange={(e) => setPreviewDatasetId(e.target.value)}
                className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="">Select dataset...</option>
                {datasets.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
              <button
                onClick={loadPreview}
                disabled={!previewDatasetId}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50"
              >
                Preview
              </button>
            </div>
            {preview && (
              <div>
                {preview.policies_applied.length > 0 && (
                  <p className="mb-2 text-xs text-slate-500">
                    Policies applied to you: {preview.policies_applied.join("; ")}
                  </p>
                )}
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-left text-slate-500">
                      {preview.columns.map((c) => (
                        <th key={c} className="py-1 pr-3">
                          {c}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {preview.rows.map((row, i) => (
                      <tr key={i} className="border-b border-slate-100">
                        {preview.columns.map((c) => (
                          <td key={c} className="py-1 pr-3">
                            {String(row[c])}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p className="mt-2 text-xs text-slate-400">{preview.row_count} total rows visible to you</p>
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}
