"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  api,
  ABCAnalysisRow,
  InventoryValue,
  Product,
  PurchaseOrder,
  ReorderSuggestion,
  SalesOrder,
  Supplier,
  Warehouse,
} from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { AppNav } from "@/components/AppNav";

type Tab = "products" | "orders" | "kpis";

export default function InventoryPage() {
  const router = useRouter();
  const { token, setToken, selectedWorkspaceId } = useAppStore();

  const [tab, setTab] = useState<Tab>("products");
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [salesOrders, setSalesOrders] = useState<SalesOrder[]>([]);
  const [inventoryValue, setInventoryValue] = useState<InventoryValue[]>([]);
  const [abcAnalysis, setAbcAnalysis] = useState<ABCAnalysisRow[]>([]);
  const [reorderSuggestions, setReorderSuggestions] = useState<ReorderSuggestion[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  function refreshAll() {
    if (!selectedWorkspaceId) return;
    api.inventory.suppliers.list(selectedWorkspaceId).then(setSuppliers).catch((e) => setError(e.message));
    api.inventory.warehouses.list(selectedWorkspaceId).then(setWarehouses).catch((e) => setError(e.message));
    api.inventory.products.list(selectedWorkspaceId).then(setProducts).catch((e) => setError(e.message));
    api.inventory.purchaseOrders.list(selectedWorkspaceId).then(setPurchaseOrders).catch((e) => setError(e.message));
    api.inventory.salesOrders.list(selectedWorkspaceId).then(setSalesOrders).catch((e) => setError(e.message));
  }

  function refreshKpis() {
    if (!selectedWorkspaceId) return;
    api.inventory.kpis.inventoryValue(selectedWorkspaceId).then(setInventoryValue).catch((e) => setError(e.message));
    api.inventory.kpis.abcAnalysis(selectedWorkspaceId).then(setAbcAnalysis).catch((e) => setError(e.message));
    api.inventory.kpis
      .reorderSuggestions(selectedWorkspaceId)
      .then(setReorderSuggestions)
      .catch((e) => setError(e.message));
  }

  useEffect(() => {
    refreshAll();
  }, [selectedWorkspaceId]);

  useEffect(() => {
    if (tab === "kpis") refreshKpis();
  }, [tab, selectedWorkspaceId]);

  async function createSupplier() {
    if (!selectedWorkspaceId) return;
    const name = prompt("Supplier name?");
    if (!name) return;
    await api.inventory.suppliers.create(selectedWorkspaceId, name);
    refreshAll();
  }

  async function createWarehouse() {
    if (!selectedWorkspaceId) return;
    const name = prompt("Warehouse name?");
    if (!name) return;
    await api.inventory.warehouses.create(selectedWorkspaceId, name);
    refreshAll();
  }

  async function createProduct() {
    if (!selectedWorkspaceId) return;
    const sku = prompt("SKU?");
    if (!sku) return;
    const name = prompt("Product name?") || sku;
    const unitCost = Number(prompt("Unit cost?", "10") || 0);
    const unitPrice = Number(prompt("Unit price?", "20") || 0);
    const reorderPoint = Number(prompt("Reorder point (trigger reorder at/below this qty)?", "20") || 0);
    const safetyStock = Number(prompt("Safety stock?", "5") || 0);
    await api.inventory.products.create(selectedWorkspaceId, {
      sku, name, unit_cost: unitCost, unit_price: unitPrice, reorder_point: reorderPoint, safety_stock: safetyStock,
    });
    refreshAll();
  }

  async function createPurchaseOrder() {
    if (!selectedWorkspaceId || suppliers.length === 0 || products.length === 0) return;
    const supplierId = suppliers[0].id;
    const product = products[0];
    const quantity = Number(prompt(`Quantity of '${product.name}' to order from '${suppliers[0].name}'?`, "50") || 0);
    if (!quantity) return;
    await api.inventory.purchaseOrders.create(selectedWorkspaceId, supplierId, [
      { product_id: product.id, quantity, unit_cost: product.unit_cost },
    ]);
    refreshAll();
  }

  async function receivePurchaseOrder(poId: string) {
    if (!selectedWorkspaceId || warehouses.length === 0) return;
    await api.inventory.purchaseOrders.receive(selectedWorkspaceId, poId, warehouses[0].id);
    refreshAll();
  }

  async function createSalesOrder() {
    if (!selectedWorkspaceId || warehouses.length === 0 || products.length === 0) return;
    const customerName = prompt("Customer name?");
    if (!customerName) return;
    const product = products[0];
    const quantity = Number(prompt(`Quantity of '${product.name}' sold?`, "10") || 0);
    if (!quantity) return;
    await api.inventory.salesOrders.create(selectedWorkspaceId, customerName, warehouses[0].id, [
      { product_id: product.id, quantity, unit_price: product.unit_price },
    ]);
    refreshAll();
  }

  async function fulfillSalesOrder(soId: string) {
    if (!selectedWorkspaceId) return;
    await api.inventory.salesOrders.fulfill(selectedWorkspaceId, soId);
    refreshAll();
  }

  const tabClass = (t: Tab) =>
    `rounded-lg px-3 py-1.5 text-sm font-medium ${tab === t ? "bg-brand-500 text-white" : "text-slate-600 hover:bg-slate-100"}`;

  return (
    <div className="mx-auto max-w-5xl px-6 py-8">
      <AppNav />

      {!selectedWorkspaceId && (
        <p className="text-sm text-slate-500">Select a workspace on the Dashboards page first.</p>
      )}

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>
      )}

      {selectedWorkspaceId && (
        <>
          <div className="mb-6 flex gap-2">
            <button onClick={() => setTab("products")} className={tabClass("products")}>
              Products & Setup
            </button>
            <button onClick={() => setTab("orders")} className={tabClass("orders")}>
              Orders
            </button>
            <button onClick={() => setTab("kpis")} className={tabClass("kpis")}>
              KPIs
            </button>
          </div>

          {tab === "products" && (
            <div className="space-y-6">
              <section className="rounded-xl border border-slate-200 bg-white p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-medium text-slate-700">Suppliers</h2>
                  <button onClick={createSupplier} className="text-xs font-medium text-brand-500 hover:underline">
                    + New
                  </button>
                </div>
                <ul className="text-sm text-slate-600">
                  {suppliers.map((s) => (
                    <li key={s.id} className="border-b border-slate-100 py-1">
                      {s.name} <span className="text-slate-400">— {s.lead_time_days}d lead time</span>
                    </li>
                  ))}
                  {suppliers.length === 0 && <p className="text-slate-400">No suppliers yet.</p>}
                </ul>
              </section>

              <section className="rounded-xl border border-slate-200 bg-white p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-medium text-slate-700">Warehouses</h2>
                  <button onClick={createWarehouse} className="text-xs font-medium text-brand-500 hover:underline">
                    + New
                  </button>
                </div>
                <ul className="text-sm text-slate-600">
                  {warehouses.map((w) => (
                    <li key={w.id} className="border-b border-slate-100 py-1">
                      {w.name}
                    </li>
                  ))}
                  {warehouses.length === 0 && <p className="text-slate-400">No warehouses yet.</p>}
                </ul>
              </section>

              <section className="rounded-xl border border-slate-200 bg-white p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-medium text-slate-700">Products</h2>
                  <button onClick={createProduct} className="text-xs font-medium text-brand-500 hover:underline">
                    + New
                  </button>
                </div>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-left text-slate-500">
                      <th className="py-1 pr-3">SKU</th>
                      <th className="py-1 pr-3">Name</th>
                      <th className="py-1 pr-3">Unit cost</th>
                      <th className="py-1 pr-3">Unit price</th>
                      <th className="py-1">Reorder point</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((p) => (
                      <tr key={p.id} className="border-b border-slate-100">
                        <td className="py-1 pr-3">{p.sku}</td>
                        <td className="py-1 pr-3">{p.name}</td>
                        <td className="py-1 pr-3">{p.unit_cost.toFixed(2)}</td>
                        <td className="py-1 pr-3">{p.unit_price.toFixed(2)}</td>
                        <td className="py-1">{p.reorder_point}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {products.length === 0 && <p className="mt-2 text-sm text-slate-400">No products yet.</p>}
              </section>
            </div>
          )}

          {tab === "orders" && (
            <div className="space-y-6">
              <section className="rounded-xl border border-slate-200 bg-white p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-medium text-slate-700">Purchase orders</h2>
                  <button
                    onClick={createPurchaseOrder}
                    disabled={suppliers.length === 0 || products.length === 0}
                    className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
                  >
                    + New (first supplier/product)
                  </button>
                </div>
                <ul className="text-sm text-slate-600">
                  {purchaseOrders.map((po) => (
                    <li key={po.id} className="flex items-center justify-between border-b border-slate-100 py-2">
                      <span>
                        PO {po.id.slice(0, 8)} — {po.lines.length} line(s) — <span className="font-medium">{po.status}</span>
                      </span>
                      {po.status !== "received" && (
                        <button
                          onClick={() => receivePurchaseOrder(po.id)}
                          disabled={warehouses.length === 0}
                          className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
                        >
                          Receive into {warehouses[0]?.name ?? "..."}
                        </button>
                      )}
                    </li>
                  ))}
                  {purchaseOrders.length === 0 && <p className="text-slate-400">No purchase orders yet.</p>}
                </ul>
              </section>

              <section className="rounded-xl border border-slate-200 bg-white p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-medium text-slate-700">Sales orders</h2>
                  <button
                    onClick={createSalesOrder}
                    disabled={warehouses.length === 0 || products.length === 0}
                    className="text-xs font-medium text-brand-500 hover:underline disabled:opacity-40"
                  >
                    + New (first product/warehouse)
                  </button>
                </div>
                <ul className="text-sm text-slate-600">
                  {salesOrders.map((so) => (
                    <li key={so.id} className="flex items-center justify-between border-b border-slate-100 py-2">
                      <span>
                        {so.customer_name} — {so.lines.length} line(s) — <span className="font-medium">{so.status}</span>
                      </span>
                      {so.status !== "fulfilled" && (
                        <button
                          onClick={() => fulfillSalesOrder(so.id)}
                          className="text-xs font-medium text-brand-500 hover:underline"
                        >
                          Fulfill
                        </button>
                      )}
                    </li>
                  ))}
                  {salesOrders.length === 0 && <p className="text-slate-400">No sales orders yet.</p>}
                </ul>
              </section>
            </div>
          )}

          {tab === "kpis" && (
            <div className="space-y-6">
              <section className="rounded-xl border border-slate-200 bg-white p-4">
                <h2 className="mb-3 text-sm font-medium text-slate-700">Inventory value</h2>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-left text-slate-500">
                      <th className="py-1 pr-3">Product</th>
                      <th className="py-1 pr-3">Warehouse</th>
                      <th className="py-1 pr-3">Qty on hand</th>
                      <th className="py-1">Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inventoryValue.map((row, i) => (
                      <tr key={i} className="border-b border-slate-100">
                        <td className="py-1 pr-3">{products.find((p) => p.id === row.product_id)?.name ?? row.product_id}</td>
                        <td className="py-1 pr-3">{warehouses.find((w) => w.id === row.warehouse_id)?.name ?? row.warehouse_id}</td>
                        <td className="py-1 pr-3">{row.quantity_on_hand}</td>
                        <td className="py-1">{row.inventory_value.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {inventoryValue.length === 0 && <p className="mt-2 text-sm text-slate-400">No stock movements yet.</p>}
              </section>

              <section className="rounded-xl border border-slate-200 bg-white p-4">
                <h2 className="mb-3 text-sm font-medium text-slate-700">ABC analysis (trailing 365 days of sales)</h2>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-left text-slate-500">
                      <th className="py-1 pr-3">Product</th>
                      <th className="py-1 pr-3">Usage value</th>
                      <th className="py-1 pr-3">Cumulative %</th>
                      <th className="py-1">Class</th>
                    </tr>
                  </thead>
                  <tbody>
                    {abcAnalysis.map((row, i) => (
                      <tr key={i} className="border-b border-slate-100">
                        <td className="py-1 pr-3">{products.find((p) => p.id === row.product_id)?.name ?? row.product_id}</td>
                        <td className="py-1 pr-3">{row.annual_usage_value.toFixed(2)}</td>
                        <td className="py-1 pr-3">{row.cumulative_pct}%</td>
                        <td className="py-1">
                          <span
                            className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                              row.product_class === "A"
                                ? "bg-emerald-100 text-emerald-700"
                                : row.product_class === "B"
                                ? "bg-amber-100 text-amber-700"
                                : "bg-slate-100 text-slate-600"
                            }`}
                          >
                            {row.product_class}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {abcAnalysis.length === 0 && <p className="mt-2 text-sm text-slate-400">No sales history yet.</p>}
              </section>

              <section className="rounded-xl border border-slate-200 bg-white p-4">
                <h2 className="mb-3 text-sm font-medium text-slate-700">Reorder suggestions</h2>
                <ul className="text-sm">
                  {reorderSuggestions.map((s, i) => (
                    <li key={i} className="flex justify-between border-b border-slate-100 py-2">
                      <span>{products.find((p) => p.id === s.product_id)?.name ?? s.product_id}</span>
                      <span className="text-slate-500">
                        {s.quantity_on_hand} on hand (reorder at {s.reorder_point}) → order{" "}
                        <span className="font-medium text-slate-700">{s.suggested_order_quantity}</span>
                      </span>
                    </li>
                  ))}
                  {reorderSuggestions.length === 0 && (
                    <p className="text-slate-400">Nothing below its reorder point right now.</p>
                  )}
                </ul>
              </section>
            </div>
          )}
        </>
      )}
    </div>
  );
}
