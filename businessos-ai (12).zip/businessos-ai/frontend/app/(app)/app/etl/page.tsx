"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import ReactFlow, { Background, Controls, Edge, Node } from "reactflow";
import "reactflow/dist/style.css";
import { api, Dataset, Pipeline, PipelineNode, PipelineRun } from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { AppNav } from "@/components/AppNav";

const NODE_TYPES: PipelineNode["type"][] = [
  "source",
  "filter",
  "select_columns",
  "rename",
  "derive",
  "aggregate",
  "sort",
  "dedupe",
  "clean",
  "join",
  "append",
  "pivot",
  "unpivot",
  "normalize",
];

function newNodeId() {
  return `node_${Math.random().toString(36).slice(2, 9)}`;
}

/** Builds a minimal, valid default config for each node type so a new node runs without editing. */
function defaultConfigFor(type: PipelineNode["type"], firstDatasetId?: string): Record<string, unknown> {
  switch (type) {
    case "source":
      return { dataset_id: firstDatasetId ?? "" };
    case "filter":
      return { column: "", operator: "gt", value: "" };
    case "select_columns":
      return { columns: [] };
    case "rename":
      return { mapping: {} };
    case "derive":
      return { new_column: "", left_column: "", operator: "add", right: "" };
    case "aggregate":
      return { group_by: [], aggregations: [] };
    case "sort":
      return { column: "", ascending: true };
    case "dedupe":
      return { columns: [] };
    case "clean":
      return { dropna_columns: [], fill_columns: [], fill_value: null };
    case "join":
      return { right_dataset_id: "", left_on: "", right_on: "", how: "inner" };
    case "append":
      return { other_dataset_id: "", dedupe: false };
    case "pivot":
      return { index: [], columns: "", values: "", agg: "sum" };
    case "unpivot":
      return { id_vars: [], value_vars: [], var_name: "variable", value_name: "value" };
    case "normalize":
      return { columns: [], method: "minmax" };
    default:
      return {};
  }
}

export default function EtlPage() {
  const router = useRouter();
  const { token, setToken, selectedWorkspaceId } = useAppStore();

  const [pipelines, setPipelines] = useState<Pipeline[]>([]);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [selectedPipelineId, setSelectedPipelineId] = useState<string | null>(null);
  const [nodes, setNodes] = useState<PipelineNode[]>([]);
  const [pipelineName, setPipelineName] = useState("");
  const [runs, setRuns] = useState<PipelineRun[]>([]);
  const [selectedRun, setSelectedRun] = useState<PipelineRun | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  useEffect(() => {
    if (!selectedWorkspaceId) return;
    api.pipelines.list(selectedWorkspaceId).then(setPipelines).catch((e) => setError(e.message));
    api.datasets.list(selectedWorkspaceId).then(setDatasets).catch((e) => setError(e.message));
  }, [selectedWorkspaceId]);

  const selectedPipeline = useMemo(
    () => pipelines.find((p) => p.id === selectedPipelineId) ?? null,
    [pipelines, selectedPipelineId]
  );

  useEffect(() => {
    if (selectedPipeline) {
      setNodes(selectedPipeline.nodes);
      setPipelineName(selectedPipeline.name);
      if (selectedWorkspaceId) {
        api.pipelines.listRuns(selectedWorkspaceId, selectedPipeline.id).then(setRuns).catch(() => {});
      }
    } else {
      setNodes([]);
      setPipelineName("");
      setRuns([]);
    }
    setSelectedRun(null);
  }, [selectedPipeline, selectedWorkspaceId]);

  async function createPipeline() {
    if (!selectedWorkspaceId) return;
    const name = prompt("Pipeline name?");
    if (!name) return;
    const sourceNode: PipelineNode = {
      id: newNodeId(),
      type: "source",
      config: defaultConfigFor("source", datasets[0]?.id),
    };
    const pipeline = await api.pipelines.create(selectedWorkspaceId, name, [sourceNode]);
    setPipelines((prev) => [...prev, pipeline]);
    setSelectedPipelineId(pipeline.id);
  }

  function addNode(type: PipelineNode["type"]) {
    setNodes((prev) => [...prev, { id: newNodeId(), type, config: defaultConfigFor(type, datasets[0]?.id) }]);
  }

  function updateNodeConfig(nodeId: string, config: Record<string, unknown>) {
    setNodes((prev) => prev.map((n) => (n.id === nodeId ? { ...n, config } : n)));
  }

  function removeNode(nodeId: string) {
    setNodes((prev) => prev.filter((n) => n.id !== nodeId));
  }

  async function savePipeline() {
    if (!selectedWorkspaceId || !selectedPipelineId) return;
    try {
      const updated = await api.pipelines.update(selectedWorkspaceId, selectedPipelineId, {
        name: pipelineName,
        nodes,
      });
      setPipelines((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    }
  }

  async function runPipeline() {
    if (!selectedWorkspaceId || !selectedPipelineId) return;
    const outputName = prompt("Name for the output dataset?", `${pipelineName}_output`);
    if (!outputName) return;
    setRunning(true);
    setError(null);
    try {
      await savePipeline();
      const run = await api.pipelines.run(selectedWorkspaceId, selectedPipelineId, outputName);
      setSelectedRun(run);
      const updatedRuns = await api.pipelines.listRuns(selectedWorkspaceId, selectedPipelineId);
      setRuns(updatedRuns);
      if (run.status === "success") {
        const updatedDatasets = await api.datasets.list(selectedWorkspaceId);
        setDatasets(updatedDatasets);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Run failed");
    } finally {
      setRunning(false);
    }
  }

  // ---- ReactFlow canvas (visual, read-only preview of the linear chain) ----
  const flowNodes: Node[] = nodes.map((n, i) => ({
    id: n.id,
    position: { x: 0, y: i * 90 },
    data: { label: `${i + 1}. ${n.type}` },
    style: {
      border: "1px solid #cbd5e1",
      borderRadius: 8,
      padding: 8,
      background: "white",
      width: 200,
      fontSize: 12,
    },
  }));
  const flowEdges: Edge[] = nodes.slice(1).map((n, i) => ({
    id: `${nodes[i].id}-${n.id}`,
    source: nodes[i].id,
    target: n.id,
  }));

  const onNodesChangeNoop = useCallback(() => {}, []);

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <AppNav />

      {!selectedWorkspaceId && (
        <p className="text-sm text-slate-500">Select a workspace on the Dashboards page first.</p>
      )}

      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>
      )}

      {selectedWorkspaceId && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr]">
          <aside className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-medium text-slate-700">Pipelines</h2>
              <button onClick={createPipeline} className="text-xs font-medium text-brand-500 hover:underline">
                + New
              </button>
            </div>
            <ul className="space-y-1">
              {pipelines.map((p) => (
                <li key={p.id}>
                  <button
                    onClick={() => setSelectedPipelineId(p.id)}
                    className={`w-full rounded-lg px-2 py-1.5 text-left text-sm ${
                      p.id === selectedPipelineId ? "bg-brand-50 text-brand-600" : "text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    {p.name}
                  </button>
                </li>
              ))}
              {pipelines.length === 0 && <p className="text-sm text-slate-400">No pipelines yet.</p>}
            </ul>
          </aside>

          <main className="space-y-6">
            {selectedPipeline ? (
              <>
                <section className="rounded-xl border border-slate-200 bg-white p-4">
                  <div className="mb-3 flex flex-wrap items-center gap-3">
                    <input
                      value={pipelineName}
                      onChange={(e) => setPipelineName(e.target.value)}
                      className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-medium"
                    />
                    <button
                      onClick={savePipeline}
                      className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                    >
                      Save
                    </button>
                    <button
                      onClick={runPipeline}
                      disabled={running}
                      className="rounded-lg bg-brand-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-brand-600 disabled:opacity-50"
                    >
                      {running ? "Running..." : "Run pipeline"}
                    </button>
                    <div className="ml-auto flex flex-wrap gap-1">
                      {NODE_TYPES.filter((t) => t !== "source").map((t) => (
                        <button
                          key={t}
                          onClick={() => addNode(t)}
                          className="rounded-full border border-slate-200 px-2.5 py-1 text-xs text-slate-600 hover:border-brand-500 hover:text-brand-500"
                        >
                          + {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4 h-64 rounded-lg border border-slate-100 bg-slate-50">
                    <ReactFlow
                      nodes={flowNodes}
                      edges={flowEdges}
                      onNodesChange={onNodesChangeNoop}
                      fitView
                      nodesDraggable={false}
                      nodesConnectable={false}
                    >
                      <Background />
                      <Controls showInteractive={false} />
                    </ReactFlow>
                  </div>

                  <div className="space-y-3">
                    {nodes.map((node, i) => (
                      <NodeEditor
                        key={node.id}
                        index={i}
                        node={node}
                        datasets={datasets}
                        onChange={(config) => updateNodeConfig(node.id, config)}
                        onRemove={() => removeNode(node.id)}
                      />
                    ))}
                  </div>
                </section>

                <section className="rounded-xl border border-slate-200 bg-white p-4">
                  <h2 className="mb-3 text-sm font-medium text-slate-700">Run history</h2>
                  {runs.length === 0 ? (
                    <p className="text-sm text-slate-400">No runs yet.</p>
                  ) : (
                    <div className="flex gap-4">
                      <ul className="w-48 shrink-0 space-y-1">
                        {runs.map((r) => (
                          <li key={r.id}>
                            <button
                              onClick={() => setSelectedRun(r)}
                              className={`w-full rounded-lg px-2 py-1.5 text-left text-xs ${
                                selectedRun?.id === r.id ? "bg-brand-50 text-brand-600" : "hover:bg-slate-50"
                              }`}
                            >
                              <span
                                className={`mr-1.5 inline-block h-2 w-2 rounded-full ${
                                  r.status === "success"
                                    ? "bg-emerald-500"
                                    : r.status === "failed"
                                    ? "bg-red-500"
                                    : "bg-amber-500"
                                }`}
                              />
                              {r.started_at?.slice(0, 19).replace("T", " ") ?? "pending"}
                            </button>
                          </li>
                        ))}
                      </ul>
                      {selectedRun && (
                        <div className="flex-1 text-sm">
                          <p className="mb-2">
                            Status: <span className="font-medium">{selectedRun.status}</span>
                            {selectedRun.rows_processed != null && (
                              <span className="ml-3 text-slate-500">{selectedRun.rows_processed} rows</span>
                            )}
                          </p>
                          {selectedRun.error_message && (
                            <p className="mb-2 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">
                              {selectedRun.error_message}
                            </p>
                          )}
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="border-b border-slate-200 text-left text-slate-500">
                                <th className="py-1 pr-2">Node</th>
                                <th className="py-1 pr-2">Status</th>
                                <th className="py-1 pr-2">Rows</th>
                                <th className="py-1">Message</th>
                              </tr>
                            </thead>
                            <tbody>
                              {selectedRun.logs.map((log, i) => (
                                <tr key={i} className="border-b border-slate-100">
                                  <td className="py-1 pr-2">{log.node_type}</td>
                                  <td className="py-1 pr-2">{log.status}</td>
                                  <td className="py-1 pr-2">
                                    {log.rows_before ?? "-"} → {log.rows_after ?? "-"}
                                  </td>
                                  <td className="py-1 text-slate-500">{log.message}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}
                </section>
              </>
            ) : (
              <p className="text-sm text-slate-400">Select or create a pipeline to start building.</p>
            )}
          </main>
        </div>
      )}
    </div>
  );
}

/**
 * Renders a small config form per node type. Falls back to a raw JSON textarea
 * for anything not covered — keeps the builder usable without blocking on every
 * possible config shape being hand-crafted into a form.
 */
function NodeEditor({
  index,
  node,
  datasets,
  onChange,
  onRemove,
}: {
  index: number;
  node: PipelineNode;
  datasets: Dataset[];
  onChange: (config: Record<string, unknown>) => void;
  onRemove: () => void;
}) {
  const [rawJson, setRawJson] = useState(JSON.stringify(node.config, null, 2));
  const [jsonError, setJsonError] = useState<string | null>(null);

  useEffect(() => {
    setRawJson(JSON.stringify(node.config, null, 2));
  }, [node.id]);

  function applyRawJson() {
    try {
      onChange(JSON.parse(rawJson));
      setJsonError(null);
    } catch {
      setJsonError("Invalid JSON");
    }
  }

  return (
    <div className="rounded-lg border border-slate-200 p-3">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-sm font-medium text-slate-700">
          {index + 1}. {node.type}
        </p>
        {node.type !== "source" && (
          <button onClick={onRemove} className="text-xs text-slate-400 hover:text-red-500">
            remove
          </button>
        )}
      </div>

      {node.type === "source" ? (
        <select
          value={(node.config.dataset_id as string) ?? ""}
          onChange={(e) => onChange({ dataset_id: e.target.value })}
          className="w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs"
        >
          <option value="">Select source dataset...</option>
          {datasets.map((d) => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </select>
      ) : (
        <div>
          <textarea
            value={rawJson}
            onChange={(e) => setRawJson(e.target.value)}
            onBlur={applyRawJson}
            rows={3}
            className="w-full rounded-lg border border-slate-300 px-2 py-1.5 font-mono text-xs"
          />
          {jsonError && <p className="mt-1 text-xs text-red-600">{jsonError}</p>}
          <p className="mt-1 text-xs text-slate-400">
            Edit the config JSON directly (e.g. {'{'}"column": "revenue", "operator": "gt", "value": 100{'}'} for filter).
          </p>
        </div>
      )}
    </div>
  );
}
