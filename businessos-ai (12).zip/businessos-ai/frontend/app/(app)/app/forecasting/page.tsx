"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import ReactECharts from "echarts-for-react";
import { api, Dataset, ForecastResponse } from "@/lib/api/client";
import { useAppStore } from "@/lib/store";
import { AppNav } from "@/components/AppNav";

export default function ForecastingPage() {
  const router = useRouter();
  const { token, setToken, selectedWorkspaceId } = useAppStore();

  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<string | null>(null);
  const [dateColumn, setDateColumn] = useState("");
  const [metricColumn, setMetricColumn] = useState("");
  const [periods, setPeriods] = useState(6);
  const [freq, setFreq] = useState<"D" | "W" | "M">("M");
  const [result, setResult] = useState<ForecastResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("access_token") : null;
    if (!stored) {
      router.push("/login");
      return;
    }
    if (!token) setToken(stored);
  }, [token, setToken, router]);

  useEffect(() => {
    if (!selectedWorkspaceId) return;
    api.datasets.list(selectedWorkspaceId).then(setDatasets).catch((e) => setError(e.message));
  }, [selectedWorkspaceId]);

  async function runForecast() {
    if (!selectedWorkspaceId || !selectedDatasetId || !dateColumn || !metricColumn) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await api.forecasting.forecast(
        selectedWorkspaceId,
        selectedDatasetId,
        dateColumn,
        metricColumn,
        periods,
        freq
      );
      setResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Forecast failed");
    } finally {
      setLoading(false);
    }
  }

  const chartOption = result
    ? {
        tooltip: { trigger: "axis" },
        legend: { data: ["History", "Forecast"] },
        grid: { left: 50, right: 20, top: 40, bottom: 40 },
        xAxis: {
          type: "category",
          data: [...result.history.map((h) => h.period), ...result.forecast.map((f) => f.period)],
        },
        yAxis: { type: "value" },
        series: [
          {
            name: "History",
            type: "line",
            data: [...result.history.map((h) => h.value), ...result.forecast.map(() => null)],
            itemStyle: { color: "#3b5bfd" },
          },
          {
            name: "Forecast",
            type: "line",
            data: [...result.history.map(() => null), result.history[result.history.length - 1]?.value, ...result.forecast.map((f) => f.value)],
            lineStyle: { type: "dashed" },
            itemStyle: { color: "#f59e0b" },
          },
        ],
      }
    : null;

  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <AppNav />

      {!selectedWorkspaceId && (
        <p className="text-sm text-slate-500">Select a workspace on the Dashboards page first.</p>
      )}

      {selectedWorkspaceId && (
        <>
          <section className="mb-6 rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-medium text-slate-700">Forecast setup</h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <select
                value={selectedDatasetId ?? ""}
                onChange={(e) => setSelectedDatasetId(e.target.value || null)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="">Select dataset...</option>
                {datasets.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
              <select
                value={freq}
                onChange={(e) => setFreq(e.target.value as "D" | "W" | "M")}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="D">Daily</option>
                <option value="W">Weekly</option>
                <option value="M">Monthly</option>
              </select>
              <input
                value={dateColumn}
                onChange={(e) => setDateColumn(e.target.value)}
                placeholder="Date column name"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <input
                value={metricColumn}
                onChange={(e) => setMetricColumn(e.target.value)}
                placeholder="Metric column name (numeric)"
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <input
                type="number"
                min={1}
                max={60}
                value={periods}
                onChange={(e) => setPeriods(Number(e.target.value))}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <button
                onClick={runForecast}
                disabled={loading || !selectedDatasetId || !dateColumn || !metricColumn}
                className="rounded-lg bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-50"
              >
                {loading ? "Forecasting..." : "Run forecast"}
              </button>
            </div>
          </section>

          {error && (
            <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">
              {error}
            </div>
          )}

          {result && (
            <section className="rounded-xl border border-slate-200 bg-white p-4">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-sm font-medium text-slate-700">
                  Forecast ({result.method.replace("_", " ")})
                </h2>
              </div>
              {result.warning && (
                <p className="mb-3 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-700">{result.warning}</p>
              )}
              {chartOption && (
                <div className="h-72">
                  <ReactECharts option={chartOption} style={{ height: "100%", width: "100%" }} />
                </div>
              )}
            </section>
          )}
        </>
      )}
    </div>
  );
}
