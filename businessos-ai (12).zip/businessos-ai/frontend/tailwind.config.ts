import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f0f5ff",
          500: "#3b5bfd",
          600: "#2f47cc",
          900: "#131b3a",
        },
      },
    },
  },
  plugins: [],
};

export default config;
