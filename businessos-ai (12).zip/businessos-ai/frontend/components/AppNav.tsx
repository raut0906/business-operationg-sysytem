"use client";

import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useAppStore } from "@/lib/store";

export function AppNav() {
  const router = useRouter();
  const pathname = usePathname();
  const setToken = useAppStore((s) => s.setToken);

  function logout() {
    setToken(null);
    router.push("/login");
  }

  const linkClass = (href: string) =>
    `text-sm font-medium ${pathname === href ? "text-brand-500" : "text-slate-500 hover:text-slate-900"}`;

  return (
    <header className="mb-8 flex items-center justify-between">
      <div className="flex items-center gap-6">
        <h1 className="text-lg font-semibold text-slate-900">BusinessOS AI</h1>
        <nav className="flex gap-4">
          <Link href="/app" className={linkClass("/app")}>
            Dashboards
          </Link>
          <Link href="/app/connectors" className={linkClass("/app/connectors")}>
            Connectors
          </Link>
          <Link href="/app/semantic" className={linkClass("/app/semantic")}>
            Semantic Layer
          </Link>
          <Link href="/app/security" className={linkClass("/app/security")}>
            Security
          </Link>
          <Link href="/app/etl" className={linkClass("/app/etl")}>
            ETL Studio
          </Link>
          <Link href="/app/copilot" className={linkClass("/app/copilot")}>
            AI Copilot
          </Link>
          <Link href="/app/forecasting" className={linkClass("/app/forecasting")}>
            Forecasting
          </Link>
          <Link href="/app/ml" className={linkClass("/app/ml")}>
            ML Studio
          </Link>
          <Link href="/app/inventory" className={linkClass("/app/inventory")}>
            Inventory
          </Link>
        </nav>
      </div>
      <button onClick={logout} className="text-sm text-slate-500 hover:text-slate-900">
        Sign out
      </button>
    </header>
  );
}
