"use client";

import ReactECharts from "echarts-for-react";
import type { WidgetData } from "@/lib/api/client";

/**
 * Renders a single widget's data using the chart type stored on the widget.
 * New chart types plug in here by adding a case — this is the only place
 * that needs to know how to translate {dimension, value} rows into ECharts option objects.
 */
export function WidgetChart({ widget }: { widget: WidgetData }) {
  const categories = widget.data.map((d) => String(d.dimension));
  const values = widget.data.map((d) => d.value);

  if (widget.chart_type === "kpi") {
    const total = values.reduce((sum, v) => sum + v, 0);
    return (
      <div className="flex h-full flex-col items-center justify-center">
        <p className="text-3xl font-semibold text-slate-900">{total.toLocaleString()}</p>
        <p className="mt-1 text-sm text-slate-500">{widget.title}</p>
      </div>
    );
  }

  if (widget.chart_type === "table") {
    return (
      <div className="max-h-56 overflow-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left text-slate-500">
              <th className="py-1 pr-2">Dimension</th>
              <th className="py-1">Value</th>
            </tr>
          </thead>
          <tbody>
            {widget.data.map((row, i) => (
              <tr key={i} className="border-b border-slate-100">
                <td className="py-1 pr-2">{row.dimension}</td>
                <td className="py-1">{row.value.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  const option =
    widget.chart_type === "pie"
      ? {
          tooltip: { trigger: "item" },
          series: [
            {
              type: "pie",
              radius: "70%",
              data: widget.data.map((d) => ({ name: String(d.dimension), value: d.value })),
            },
          ],
        }
      : {
          tooltip: { trigger: "axis" },
          grid: { left: 40, right: 16, top: 16, bottom: 40 },
          xAxis: { type: "category", data: categories },
          yAxis: { type: "value" },
          series: [
            {
              type: widget.chart_type === "line" ? "line" : "bar",
              data: values,
              itemStyle: { color: "#3b5bfd" },
            },
          ],
        };

  return <ReactECharts option={option} style={{ height: "100%", width: "100%" }} />;
}
