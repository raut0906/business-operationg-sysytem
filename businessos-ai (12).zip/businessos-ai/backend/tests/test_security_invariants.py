"""
Architectural invariant test: RLS/CLS cannot be bypassed by a new domain
service calling duckdb_client's unfiltered-read functions directly.

This exists because that exact bug happened during development — six
separate services (forecasting, ML training, ETL, semantic layer, dataset
preview, alert evaluation) independently read the raw warehouse table
before this was caught by an explicit audit, not by any test. The worst of
the six (DatasetService.preview) was a direct, trivial bypass around the
entire secured-preview endpoint.

This test doesn't require a database, pandas, or any of the app's real
dependencies — it's static analysis over the source files themselves, so
it runs anywhere Python runs and stays cheap to keep in CI permanently.

Run directly: `python -m tests.test_security_invariants` (from backend/)
Run under pytest, if installed: `pytest tests/test_security_invariants.py`
"""
import re
from pathlib import Path

# Every duckdb_client function that reads warehouse rows without applying
# RLS/CLS. Only app/domain/security/service.py is allowed to call these —
# it's the one place the unfiltered read is supposed to happen, centrally,
# before SecurityService.get_secured_dataframe applies policies and hands
# a filtered/masked result to every other consumer.
UNFILTERED_READ_FUNCTIONS = [
    "load_full_table",
    "preview_table",
    "get_metric_value",
    "run_aggregate_query",
    "run_readonly_sql",
]

_BACKEND_ROOT = Path(__file__).resolve().parent.parent
_ALLOWED_CALLER = _BACKEND_ROOT / "app" / "domain" / "security" / "service.py"


def find_security_bypass_violations() -> list[str]:
    """Returns a list of human-readable violation descriptions; empty means the invariant holds."""
    violations = []
    domain_dir = _BACKEND_ROOT / "app" / "domain"
    for service_file in sorted(domain_dir.glob("*/service.py")):
        if service_file == _ALLOWED_CALLER:
            continue
        content = service_file.read_text()
        for func_name in UNFILTERED_READ_FUNCTIONS:
            if re.search(rf"duckdb_client\.{func_name}\b", content):
                relative_path = service_file.relative_to(_BACKEND_ROOT)
                violations.append(f"{relative_path} calls duckdb_client.{func_name}() directly, bypassing RLS/CLS")
    return violations


def test_no_domain_service_bypasses_security():
    violations = find_security_bypass_violations()
    assert not violations, (
        "Found domain service(s) reading warehouse data without going through "
        "SecurityService.get_secured_dataframe:\n" + "\n".join(f"  - {v}" for v in violations)
    )


if __name__ == "__main__":
    found = find_security_bypass_violations()
    if found:
        print("SECURITY INVARIANT VIOLATED:")
        for v in found:
            print(" -", v)
        raise SystemExit(1)
    print("PASS: no domain service bypasses RLS/CLS via a direct unfiltered duckdb_client call.")
