from pydantic import BaseModel


class CopilotAskRequest(BaseModel):
    dataset_id: str
    question: str


class CopilotAskResponse(BaseModel):
    question: str
    generated_sql: str
    explanation: str
    columns: list[str]
    rows: list[dict]


class CopilotSummaryRequest(BaseModel):
    dataset_id: str


class CopilotSummaryResponse(BaseModel):
    dataset_id: str
    summary: str


class CopilotChartSuggestion(BaseModel):
    chart_type: str
    dimension: str
    metric: str
    aggregate: str
    reasoning: str
