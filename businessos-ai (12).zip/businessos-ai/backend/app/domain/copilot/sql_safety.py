"""
Validates LLM-generated SQL before it ever touches the warehouse.

This is deliberately paranoid: the Copilot never executes AI output on a
writable connection, and this validator is a second line of defense on
top of that (belt and suspenders — DuckDB's read_only mode already blocks
writes at the engine level, but rejecting suspicious queries before
execution gives a clean error message instead of a raw DB exception, and
guards against read_only mode being misconfigured in some future change).
"""
import re

_FORBIDDEN_KEYWORDS = [
    "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", "ATTACH",
    "DETACH", "COPY", "PRAGMA", "EXPORT", "IMPORT", "CALL", "GRANT",
    "REVOKE", "TRUNCATE", "REPLACE", "VACUUM", "INSTALL", "LOAD",
]

_MAX_QUERY_LENGTH = 4000
_DEFAULT_ROW_LIMIT = 500


class UnsafeQueryError(Exception):
    pass


def validate_and_prepare(sql: str, allowed_table: str) -> str:
    """
    Raises UnsafeQueryError if the query looks unsafe. Otherwise returns the
    query with a LIMIT clause appended if the model didn't include one.
    """
    if not sql or not sql.strip():
        raise UnsafeQueryError("Empty query")

    cleaned = sql.strip().rstrip(";")

    if len(cleaned) > _MAX_QUERY_LENGTH:
        raise UnsafeQueryError("Query is unexpectedly long — refusing to execute")

    if ";" in cleaned:
        raise UnsafeQueryError("Multiple statements are not allowed")

    if not re.match(r"^\s*SELECT\b", cleaned, re.IGNORECASE):
        raise UnsafeQueryError("Only SELECT queries are allowed")

    upper = cleaned.upper()
    for keyword in _FORBIDDEN_KEYWORDS:
        if re.search(rf"\b{keyword}\b", upper):
            raise UnsafeQueryError(f"Query contains a disallowed keyword: {keyword}")

    # The model is only ever told about one table; if it references anything
    # else (or tries to reach another workspace's data), reject it outright.
    table_pattern = re.compile(r"\bFROM\s+[\"']?([a-zA-Z0-9_]+)[\"']?", re.IGNORECASE)
    referenced_tables = table_pattern.findall(cleaned)
    for table in referenced_tables:
        if table.lower() != allowed_table.lower():
            raise UnsafeQueryError(f"Query references an unexpected table: '{table}'")

    if not re.search(r"\bLIMIT\b", upper):
        cleaned = f"{cleaned} LIMIT {_DEFAULT_ROW_LIMIT}"

    return cleaned
