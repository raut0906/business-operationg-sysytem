from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.copilot.schemas import (
    CopilotAskRequest,
    CopilotAskResponse,
    CopilotChartSuggestion,
    CopilotSummaryResponse,
)
from app.domain.copilot.service import CopilotService
from app.infrastructure.ai_gateway import AIGateway, get_ai_gateway
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/copilot", tags=["copilot"])


@router.post("/ask", response_model=CopilotAskResponse)
def ask(
    workspace_id: str,
    payload: CopilotAskRequest,
    db: Session = Depends(get_db),
    gateway: AIGateway = Depends(get_ai_gateway),
    current_user: User = Depends(get_current_user),
):
    result = CopilotService(db, gateway).ask(workspace_id, payload.dataset_id, payload.question, current_user.id)
    return CopilotAskResponse(**result)


@router.get("/summary/{dataset_id}", response_model=CopilotSummaryResponse)
def summary(
    workspace_id: str,
    dataset_id: str,
    db: Session = Depends(get_db),
    gateway: AIGateway = Depends(get_ai_gateway),
    current_user: User = Depends(get_current_user),
):
    text = CopilotService(db, gateway).summarize(workspace_id, dataset_id, current_user.id)
    return CopilotSummaryResponse(dataset_id=dataset_id, summary=text)


@router.get("/chart-suggestion/{dataset_id}", response_model=CopilotChartSuggestion)
def chart_suggestion(
    workspace_id: str,
    dataset_id: str,
    db: Session = Depends(get_db),
    gateway: AIGateway = Depends(get_ai_gateway),
    current_user: User = Depends(get_current_user),
):
    return CopilotService(db, gateway).suggest_chart(workspace_id, dataset_id, current_user.id)
