"""
AI Copilot service.

Every method here follows the same shape: build a tightly-scoped prompt
(schema + question, nothing else about the workspace), call the AI Gateway,
then treat the response as untrusted input — SQL goes through
sql_safety.validate_and_prepare before ever touching data, and chart
suggestions are validated against an allowlist of real column names and
chart types before being returned.

RLS/CLS enforcement: every method here operates on a security-filtered
DataFrame from SecurityService.get_secured_dataframe rather than the raw
warehouse table — hidden columns are never mentioned in prompts (so the AI
can't reference them), and generated SQL executes via
duckdb_client.run_sql_on_dataframe against an in-memory copy of the
already-filtered data, never the persisted warehouse file. A Viewer with
row/column restrictions gets restricted answers from Copilot, not just
from the secured-preview endpoint.
"""
import json
import re

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.copilot.schemas import CopilotChartSuggestion
from app.domain.copilot.sql_safety import UnsafeQueryError, validate_and_prepare
from app.domain.datasets.service import DatasetService
from app.infrastructure import duckdb_client
from app.infrastructure.ai_gateway import AIGateway, require_configured_gateway

_SQL_SYSTEM_PROMPT = (
    "You are a SQL generator for a DuckDB analytics warehouse. Given a table schema and a "
    "natural language question, output ONLY a single valid DuckDB SELECT statement that answers "
    "the question. Do not include explanations, markdown formatting, or code fences. Do not use "
    "any table other than the one described. Never write INSERT, UPDATE, DELETE, DROP, ALTER, or "
    "any other statement besides SELECT."
)

_CHART_SYSTEM_PROMPT = (
    "You choose the best chart type and column mapping to visualize a dataset for a business "
    "dashboard. Respond with ONLY a JSON object of the exact shape: "
    '{"chart_type": "bar|line|pie|table|kpi", "dimension": "<column name>", '
    '"metric": "<column name>", "aggregate": "SUM|AVG|COUNT|MIN|MAX", "reasoning": "<one sentence>"}. '
    "No markdown, no extra text."
)


def _strip_code_fences(text: str) -> str:
    """LLMs frequently wrap output in ```sql ... ``` or ```json ... ``` despite instructions not to."""
    cleaned = text.strip()
    cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", cleaned)
    cleaned = re.sub(r"\n?```$", "", cleaned)
    return cleaned.strip()


def _schema_description_from_df(df) -> str:
    return ", ".join(f"{col} ({dtype})" for col, dtype in df.dtypes.items())


class CopilotService:
    def __init__(self, db: Session, gateway: AIGateway):
        self.db = db
        self.gateway = gateway

    def _get_secured_dataset_df(self, workspace_id: str, dataset_id: str, user_id: str):
        # Local import: same circular-import-avoidance reasoning as dashboards/service.py.
        from app.domain.security.service import SecurityService

        dataset = DatasetService(self.db).get_or_404(dataset_id, workspace_id, user_id)
        df, _applied, _hidden = SecurityService(self.db).get_secured_dataframe(dataset_id, workspace_id, user_id)
        return dataset, df

    def ask(self, workspace_id: str, dataset_id: str, question: str, user_id: str) -> dict:
        require_configured_gateway(self.gateway)
        dataset, df = self._get_secured_dataset_df(workspace_id, dataset_id, user_id)

        schema_desc = _schema_description_from_df(df)
        user_prompt = (
            f"Table name: {dataset.warehouse_table_name}\n"
            f"Columns: {schema_desc}\n\n"
            f"Question: {question}"
        )

        raw_sql = self.gateway.complete(_SQL_SYSTEM_PROMPT, user_prompt, max_tokens=300)
        candidate_sql = _strip_code_fences(raw_sql)

        try:
            safe_sql = validate_and_prepare(candidate_sql, dataset.warehouse_table_name)
        except UnsafeQueryError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"AI generated an unsafe or invalid query, refused to execute: {exc}",
            ) from exc

        try:
            # Runs against the in-memory, already-security-filtered DataFrame — the
            # persisted warehouse file is never opened for this query.
            result = duckdb_client.run_sql_on_dataframe(df, dataset.warehouse_table_name, safe_sql)
        except Exception as exc:  # DuckDB raises its own exception types for bad SQL
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Generated query failed to execute: {exc}",
            ) from exc

        return {
            "question": question,
            "generated_sql": safe_sql,
            "explanation": f"Generated and executed a read-only query against '{dataset.name}' (with your role's security policies applied).",
            "columns": result["columns"],
            "rows": result["rows"],
        }

    def summarize(self, workspace_id: str, dataset_id: str, user_id: str) -> str:
        require_configured_gateway(self.gateway)
        dataset, df = self._get_secured_dataset_df(workspace_id, dataset_id, user_id)

        schema_desc = _schema_description_from_df(df)
        sample_rows = df.head(20).to_dict(orient="records")

        system_prompt = (
            "You are a business analyst. Write a concise 3-5 sentence executive summary of the "
            "dataset described below, in plain English, for a non-technical audience. Do not "
            "invent numbers you cannot see in the sample provided — describe structure and "
            "notable patterns in the sample, not precise totals."
        )
        user_prompt = (
            f"Dataset: {dataset.name}\nRow count (visible to you): {len(df)}\nColumns: {schema_desc}\n"
            f"Sample rows (first {len(sample_rows)}): {json.dumps(sample_rows, default=str)}"
        )
        return self.gateway.complete(system_prompt, user_prompt, max_tokens=400).strip()

    def suggest_chart(self, workspace_id: str, dataset_id: str, user_id: str) -> CopilotChartSuggestion:
        require_configured_gateway(self.gateway)
        _dataset, df = self._get_secured_dataset_df(workspace_id, dataset_id, user_id)

        column_names = set(df.columns)
        schema_desc = _schema_description_from_df(df)

        raw = self.gateway.complete(_CHART_SYSTEM_PROMPT, f"Columns: {schema_desc}", max_tokens=200)
        try:
            parsed = json.loads(_strip_code_fences(raw))
        except json.JSONDecodeError as exc:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"AI returned a non-JSON chart suggestion: {raw[:200]}",
            ) from exc

        # Validate every field against known-good values before trusting it — the model's JSON
        # could hallucinate a column that doesn't exist or an unsupported chart type. Checking
        # against `column_names` (already CLS-filtered) also means a hidden column can never be
        # suggested, since it was never in the schema description the model saw in the first place.
        if parsed.get("chart_type") not in {"bar", "line", "pie", "table", "kpi"}:
            raise HTTPException(status.HTTP_502_BAD_GATEWAY, detail="AI suggested an unsupported chart type")
        if parsed.get("dimension") not in column_names or parsed.get("metric") not in column_names:
            raise HTTPException(status.HTTP_502_BAD_GATEWAY, detail="AI suggested a column that doesn't exist")
        if parsed.get("aggregate") not in {"SUM", "AVG", "COUNT", "MIN", "MAX"}:
            raise HTTPException(status.HTTP_502_BAD_GATEWAY, detail="AI suggested an unsupported aggregate")

        return CopilotChartSuggestion(**parsed)
