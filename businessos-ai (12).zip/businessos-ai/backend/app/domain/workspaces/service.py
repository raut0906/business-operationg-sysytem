import re

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.organizations.service import OrganizationService
from app.domain.shared.rbac import Role
from app.domain.workspaces.models import Workspace, WorkspaceMembership
from app.domain.workspaces.schemas import WorkspaceCreate


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "workspace"


class WorkspaceService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, org_id: str, payload: WorkspaceCreate, creator_user_id: str) -> Workspace:
        # Ensures caller is at least an editor in the parent org before allowing workspace creation.
        membership = OrganizationService(self.db).get_membership(org_id, creator_user_id)
        if membership.role < Role.EDITOR:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient org role")

        workspace = Workspace(org_id=org_id, name=payload.name, slug=_slugify(payload.name))
        self.db.add(workspace)
        self.db.flush()

        self.db.add(WorkspaceMembership(workspace_id=workspace.id, user_id=creator_user_id, role=Role.OWNER))
        self.db.commit()
        self.db.refresh(workspace)
        return workspace

    def list_for_org(self, org_id: str, user_id: str) -> list[Workspace]:
        OrganizationService(self.db).get_membership(org_id, user_id)  # raises 403 if not a member
        return self.db.query(Workspace).filter(Workspace.org_id == org_id).all()

    def get_membership_or_403(self, workspace_id: str, user_id: str) -> WorkspaceMembership:
        membership = (
            self.db.query(WorkspaceMembership)
            .filter(
                WorkspaceMembership.workspace_id == workspace_id,
                WorkspaceMembership.user_id == user_id,
            )
            .first()
        )
        if not membership:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of this workspace")
        return membership

    def require_role(self, workspace_id: str, user_id: str, min_role: Role) -> WorkspaceMembership:
        """
        The single enforcement point for role-based access control across every
        domain in the app: confirms membership AND that the member's role meets
        or exceeds min_role, raising 403 with a clear message otherwise. Every
        domain service should call this (not get_membership_or_403 alone) for
        any action that creates, modifies, or deletes data — get_membership_or_403
        remains appropriate for pure reads, where any workspace member (including
        Viewer) is allowed.
        """
        membership = self.get_membership_or_403(workspace_id, user_id)
        if membership.role < min_role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"This action requires {min_role.name} role or higher (you have {Role(membership.role).name})",
            )
        return membership
