from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.workspaces.schemas import WorkspaceCreate, WorkspaceOut
from app.domain.workspaces.service import WorkspaceService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/organizations/{org_id}/workspaces", tags=["workspaces"])


@router.post("", response_model=WorkspaceOut, status_code=201)
def create_workspace(
    org_id: str,
    payload: WorkspaceCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return WorkspaceService(db).create(org_id, payload, creator_user_id=current_user.id)


@router.get("", response_model=list[WorkspaceOut])
def list_workspaces(
    org_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return WorkspaceService(db).list_for_org(org_id, current_user.id)
