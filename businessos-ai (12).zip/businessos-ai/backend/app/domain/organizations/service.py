import re

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.organizations.models import Organization, OrgMembership
from app.domain.organizations.schemas import OrganizationCreate
from app.domain.shared.rbac import Role


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "org"


class OrganizationService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, payload: OrganizationCreate, owner_user_id: str) -> Organization:
        base_slug = _slugify(payload.name)
        slug = base_slug
        suffix = 1
        while self.db.query(Organization).filter(Organization.slug == slug).first():
            suffix += 1
            slug = f"{base_slug}-{suffix}"

        org = Organization(name=payload.name, slug=slug)
        self.db.add(org)
        self.db.flush()  # get org.id without committing yet

        membership = OrgMembership(org_id=org.id, user_id=owner_user_id, role=Role.OWNER)
        self.db.add(membership)
        self.db.commit()
        self.db.refresh(org)
        return org

    def list_for_user(self, user_id: str) -> list[Organization]:
        return (
            self.db.query(Organization)
            .join(OrgMembership, OrgMembership.org_id == Organization.id)
            .filter(OrgMembership.user_id == user_id)
            .all()
        )

    def get_membership(self, org_id: str, user_id: str) -> OrgMembership:
        membership = (
            self.db.query(OrgMembership)
            .filter(OrgMembership.org_id == org_id, OrgMembership.user_id == user_id)
            .first()
        )
        if not membership:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not a member of this organization")
        return membership
