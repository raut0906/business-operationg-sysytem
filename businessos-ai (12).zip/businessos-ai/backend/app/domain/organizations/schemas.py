from pydantic import BaseModel, Field


class OrganizationCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)


class OrganizationOut(BaseModel):
    id: str
    name: str
    slug: str
    plan: str

    model_config = {"from_attributes": True}
