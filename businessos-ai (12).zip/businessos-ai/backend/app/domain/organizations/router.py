from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.organizations.schemas import OrganizationCreate, OrganizationOut
from app.domain.organizations.service import OrganizationService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/organizations", tags=["organizations"])


@router.post("", response_model=OrganizationOut, status_code=201)
def create_organization(
    payload: OrganizationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return OrganizationService(db).create(payload, owner_user_id=current_user.id)


@router.get("", response_model=list[OrganizationOut])
def list_organizations(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return OrganizationService(db).list_for_user(current_user.id)
