from pydantic import BaseModel, Field, model_validator


class DashboardCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)


class DashboardOut(BaseModel):
    id: str
    workspace_id: str
    name: str
    created_by: str

    model_config = {"from_attributes": True}


class WidgetCreate(BaseModel):
    dataset_id: str
    chart_type: str = Field(pattern="^(bar|line|pie|table|kpi)$")
    title: str

    # Raw path — provide dimension + metric (+ optionally aggregate)
    dimension: str | None = None
    metric: str | None = None
    aggregate: str = Field(default="SUM", pattern="^(SUM|AVG|COUNT|MIN|MAX)$")

    # Semantic path — provide metric_id + dimension_id instead
    metric_id: str | None = None
    dimension_id: str | None = None

    position: dict = Field(default_factory=lambda: {"x": 0, "y": 0, "w": 4, "h": 3})

    @model_validator(mode="after")
    def _exactly_one_path(self) -> "WidgetCreate":
        raw_path = bool(self.dimension and self.metric)
        semantic_path = bool(self.metric_id and self.dimension_id)
        if raw_path == semantic_path:  # both true or both false
            raise ValueError(
                "Provide either (dimension + metric) for a raw widget, or "
                "(metric_id + dimension_id) for a semantic-layer widget — not both, not neither"
            )
        return self


class WidgetOut(BaseModel):
    id: str
    dashboard_id: str
    dataset_id: str
    chart_type: str
    title: str
    dimension: str | None
    metric: str | None
    aggregate: str
    metric_id: str | None = None
    dimension_id: str | None = None

    model_config = {"from_attributes": True}


class WidgetData(BaseModel):
    widget_id: str
    chart_type: str
    title: str
    data: list[dict]
