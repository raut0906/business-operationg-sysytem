import json

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.dashboards.models import Dashboard, DashboardWidget
from app.domain.dashboards.schemas import DashboardCreate, WidgetCreate, WidgetData
from app.domain.datasets.service import DatasetService
from app.domain.semantic.engine import MetricExpressionError, evaluate_metric_grouped, referenced_columns
from app.domain.semantic.models import Dimension, Metric
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService


class DashboardService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, workspace_id: str, payload: DashboardCreate, user_id: str) -> Dashboard:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        dashboard = Dashboard(workspace_id=workspace_id, name=payload.name, created_by=user_id)
        self.db.add(dashboard)
        self.db.commit()
        self.db.refresh(dashboard)
        return dashboard

    def list_for_workspace(self, workspace_id: str, user_id: str) -> list[Dashboard]:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        return self.db.query(Dashboard).filter(Dashboard.workspace_id == workspace_id).all()

    def get_or_404(self, dashboard_id: str, workspace_id: str, user_id: str) -> Dashboard:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        dashboard = (
            self.db.query(Dashboard)
            .filter(Dashboard.id == dashboard_id, Dashboard.workspace_id == workspace_id)
            .first()
        )
        if not dashboard:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dashboard not found")
        return dashboard

    def add_widget(
        self, workspace_id: str, dashboard_id: str, payload: WidgetCreate, user_id: str
    ) -> DashboardWidget:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        self.get_or_404(dashboard_id, workspace_id, user_id)
        # Confirms the dataset belongs to this workspace before wiring a widget to it.
        DatasetService(self.db).get_or_404(payload.dataset_id, workspace_id, user_id)

        if payload.metric_id and payload.dimension_id:
            metric = (
                self.db.query(Metric)
                .filter(Metric.id == payload.metric_id, Metric.workspace_id == workspace_id)
                .first()
            )
            if not metric:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="metric_id not found")
            dimension = (
                self.db.query(Dimension)
                .filter(Dimension.id == payload.dimension_id, Dimension.workspace_id == workspace_id)
                .first()
            )
            if not dimension:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="dimension_id not found")

        widget = DashboardWidget(
            dashboard_id=dashboard_id,
            dataset_id=payload.dataset_id,
            chart_type=payload.chart_type,
            title=payload.title,
            dimension=payload.dimension,
            metric=payload.metric,
            aggregate=payload.aggregate,
            metric_id=payload.metric_id,
            dimension_id=payload.dimension_id,
            position_json=json.dumps(payload.position),
        )
        self.db.add(widget)
        self.db.commit()
        self.db.refresh(widget)
        return widget

    def list_widgets(self, workspace_id: str, dashboard_id: str, user_id: str) -> list[DashboardWidget]:
        self.get_or_404(dashboard_id, workspace_id, user_id)
        return self.db.query(DashboardWidget).filter(DashboardWidget.dashboard_id == dashboard_id).all()

    def get_widget_data(self, workspace_id: str, dashboard_id: str, widget_id: str, user_id: str) -> WidgetData:
        self.get_or_404(dashboard_id, workspace_id, user_id)
        widget = self.db.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
        if not widget:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Widget not found")

        # Import kept local to avoid a module-level circular import (security imports
        # datasets/workspaces, dashboards imports security — this direction is fine
        # since security never imports back from dashboards, but the local import
        # keeps that dependency explicit and easy to spot here).
        from app.domain.security.service import SecurityService

        df, _applied, hidden_columns = SecurityService(self.db).get_secured_dataframe(
            widget.dataset_id, workspace_id, user_id
        )

        if widget.metric_id and widget.dimension_id:
            data = self._get_semantic_widget_data(df, hidden_columns, widget)
        else:
            data = self._get_raw_widget_data(df, hidden_columns, widget)

        return WidgetData(widget_id=widget.id, chart_type=widget.chart_type, title=widget.title, data=data)

    def _get_raw_widget_data(self, df, hidden_columns: list[str], widget: DashboardWidget) -> list[dict]:
        from app.domain.dashboards.aggregation import AggregationError, aggregate_dataframe

        for column in (widget.dimension, widget.metric):
            if column in hidden_columns:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Column '{column}' is hidden for your role and can't be used in this widget",
                )
        try:
            return aggregate_dataframe(df, widget.dimension, widget.metric, widget.aggregate)
        except AggregationError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    def _get_semantic_widget_data(self, df, hidden_columns: list[str], widget: DashboardWidget) -> list[dict]:
        """Evaluates a semantic-layer metric grouped by a semantic-layer dimension, on already-secured data."""
        metric = self.db.query(Metric).filter(Metric.id == widget.metric_id).first()
        dimension = self.db.query(Dimension).filter(Dimension.id == widget.dimension_id).first()
        if not metric or not dimension:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This widget's referenced metric or dimension no longer exists",
            )

        if dimension.column in hidden_columns:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Dimension column '{dimension.column}' is hidden for your role",
            )
        needed = referenced_columns(metric.expression)
        blocked = [c for c in needed if c in hidden_columns]
        if blocked:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Metric '{metric.name}' references columns hidden for your role: {blocked}",
            )

        try:
            result_df = evaluate_metric_grouped(metric.expression, df, dimension.column)
        except MetricExpressionError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
        return result_df.to_dict(orient="records")
