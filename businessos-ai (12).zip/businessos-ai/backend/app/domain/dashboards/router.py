from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.dashboards.schemas import DashboardCreate, DashboardOut, WidgetCreate, WidgetData, WidgetOut
from app.domain.dashboards.service import DashboardService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/dashboards", tags=["dashboards"])


@router.post("", response_model=DashboardOut, status_code=201)
def create_dashboard(
    workspace_id: str,
    payload: DashboardCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return DashboardService(db).create(workspace_id, payload, current_user.id)


@router.get("", response_model=list[DashboardOut])
def list_dashboards(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return DashboardService(db).list_for_workspace(workspace_id, current_user.id)


@router.post("/{dashboard_id}/widgets", response_model=WidgetOut, status_code=201)
def add_widget(
    workspace_id: str,
    dashboard_id: str,
    payload: WidgetCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return DashboardService(db).add_widget(workspace_id, dashboard_id, payload, current_user.id)


@router.get("/{dashboard_id}/widgets", response_model=list[WidgetOut])
def list_widgets(
    workspace_id: str,
    dashboard_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return DashboardService(db).list_widgets(workspace_id, dashboard_id, current_user.id)


@router.get("/{dashboard_id}/widgets/{widget_id}/data", response_model=WidgetData)
def get_widget_data(
    workspace_id: str,
    dashboard_id: str,
    widget_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return DashboardService(db).get_widget_data(workspace_id, dashboard_id, widget_id, current_user.id)
