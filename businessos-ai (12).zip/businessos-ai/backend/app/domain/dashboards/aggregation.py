"""
Pure aggregation logic for dashboard widgets, factored out so it can run
on an already-filtered/masked pandas DataFrame (post-RLS/CLS) rather than
only via a raw SQL GROUP BY against the warehouse. This is what makes it
possible to apply row-level security *before* aggregation instead of
after — filtering aggregated results after the fact would leak the
existence/shape of restricted rows through the aggregate values.
"""
import pandas as pd

_ALLOWED_AGGS = {"SUM", "AVG", "COUNT", "MIN", "MAX"}


class AggregationError(Exception):
    pass


def aggregate_dataframe(df: pd.DataFrame, dimension: str, metric: str, agg: str, limit: int = 500) -> list[dict]:
    """
    Replicates the shape of app.infrastructure.duckdb_client.run_aggregate_query's
    output ({"dimension": ..., "value": ...} rows, sorted descending by value,
    capped at `limit`) but computed in pandas over an in-memory DataFrame.
    """
    agg_upper = agg.upper()
    if agg_upper not in _ALLOWED_AGGS:
        raise AggregationError(f"Unsupported aggregate '{agg}', use one of {_ALLOWED_AGGS}")
    if dimension not in df.columns:
        raise AggregationError(f"Dimension column '{dimension}' not found")
    if metric not in df.columns:
        raise AggregationError(f"Metric column '{metric}' not found")

    metric_series = pd.to_numeric(df[metric], errors="coerce") if agg_upper != "COUNT" else df[metric]
    if agg_upper != "COUNT" and metric_series.isna().all() and df[metric].notna().any():
        raise AggregationError(
            f"Metric column '{metric}' could not be treated as numeric — it may be masked for your role"
        )

    work = df[[dimension]].copy()
    work["__metric__"] = metric_series

    grouped = work.groupby(dimension, dropna=False)["__metric__"]
    if agg_upper == "SUM":
        result = grouped.sum()
    elif agg_upper == "AVG":
        result = grouped.mean()
    elif agg_upper == "COUNT":
        result = grouped.count()
    elif agg_upper == "MIN":
        result = grouped.min()
    else:
        result = grouped.max()

    result_df = result.reset_index()
    result_df.columns = ["dimension", "value"]
    result_df = result_df.sort_values("value", ascending=False).head(limit)
    return result_df.to_dict(orient="records")
