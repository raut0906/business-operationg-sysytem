from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.shared.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.infrastructure.db import Base


class Dashboard(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "dashboards"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)


class DashboardWidget(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """
    A widget's data source is EITHER:
    - raw path: dimension + metric (raw column names) + aggregate, run as a
      direct GROUP BY aggregate query against the dataset's warehouse table, OR
    - semantic path: metric_id + dimension_id, referencing a named, reusable
      Metric/Dimension from the semantic layer — the metric's formula is
      evaluated per dimension slice via app.domain.semantic.engine instead of
      a raw column aggregate.

    Exactly one of these two paths must be set; see WidgetCreate's validation
    for the enforcement (kept in the schema so it's the same rule everywhere
    a widget is created, not just here).
    """
    __tablename__ = "dashboard_widgets"

    dashboard_id: Mapped[str] = mapped_column(ForeignKey("dashboards.id"), index=True, nullable=False)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    # bar | line | pie | table | kpi
    chart_type: Mapped[str] = mapped_column(String(50), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)

    # Raw path (nullable — only set when not using the semantic path)
    dimension: Mapped[str] = mapped_column(String(255), nullable=True)
    metric: Mapped[str] = mapped_column(String(255), nullable=True)
    aggregate: Mapped[str] = mapped_column(String(20), default="SUM")

    # Semantic path (nullable — only set when not using the raw path)
    metric_id: Mapped[str] = mapped_column(ForeignKey("semantic_metrics.id"), nullable=True)
    dimension_id: Mapped[str] = mapped_column(ForeignKey("semantic_dimensions.id"), nullable=True)

    # JSON-encoded {"x": int, "y": int, "w": int, "h": int}
    position_json: Mapped[str] = mapped_column(Text, default="{}")
