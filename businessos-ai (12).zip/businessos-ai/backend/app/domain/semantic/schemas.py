from pydantic import BaseModel, Field


class MetricCreate(BaseModel):
    dataset_id: str
    name: str = Field(min_length=1, max_length=255)
    expression: str = Field(min_length=1, description="e.g. 'SUM(revenue) - SUM(cost)'")
    format: str = Field(default="number", pattern="^(currency|number|percent)$")
    description: str | None = None


class MetricOut(BaseModel):
    id: str
    workspace_id: str
    dataset_id: str
    name: str
    expression: str
    format: str
    description: str | None

    model_config = {"from_attributes": True}


class MetricEvaluation(BaseModel):
    metric_id: str
    name: str
    value: float
    format: str


class DimensionCreate(BaseModel):
    dataset_id: str
    name: str = Field(min_length=1, max_length=255)
    column: str = Field(min_length=1)
    description: str | None = None


class DimensionOut(BaseModel):
    id: str
    workspace_id: str
    dataset_id: str
    name: str
    column: str
    description: str | None

    model_config = {"from_attributes": True}
