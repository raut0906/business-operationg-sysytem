"""
Metric expression engine.

Business users write metric formulas like "SUM(revenue) - SUM(cost)" or
"SUM(revenue) / COUNT(order_id)". This module parses and evaluates those
expressions WITHOUT ever calling Python's eval()/exec() — it parses the
expression into an AST via the stdlib `ast` module, then walks that tree
itself, only ever interpreting a small allowlist of node types (arithmetic
operators, numeric constants, and calls to SUM/AVG/COUNT/MIN/MAX with a
single column-name argument). Any other node type — attribute access,
subscripting, comprehensions, function calls to anything else, name
lookups outside of an aggregate call — is rejected before evaluation ever
starts. This mirrors the same defense-in-depth spirit as
app.domain.copilot.sql_safety: never trust a user-supplied expression
string enough to hand it to a general-purpose interpreter.
"""
import ast

import pandas as pd

_ALLOWED_AGGREGATES = {"SUM", "AVG", "COUNT", "MIN", "MAX"}
_ALLOWED_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.Div)


class MetricExpressionError(Exception):
    pass


def validate_expression_syntax(expression: str) -> None:
    """Raises MetricExpressionError if the expression can't even be parsed/validated
    against the schema-free grammar (doesn't check column existence — that needs a
    DataFrame, see evaluate_metric)."""
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise MetricExpressionError(f"Could not parse expression: {exc}") from exc
    _validate_node(tree.body)


def _validate_node(node: ast.AST) -> None:
    if isinstance(node, ast.BinOp):
        if not isinstance(node.op, _ALLOWED_BINOPS):
            raise MetricExpressionError(f"Operator '{type(node.op).__name__}' is not allowed")
        _validate_node(node.left)
        _validate_node(node.right)
        return
    if isinstance(node, ast.UnaryOp):
        if not isinstance(node.op, ast.USub):
            raise MetricExpressionError(f"Unary operator '{type(node.op).__name__}' is not allowed")
        _validate_node(node.operand)
        return
    if isinstance(node, ast.Constant):
        if not isinstance(node.value, (int, float)):
            raise MetricExpressionError(f"Only numeric constants are allowed, got {node.value!r}")
        return
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name) or node.func.id not in _ALLOWED_AGGREGATES:
            raise MetricExpressionError(
                f"Only these aggregate functions are allowed: {sorted(_ALLOWED_AGGREGATES)}"
            )
        if node.keywords or len(node.args) != 1 or not isinstance(node.args[0], ast.Name):
            raise MetricExpressionError(
                f"{node.func.id}(...) must take exactly one column name, e.g. {node.func.id}(revenue)"
            )
        return
    raise MetricExpressionError(f"Expression contains a disallowed construct: {type(node).__name__}")


def _compute_aggregate(df: pd.DataFrame, agg: str, column: str) -> float:
    if column not in df.columns:
        raise MetricExpressionError(f"Column '{column}' not found. Available: {list(df.columns)}")
    series = pd.to_numeric(df[column], errors="coerce") if agg != "COUNT" else df[column]
    if agg == "SUM":
        return float(series.sum())
    if agg == "AVG":
        return float(series.mean())
    if agg == "COUNT":
        return float(series.count())
    if agg == "MIN":
        return float(series.min())
    if agg == "MAX":
        return float(series.max())
    raise MetricExpressionError(f"Unknown aggregate '{agg}'")  # unreachable given _validate_node, kept defensive


def _eval_node(node: ast.AST, df: pd.DataFrame) -> float:
    if isinstance(node, ast.BinOp):
        left = _eval_node(node.left, df)
        right = _eval_node(node.right, df)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            if right == 0:
                raise MetricExpressionError("Division by zero in metric expression")
            return left / right
    if isinstance(node, ast.UnaryOp):
        return -_eval_node(node.operand, df)
    if isinstance(node, ast.Constant):
        return float(node.value)
    if isinstance(node, ast.Call):
        agg = node.func.id
        column = node.args[0].id
        return _compute_aggregate(df, agg, column)
    raise MetricExpressionError(f"Unexpected node during evaluation: {type(node).__name__}")


def evaluate_metric_grouped(expression: str, df: pd.DataFrame, group_by_column: str) -> pd.DataFrame:
    """
    Evaluates a metric expression separately within each group of group_by_column,
    e.g. "Gross Profit" grouped by "region" — this is what a dashboard widget
    actually needs (a value per dimension slice), as opposed to evaluate_metric's
    single overall scalar.

    Returns a DataFrame with columns [dimension, value], sorted descending by value
    to match the shape dashboard widgets already expect from raw aggregate queries.
    """
    validate_expression_syntax(expression)
    if group_by_column not in df.columns:
        raise MetricExpressionError(f"Group-by column '{group_by_column}' not found. Available: {list(df.columns)}")

    tree = ast.parse(expression, mode="eval")
    results = []
    for group_value, group_df in df.groupby(group_by_column, dropna=False):
        value = _eval_node(tree.body, group_df)
        results.append({"dimension": group_value, "value": value})

    result_df = pd.DataFrame(results)
    if result_df.empty:
        return result_df
    return result_df.sort_values("value", ascending=False).reset_index(drop=True)


def evaluate_metric(expression: str, df: pd.DataFrame) -> float:
    """Validates then evaluates a metric expression against a DataFrame. Returns a single scalar value."""
    validate_expression_syntax(expression)
    tree = ast.parse(expression, mode="eval")
    return _eval_node(tree.body, df)


def referenced_columns(expression: str) -> list[str]:
    """Returns the distinct column names referenced by SUM/AVG/COUNT/etc calls in the expression."""
    validate_expression_syntax(expression)
    tree = ast.parse(expression, mode="eval")
    columns: list[str] = []

    def _walk(node: ast.AST) -> None:
        if isinstance(node, ast.Call):
            col = node.args[0].id
            if col not in columns:
                columns.append(col)
        for child in ast.iter_child_nodes(node):
            _walk(child)

    _walk(tree.body)
    return columns
