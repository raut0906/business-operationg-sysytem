from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.semantic.schemas import (
    DimensionCreate,
    DimensionOut,
    MetricCreate,
    MetricEvaluation,
    MetricOut,
)
from app.domain.semantic.service import SemanticService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/semantic", tags=["semantic"])


@router.post("/metrics", response_model=MetricOut, status_code=201)
def create_metric(
    workspace_id: str,
    payload: MetricCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return SemanticService(db).create_metric(workspace_id, payload, current_user.id)


@router.get("/metrics", response_model=list[MetricOut])
def list_metrics(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return SemanticService(db).list_metrics(workspace_id, current_user.id)


@router.get("/metrics/{metric_id}/evaluate", response_model=MetricEvaluation)
def evaluate_metric(
    workspace_id: str,
    metric_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    service = SemanticService(db)
    metric = service.get_metric_or_404(metric_id, workspace_id, current_user.id)
    value = service.evaluate_metric(metric_id, workspace_id, current_user.id)
    return MetricEvaluation(metric_id=metric.id, name=metric.name, value=value, format=metric.format)


@router.delete("/metrics/{metric_id}", status_code=204)
def delete_metric(
    workspace_id: str,
    metric_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    SemanticService(db).delete_metric(metric_id, workspace_id, current_user.id)


@router.post("/dimensions", response_model=DimensionOut, status_code=201)
def create_dimension(
    workspace_id: str,
    payload: DimensionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return SemanticService(db).create_dimension(workspace_id, payload, current_user.id)


@router.get("/dimensions", response_model=list[DimensionOut])
def list_dimensions(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return SemanticService(db).list_dimensions(workspace_id, current_user.id)


@router.delete("/dimensions/{dimension_id}", status_code=204)
def delete_dimension(
    workspace_id: str,
    dimension_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    SemanticService(db).delete_dimension(dimension_id, workspace_id, current_user.id)
