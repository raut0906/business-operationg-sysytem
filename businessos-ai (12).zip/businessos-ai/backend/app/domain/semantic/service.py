"""
Semantic layer service.

Metrics are validated (syntax + referenced columns actually existing on the
dataset) at *creation* time, not first use — so a typo in a metric formula
is caught immediately with a clear error, rather than surfacing later as a
confusing failure on some dashboard three clicks away.
"""
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.datasets.service import DatasetService
from app.domain.semantic.engine import MetricExpressionError, evaluate_metric, referenced_columns
from app.domain.semantic.models import Dimension, Metric
from app.domain.semantic.schemas import DimensionCreate, MetricCreate
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService
from app.infrastructure import duckdb_client


class SemanticService:
    def __init__(self, db: Session):
        self.db = db

    def _check_membership(self, workspace_id: str, user_id: str) -> None:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)

    # ---- Metrics ---------------------------------------------

    def create_metric(self, workspace_id: str, payload: MetricCreate, user_id: str) -> Metric:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        dataset = DatasetService(self.db).get_or_404(payload.dataset_id, workspace_id, user_id)

        try:
            needed_columns = referenced_columns(payload.expression)
        except MetricExpressionError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

        schema = duckdb_client.get_table_schema(workspace_id, dataset.warehouse_table_name)
        available = {col["name"] for col in schema}
        missing = [c for c in needed_columns if c not in available]
        if missing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Metric references columns not in dataset '{dataset.name}': {missing}",
            )

        metric = Metric(workspace_id=workspace_id, **payload.model_dump())
        self.db.add(metric)
        self.db.commit()
        self.db.refresh(metric)
        return metric

    def list_metrics(self, workspace_id: str, user_id: str) -> list[Metric]:
        self._check_membership(workspace_id, user_id)
        return self.db.query(Metric).filter(Metric.workspace_id == workspace_id).all()

    def get_metric_or_404(self, metric_id: str, workspace_id: str, user_id: str) -> Metric:
        self._check_membership(workspace_id, user_id)
        metric = self.db.query(Metric).filter(Metric.id == metric_id, Metric.workspace_id == workspace_id).first()
        if not metric:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Metric not found")
        return metric

    def evaluate_metric(self, metric_id: str, workspace_id: str, user_id: str) -> float:
        metric = self.get_metric_or_404(metric_id, workspace_id, user_id)

        # Local import: avoids a module-level circular import (security imports
        # datasets/workspaces at module level; this direction stays one-way).
        from app.domain.security.service import SecurityService

        df, _applied, hidden_columns = SecurityService(self.db).get_secured_dataframe(
            metric.dataset_id, workspace_id, user_id
        )
        blocked = [c for c in referenced_columns(metric.expression) if c in hidden_columns]
        if blocked:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Metric '{metric.name}' references columns hidden for your role: {blocked}",
            )
        try:
            return evaluate_metric(metric.expression, df)
        except MetricExpressionError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    def delete_metric(self, metric_id: str, workspace_id: str, user_id: str) -> None:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        metric = self.get_metric_or_404(metric_id, workspace_id, user_id)
        self.db.delete(metric)
        self.db.commit()

    # ---- Dimensions ---------------------------------------------

    def create_dimension(self, workspace_id: str, payload: DimensionCreate, user_id: str) -> Dimension:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        dataset = DatasetService(self.db).get_or_404(payload.dataset_id, workspace_id, user_id)

        schema = duckdb_client.get_table_schema(workspace_id, dataset.warehouse_table_name)
        available = {col["name"] for col in schema}
        if payload.column not in available:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Column '{payload.column}' not found in dataset '{dataset.name}'. Available: {sorted(available)}",
            )

        dimension = Dimension(workspace_id=workspace_id, **payload.model_dump())
        self.db.add(dimension)
        self.db.commit()
        self.db.refresh(dimension)
        return dimension

    def list_dimensions(self, workspace_id: str, user_id: str) -> list[Dimension]:
        self._check_membership(workspace_id, user_id)
        return self.db.query(Dimension).filter(Dimension.workspace_id == workspace_id).all()

    def delete_dimension(self, dimension_id: str, workspace_id: str, user_id: str) -> None:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        dimension = (
            self.db.query(Dimension)
            .filter(Dimension.id == dimension_id, Dimension.workspace_id == workspace_id)
            .first()
        )
        if not dimension:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dimension not found")
        self.db.delete(dimension)
        self.db.commit()
