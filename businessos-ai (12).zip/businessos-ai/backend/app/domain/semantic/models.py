from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.shared.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.infrastructure.db import Base


class Metric(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """
    A reusable, named business metric ("Gross Profit" = SUM(revenue) - SUM(cost))
    defined once against a dataset and referenced by name from any dashboard
    widget or Copilot query going forward, instead of every widget re-deriving
    the same aggregate expression independently.
    """
    __tablename__ = "semantic_metrics"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    expression: Mapped[str] = mapped_column(Text, nullable=False)
    # currency | number | percent
    format: Mapped[str] = mapped_column(String(20), default="number")
    description: Mapped[str] = mapped_column(Text, nullable=True)


class Dimension(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """A named, reusable grouping column ("Region" -> the 'region' column) for a dataset."""
    __tablename__ = "semantic_dimensions"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    column: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=True)
