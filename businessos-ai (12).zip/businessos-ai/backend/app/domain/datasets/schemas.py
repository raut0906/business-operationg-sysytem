from pydantic import BaseModel


class DatasetOut(BaseModel):
    id: str
    workspace_id: str
    name: str
    warehouse_table_name: str
    source_type: str
    row_count: int

    model_config = {"from_attributes": True}


class DatasetPreview(BaseModel):
    columns: list[str]
    rows: list[dict]
    row_count: int
