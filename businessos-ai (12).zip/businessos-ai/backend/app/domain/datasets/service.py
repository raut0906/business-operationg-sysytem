"""
Dataset ingestion service.

Handles CSV/XLSX upload -> schema inference -> load into the workspace's
DuckDB warehouse. This is intentionally the *only* place that knows how to
turn a raw file into a warehouse table, so future connectors plug in here
by implementing the same `ingest_dataframe` step rather than duplicating
warehouse-loading logic.
"""
import json

import pandas as pd
from fastapi import HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.domain.datasets.models import Dataset
from app.domain.datasets.schemas import DatasetPreview
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService
from app.infrastructure import duckdb_client

SUPPORTED_EXTENSIONS = {".csv", ".xlsx", ".xls"}


class DatasetService:
    def __init__(self, db: Session):
        self.db = db

    def _read_file_to_dataframe(self, file: UploadFile) -> pd.DataFrame:
        filename = file.filename or ""
        ext = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext not in SUPPORTED_EXTENSIONS:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unsupported file type '{ext}'. Supported: {sorted(SUPPORTED_EXTENSIONS)}",
            )
        try:
            if ext == ".csv":
                return pd.read_csv(file.file)
            return pd.read_excel(file.file)
        except Exception as exc:  # pandas raises many different error types for malformed files
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Could not parse file: {exc}",
            ) from exc

    def upload_and_ingest(self, workspace_id: str, user_id: str, dataset_name: str, file: UploadFile) -> Dataset:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)

        df = self._read_file_to_dataframe(file)
        if df.empty:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file has no rows")

        table_name = duckdb_client.load_dataframe(workspace_id, dataset_name, df)

        schema = [{"name": col, "dtype": str(dtype)} for col, dtype in df.dtypes.items()]

        dataset = Dataset(
            workspace_id=workspace_id,
            name=dataset_name,
            warehouse_table_name=table_name,
            source_type="file_upload",
            row_count=len(df),
            schema_json=json.dumps(schema),
        )
        self.db.add(dataset)
        self.db.commit()
        self.db.refresh(dataset)
        return dataset

    def list_for_workspace(self, workspace_id: str, user_id: str) -> list[Dataset]:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        return self.db.query(Dataset).filter(Dataset.workspace_id == workspace_id).all()

    def get_or_404(self, dataset_id: str, workspace_id: str, user_id: str) -> Dataset:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        dataset = (
            self.db.query(Dataset)
            .filter(Dataset.id == dataset_id, Dataset.workspace_id == workspace_id)
            .first()
        )
        if not dataset:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found")
        return dataset

    def preview(self, dataset_id: str, workspace_id: str, user_id: str, limit: int = 50) -> DatasetPreview:
        # RLS/CLS enforcement: this was previously a direct bypass around the entire security
        # system — any member could hit this raw preview endpoint instead of the dedicated
        # secured-preview endpoint and see completely unfiltered data. Now both paths go through
        # the same SecurityService.get_secured_dataframe primitive, so there is no unsecured
        # route to a dataset's rows left in the app.
        self.get_or_404(dataset_id, workspace_id, user_id)  # 404s before importing/querying if the dataset is invalid

        from app.domain.security.service import SecurityService

        df, _applied, _hidden = SecurityService(self.db).get_secured_dataframe(dataset_id, workspace_id, user_id)
        limited = df.head(limit)
        return DatasetPreview(columns=list(limited.columns), rows=limited.to_dict(orient="records"), row_count=len(df))
