from sqlalchemy import ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.shared.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.infrastructure.db import Base


class Dataset(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "datasets"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    # Name of the table inside the workspace's DuckDB warehouse file.
    warehouse_table_name: Mapped[str] = mapped_column(String(255), nullable=False)
    source_type: Mapped[str] = mapped_column(String(50), default="file_upload")
    row_count: Mapped[int] = mapped_column(Integer, default=0)
    # JSON-encoded list of {"name": str, "dtype": str}
    schema_json: Mapped[str] = mapped_column(Text, default="[]")
