from fastapi import APIRouter, Depends, File, Query, UploadFile
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.datasets.schemas import DatasetOut, DatasetPreview
from app.domain.datasets.service import DatasetService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/datasets", tags=["datasets"])


@router.post("", response_model=DatasetOut, status_code=201)
def upload_dataset(
    workspace_id: str,
    name: str = Query(..., description="Display name for the dataset"),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return DatasetService(db).upload_and_ingest(workspace_id, current_user.id, name, file)


@router.get("", response_model=list[DatasetOut])
def list_datasets(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return DatasetService(db).list_for_workspace(workspace_id, current_user.id)


@router.get("/{dataset_id}/preview", response_model=DatasetPreview)
def preview_dataset(
    workspace_id: str,
    dataset_id: str,
    limit: int = Query(50, ge=1, le=1000),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return DatasetService(db).preview(dataset_id, workspace_id, current_user.id, limit=limit)
