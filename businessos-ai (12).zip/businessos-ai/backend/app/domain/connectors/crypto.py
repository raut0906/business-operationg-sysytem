"""
Encrypts connector credentials (connection strings, passwords, API keys)
before they touch the database. Uses Fernet (AES-128-CBC + HMAC), keyed
from a dedicated secret rather than reusing the JWT signing key — a
compromise of one shouldn't automatically compromise the other.

If CONNECTOR_ENCRYPTION_KEY isn't set, a key is derived deterministically
from JWT_SECRET_KEY as a local-dev fallback so the app doesn't crash on
first run — this is flagged as unsafe for production in Settings, and
callers should set a real key via environment variable there.
"""
import base64
import hashlib

from cryptography.fernet import Fernet, InvalidToken

from app.core.config import get_settings

settings = get_settings()


def _get_fernet() -> Fernet:
    key_material = settings.connector_encryption_key or settings.jwt_secret_key
    # Fernet requires a 32-byte urlsafe-base64 key; derive one deterministically
    # from whatever secret material is configured.
    digest = hashlib.sha256(key_material.encode()).digest()
    fernet_key = base64.urlsafe_b64encode(digest)
    return Fernet(fernet_key)


def encrypt_credentials(plaintext: str) -> str:
    return _get_fernet().encrypt(plaintext.encode()).decode()


def decrypt_credentials(ciphertext: str) -> str:
    try:
        return _get_fernet().decrypt(ciphertext.encode()).decode()
    except InvalidToken as exc:
        raise ValueError("Could not decrypt connector credentials — wrong key or corrupted data") from exc
