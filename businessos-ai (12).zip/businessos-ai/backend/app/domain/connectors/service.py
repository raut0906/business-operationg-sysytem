"""
Connectors domain service.

The key integration point is `sync()`: it extracts a table from the
external database via engine.py, then hands the resulting DataFrame to
the exact same `duckdb_client.load_dataframe()` used by CSV/XLSX upload
(see app.domain.datasets.service) — a database connector and a file
upload both end up as "a dataset in the warehouse" through one shared
path, which is what makes adding more connector types in the future a
matter of writing an extractor, not touching the dataset/dashboard layer.
"""
import json
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.connectors import engine as connector_engine
from app.domain.connectors.crypto import decrypt_credentials, encrypt_credentials
from app.domain.connectors.models import DatabaseConnector
from app.domain.connectors.schemas import ConnectorCreate
from app.domain.datasets.models import Dataset
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService
from app.infrastructure import duckdb_client


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class ConnectorService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, workspace_id: str, payload: ConnectorCreate, user_id: str) -> DatabaseConnector:
        # Admin+ only: this action stores encrypted DB credentials, a more sensitive action
        # than ordinary content creation, so it's held to a higher bar than Editor.
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)

        try:
            connection_string = connector_engine.build_connection_string(
                dialect=payload.dialect,
                database=payload.database,
                host=payload.host,
                port=payload.port,
                username=payload.username,
                password=payload.password,
            )
        except connector_engine.ConnectorError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

        connector = DatabaseConnector(
            workspace_id=workspace_id,
            name=payload.name,
            dialect=payload.dialect,
            encrypted_connection_string=encrypt_credentials(connection_string),
            status="untested",
            created_by=user_id,
        )
        self.db.add(connector)
        self.db.commit()
        self.db.refresh(connector)
        return connector

    def list_for_workspace(self, workspace_id: str, user_id: str) -> list[DatabaseConnector]:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        return self.db.query(DatabaseConnector).filter(DatabaseConnector.workspace_id == workspace_id).all()

    def get_or_404(self, connector_id: str, workspace_id: str, user_id: str) -> DatabaseConnector:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        connector = (
            self.db.query(DatabaseConnector)
            .filter(DatabaseConnector.id == connector_id, DatabaseConnector.workspace_id == workspace_id)
            .first()
        )
        if not connector:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Connector not found")
        return connector

    def test_connection(self, connector_id: str, workspace_id: str, user_id: str) -> DatabaseConnector:
        connector = self.get_or_404(connector_id, workspace_id, user_id)
        connection_string = decrypt_credentials(connector.encrypted_connection_string)
        try:
            connector_engine.test_connection(connection_string)
            connector.status = "connected"
            connector.last_error = None
        except connector_engine.ConnectorError as exc:
            connector.status = "failed"
            connector.last_error = str(exc)
        self.db.commit()
        self.db.refresh(connector)
        return connector

    def discover_schema(self, connector_id: str, workspace_id: str, user_id: str) -> list[dict]:
        connector = self.get_or_404(connector_id, workspace_id, user_id)
        connection_string = decrypt_credentials(connector.encrypted_connection_string)
        try:
            return connector_engine.discover_schema(connection_string)
        except connector_engine.ConnectorError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    def sync(
        self, connector_id: str, workspace_id: str, table_name: str, dataset_name: str, user_id: str, limit: int | None = None
    ) -> Dataset:
        """Extracts a table from the external DB and loads it into the warehouse as a new dataset."""
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        connector = self.get_or_404(connector_id, workspace_id, user_id)
        connection_string = decrypt_credentials(connector.encrypted_connection_string)

        try:
            df = connector_engine.extract_table(connection_string, table_name, limit=limit)
        except connector_engine.ConnectorError as exc:
            connector.status = "failed"
            connector.last_error = str(exc)
            self.db.commit()
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

        if df.empty:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Table '{table_name}' has no rows")

        warehouse_table_name = duckdb_client.load_dataframe(workspace_id, dataset_name, df)
        schema = [{"name": col, "dtype": str(dtype)} for col, dtype in df.dtypes.items()]

        dataset = Dataset(
            workspace_id=workspace_id,
            name=dataset_name,
            warehouse_table_name=warehouse_table_name,
            source_type=f"connector:{connector.dialect}",
            row_count=len(df),
            schema_json=json.dumps(schema),
        )
        self.db.add(dataset)

        connector.status = "connected"
        connector.last_synced_at = _now_iso()
        connector.last_error = None
        self.db.commit()
        self.db.refresh(dataset)
        return dataset

    def delete(self, connector_id: str, workspace_id: str, user_id: str) -> None:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        connector = self.get_or_404(connector_id, workspace_id, user_id)
        self.db.delete(connector)
        self.db.commit()
