"""
Database connector engine.

Deliberately generic: works against any SQLAlchemy-supported dialect
(sqlite, postgresql, mysql, and beyond) through the same three functions.
Postgres/MySQL need their driver installed (psycopg2/pymysql) to actually
connect — this module doesn't hardcode any dialect-specific logic, so
adding a new supported database is a connection-string-builder change,
not an engine change.
"""
import pandas as pd
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import Engine


class ConnectorError(Exception):
    pass


SUPPORTED_DIALECTS = {"sqlite", "postgresql", "mysql"}


def build_connection_string(
    dialect: str,
    database: str,
    host: str | None = None,
    port: int | None = None,
    username: str | None = None,
    password: str | None = None,
) -> str:
    if dialect not in SUPPORTED_DIALECTS:
        raise ConnectorError(f"Unsupported dialect '{dialect}', use one of {SUPPORTED_DIALECTS}")

    if dialect == "sqlite":
        # `database` is a file path for sqlite; no host/port/credentials involved.
        return f"sqlite:///{database}"

    if not host or not username:
        raise ConnectorError(f"'{dialect}' connections require host and username")

    driver = "psycopg2" if dialect == "postgresql" else "pymysql"
    default_port = 5432 if dialect == "postgresql" else 3306
    auth = f"{username}:{password}@" if password else f"{username}@"
    return f"{dialect}+{driver}://{auth}{host}:{port or default_port}/{database}"


def test_connection(connection_string: str) -> None:
    """Raises ConnectorError with a clear message if the connection can't be established."""
    engine = None
    try:
        engine = create_engine(connection_string, connect_args={"connect_timeout": 5} if "sqlite" not in connection_string else {})
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
    except Exception as exc:
        raise ConnectorError(f"Connection failed: {exc}") from exc
    finally:
        if engine is not None:
            engine.dispose()


def discover_schema(connection_string: str) -> list[dict]:
    """Returns [{"table_name": str, "columns": [{"name": str, "type": str}]}, ...]"""
    engine = None
    try:
        engine = create_engine(connection_string)
        inspector = inspect(engine)
        tables = []
        for table_name in inspector.get_table_names():
            columns = [
                {"name": col["name"], "type": str(col["type"])} for col in inspector.get_columns(table_name)
            ]
            tables.append({"table_name": table_name, "columns": columns})
        return tables
    except Exception as exc:
        raise ConnectorError(f"Schema discovery failed: {exc}") from exc
    finally:
        if engine is not None:
            engine.dispose()


def extract_table(connection_string: str, table_name: str, limit: int | None = None) -> pd.DataFrame:
    """Extracts a full table (or a limited sample) as a DataFrame."""
    engine = None
    try:
        engine = create_engine(connection_string)
        query = f'SELECT * FROM "{table_name}"' if not limit else f'SELECT * FROM "{table_name}" LIMIT {int(limit)}'
        with engine.connect() as conn:
            return pd.read_sql(text(query), conn)
    except Exception as exc:
        raise ConnectorError(f"Extraction from '{table_name}' failed: {exc}") from exc
    finally:
        if engine is not None:
            engine.dispose()


def extract_query(connection_string: str, sql_query: str) -> pd.DataFrame:
    """Extracts the result of an arbitrary caller-supplied SQL query (e.g. a custom join)."""
    engine = None
    try:
        engine = create_engine(connection_string)
        with engine.connect() as conn:
            return pd.read_sql(text(sql_query), conn)
    except Exception as exc:
        raise ConnectorError(f"Query execution failed: {exc}") from exc
    finally:
        if engine is not None:
            engine.dispose()
