from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.connectors.schemas import (
    ConnectorCreate,
    ConnectorOut,
    ConnectorSchemaResponse,
)
from app.domain.connectors.service import ConnectorService
from app.domain.datasets.schemas import DatasetOut
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/connectors", tags=["connectors"])


@router.post("", response_model=ConnectorOut, status_code=201)
def create_connector(
    workspace_id: str,
    payload: ConnectorCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return ConnectorService(db).create(workspace_id, payload, current_user.id)


@router.get("", response_model=list[ConnectorOut])
def list_connectors(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return ConnectorService(db).list_for_workspace(workspace_id, current_user.id)


@router.post("/{connector_id}/test", response_model=ConnectorOut)
def test_connector(
    workspace_id: str,
    connector_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return ConnectorService(db).test_connection(connector_id, workspace_id, current_user.id)


@router.get("/{connector_id}/schema", response_model=ConnectorSchemaResponse)
def get_connector_schema(
    workspace_id: str,
    connector_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    tables = ConnectorService(db).discover_schema(connector_id, workspace_id, current_user.id)
    return ConnectorSchemaResponse(tables=tables)


@router.post("/{connector_id}/sync", response_model=DatasetOut, status_code=201)
def sync_connector(
    workspace_id: str,
    connector_id: str,
    table_name: str = Query(...),
    dataset_name: str = Query(...),
    limit: int | None = Query(default=None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return ConnectorService(db).sync(connector_id, workspace_id, table_name, dataset_name, current_user.id, limit=limit)


@router.delete("/{connector_id}", status_code=204)
def delete_connector(
    workspace_id: str,
    connector_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    ConnectorService(db).delete(connector_id, workspace_id, current_user.id)
