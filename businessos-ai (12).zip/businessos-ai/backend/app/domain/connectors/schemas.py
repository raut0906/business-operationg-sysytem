from pydantic import BaseModel, Field


class ConnectorCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    dialect: str = Field(pattern="^(sqlite|postgresql|mysql)$")
    # For sqlite: the file path. For postgresql/mysql: the database name.
    database: str = Field(min_length=1)
    host: str | None = None
    port: int | None = None
    username: str | None = None
    password: str | None = None


class ConnectorOut(BaseModel):
    id: str
    workspace_id: str
    name: str
    dialect: str
    status: str
    last_error: str | None = None
    last_synced_at: str | None = None

    model_config = {"from_attributes": True}


class ConnectorTableSchema(BaseModel):
    table_name: str
    columns: list[dict]


class ConnectorSchemaResponse(BaseModel):
    tables: list[ConnectorTableSchema]


class ConnectorSyncRequest(BaseModel):
    table_name: str
    dataset_name: str
    limit: int | None = Field(default=None, description="Optional row cap for a quick sample sync")
