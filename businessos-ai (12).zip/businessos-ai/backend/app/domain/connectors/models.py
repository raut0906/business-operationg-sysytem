from sqlalchemy import Boolean, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.shared.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.infrastructure.db import Base


class DatabaseConnector(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "connectors"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    # sqlite | postgresql | mysql
    dialect: Mapped[str] = mapped_column(String(20), nullable=False)
    # Fernet-encrypted connection string — never stored or logged in plaintext.
    encrypted_connection_string: Mapped[str] = mapped_column(Text, nullable=False)
    # untested | connected | failed
    status: Mapped[str] = mapped_column(String(20), default="untested")
    last_error: Mapped[str] = mapped_column(Text, nullable=True)
    last_synced_at: Mapped[str] = mapped_column(String(50), nullable=True)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
