"""
Reports service — gathers a dashboard's widgets and their live data, optionally
adds an AI executive summary (best-effort: if Copilot isn't configured or the
call fails, the report still generates without one rather than failing the
whole report), and hands everything to whichever pure builder matches the
requested format (pdf_builder or xlsx_builder — both take the exact same
ReportWidget list and summary string, so adding a third format later is a
new builder module, not a service-layer rewrite).
"""
import logging

from sqlalchemy.orm import Session

from app.domain.copilot.service import CopilotService
from app.domain.dashboards.service import DashboardService
from app.domain.reports.pdf_builder import ReportWidget, build_dashboard_report
from app.domain.reports.xlsx_builder import build_dashboard_report_xlsx
from app.infrastructure.ai_gateway import AIGateway

logger = logging.getLogger("reports")


class ReportsService:
    def __init__(self, db: Session):
        self.db = db

    def _gather_report_data(
        self, workspace_id: str, dashboard_id: str, user_id: str, include_ai_summary: bool
    ) -> tuple[str, list[ReportWidget], str | None]:
        dashboard_service = DashboardService(self.db)
        dashboard = dashboard_service.get_or_404(dashboard_id, workspace_id, user_id)

        widget_models = dashboard_service.list_widgets(workspace_id, dashboard_id, user_id)
        report_widgets: list[ReportWidget] = []
        for widget in widget_models:
            data = dashboard_service.get_widget_data(workspace_id, dashboard_id, widget.id, user_id)
            report_widgets.append(ReportWidget(title=data.title, chart_type=data.chart_type, rows=data.data))

        summary = None
        if include_ai_summary and report_widgets:
            summary = self._try_generate_summary(workspace_id, widget_models[0].dataset_id, user_id)

        return dashboard.name, report_widgets, summary

    def generate_dashboard_pdf(
        self, workspace_id: str, dashboard_id: str, user_id: str, include_ai_summary: bool = False
    ) -> bytes:
        name, widgets, summary = self._gather_report_data(workspace_id, dashboard_id, user_id, include_ai_summary)
        return build_dashboard_report(dashboard_name=name, widgets=widgets, summary=summary)

    def generate_dashboard_xlsx(
        self, workspace_id: str, dashboard_id: str, user_id: str, include_ai_summary: bool = False
    ) -> bytes:
        name, widgets, summary = self._gather_report_data(workspace_id, dashboard_id, user_id, include_ai_summary)
        return build_dashboard_report_xlsx(dashboard_name=name, widgets=widgets, summary=summary)

    def _try_generate_summary(self, workspace_id: str, dataset_id: str, user_id: str) -> str | None:
        """Best-effort: a report should still generate even if AI Copilot isn't configured or errors out."""
        try:
            gateway = AIGateway()
            if not gateway.is_configured():
                return None
            return CopilotService(self.db, gateway).summarize(workspace_id, dataset_id, user_id)
        except Exception:
            logger.exception("AI summary generation failed for report; continuing without it")
            return None
