"""
Builds a dashboard report as PDF bytes using reportlab.

Kept as a pure function (title/widgets/summary in, bytes out) so it's
testable without touching the DB, matching the same pattern as
app.domain.etl.nodes and app.domain.forecasting.engine. The reports
service (service.py) is the only caller, and its job is just to gather
the dashboard/widget/summary data and hand it here.
"""
import io
from dataclasses import dataclass
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


@dataclass
class ReportWidget:
    title: str
    chart_type: str
    rows: list[dict]  # each row: {"dimension": ..., "value": ...}


def build_dashboard_report(
    dashboard_name: str,
    widgets: list[ReportWidget],
    summary: str | None = None,
    generated_at: datetime | None = None,
) -> bytes:
    generated_at = generated_at or datetime.utcnow()
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, topMargin=0.75 * inch, bottomMargin=0.75 * inch)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("ReportTitle", parent=styles["Title"], fontSize=20)
    section_style = ParagraphStyle("Section", parent=styles["Heading2"], spaceBefore=16, spaceAfter=8)

    story = [
        Paragraph(dashboard_name, title_style),
        Paragraph(f"Generated {generated_at.strftime('%Y-%m-%d %H:%M UTC')}", styles["Normal"]),
        Spacer(1, 0.25 * inch),
    ]

    if summary:
        story.append(Paragraph("Executive Summary", section_style))
        story.append(Paragraph(summary, styles["BodyText"]))
        story.append(Spacer(1, 0.15 * inch))

    if not widgets:
        story.append(Paragraph("This dashboard has no widgets yet.", styles["BodyText"]))

    for widget in widgets:
        story.append(Paragraph(f"{widget.title} ({widget.chart_type})", section_style))
        if not widget.rows:
            story.append(Paragraph("No data.", styles["BodyText"]))
            continue

        table_data = [["Dimension", "Value"]] + [
            [str(row.get("dimension", "")), _format_value(row.get("value"))] for row in widget.rows[:50]
        ]
        table = Table(table_data, colWidths=[3.5 * inch, 2 * inch])
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#3b5bfd")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]
            )
        )
        story.append(table)
        if len(widget.rows) > 50:
            story.append(Paragraph(f"... and {len(widget.rows) - 50} more rows", styles["Normal"]))
        story.append(Spacer(1, 0.2 * inch))

    doc.build(story)
    return buffer.getvalue()


def _format_value(value) -> str:
    if isinstance(value, (int, float)):
        return f"{value:,.2f}" if isinstance(value, float) else f"{value:,}"
    return str(value)
