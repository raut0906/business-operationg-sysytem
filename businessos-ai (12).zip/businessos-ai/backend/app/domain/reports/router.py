from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.reports.schemas import ReportGenerateRequest
from app.domain.reports.service import ReportsService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/reports", tags=["reports"])


@router.post("/dashboards/{dashboard_id}/pdf")
def generate_dashboard_pdf(
    workspace_id: str,
    dashboard_id: str,
    payload: ReportGenerateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    pdf_bytes = ReportsService(db).generate_dashboard_pdf(
        workspace_id, dashboard_id, current_user.id, include_ai_summary=payload.include_ai_summary
    )
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="dashboard-report-{dashboard_id}.pdf"'},
    )


@router.post("/dashboards/{dashboard_id}/xlsx")
def generate_dashboard_xlsx(
    workspace_id: str,
    dashboard_id: str,
    payload: ReportGenerateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    xlsx_bytes = ReportsService(db).generate_dashboard_xlsx(
        workspace_id, dashboard_id, current_user.id, include_ai_summary=payload.include_ai_summary
    )
    return Response(
        content=xlsx_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="dashboard-report-{dashboard_id}.xlsx"'},
    )
