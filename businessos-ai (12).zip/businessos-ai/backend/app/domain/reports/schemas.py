from pydantic import BaseModel


class ReportGenerateRequest(BaseModel):
    include_ai_summary: bool = False
