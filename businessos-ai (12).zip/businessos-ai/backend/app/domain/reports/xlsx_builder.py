"""
Builds a dashboard report as XLSX bytes using openpyxl.

Same pure-function pattern as pdf_builder.py: dashboard name + widgets +
optional summary in, bytes out, no DB access. Reuses the same ReportWidget
dataclass so the reports service can hand identical data to either builder
without any format-specific data shaping.

Layout: one "Summary" sheet (dashboard name, generation time, executive
summary if provided, and a table of contents linking to each widget's
sheet) plus one sheet per widget containing its full data as a real Excel
table (not just gridlines — an actual named Table object) so filtering/
sorting works immediately for whoever opens the file.
"""
import io
import re
from dataclasses import dataclass
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from app.domain.reports.pdf_builder import ReportWidget

_HEADER_FILL = PatternFill(start_color="3B5BFD", end_color="3B5BFD", fill_type="solid")
_HEADER_FONT = Font(color="FFFFFF", bold=True)
_TITLE_FONT = Font(size=16, bold=True)


def _safe_sheet_name(name: str, used_names: set[str]) -> str:
    """Excel sheet names: max 31 chars, no []:*?/\\, and must be unique within the workbook."""
    cleaned = re.sub(r"[\[\]:*?/\\]", "_", name)[:31] or "Sheet"
    candidate = cleaned
    suffix = 1
    while candidate in used_names:
        suffix += 1
        # Truncate further to leave room for the numeric suffix and stay under 31 chars.
        candidate = f"{cleaned[: 31 - len(str(suffix)) - 1]}_{suffix}"
    used_names.add(candidate)
    return candidate


def build_dashboard_report_xlsx(
    dashboard_name: str,
    widgets: list[ReportWidget],
    summary: str | None = None,
    generated_at: datetime | None = None,
) -> bytes:
    generated_at = generated_at or datetime.utcnow()
    wb = Workbook()

    summary_sheet = wb.active
    summary_sheet.title = "Summary"
    summary_sheet["A1"] = dashboard_name
    summary_sheet["A1"].font = _TITLE_FONT
    summary_sheet["A2"] = f"Generated {generated_at.strftime('%Y-%m-%d %H:%M UTC')}"
    summary_sheet.column_dimensions["A"].width = 40

    row = 4
    if summary:
        summary_sheet[f"A{row}"] = "Executive Summary"
        summary_sheet[f"A{row}"].font = Font(bold=True)
        row += 1
        summary_sheet[f"A{row}"] = summary
        summary_sheet[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        summary_sheet.row_dimensions[row].height = 60
        row += 2

    summary_sheet[f"A{row}"] = "Widgets"
    summary_sheet[f"A{row}"].font = Font(bold=True)
    row += 1

    used_sheet_names = {"Summary"}
    for widget in widgets:
        sheet_name = _safe_sheet_name(widget.title, used_sheet_names)
        summary_sheet[f"A{row}"] = f"{widget.title} ({widget.chart_type}) — see sheet '{sheet_name}'"
        row += 1
        _write_widget_sheet(wb, sheet_name, widget)

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


def _write_widget_sheet(wb: Workbook, sheet_name: str, widget: ReportWidget) -> None:
    ws = wb.create_sheet(sheet_name)
    ws["A1"] = widget.title
    ws["A1"].font = _TITLE_FONT

    if not widget.rows:
        ws["A3"] = "No data."
        return

    headers = ["Dimension", "Value"]
    header_row_idx = 3
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=header_row_idx, column=col_idx, value=header)
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL

    for row_offset, row in enumerate(widget.rows, start=1):
        ws.cell(row=header_row_idx + row_offset, column=1, value=row.get("dimension"))
        ws.cell(row=header_row_idx + row_offset, column=2, value=row.get("value"))

    last_row = header_row_idx + len(widget.rows)
    last_col_letter = get_column_letter(len(headers))
    table_ref = f"A{header_row_idx}:{last_col_letter}{last_row}"
    # Table names must be unique per workbook and alphanumeric/underscore only.
    table_name = "T_" + re.sub(r"[^A-Za-z0-9_]", "_", sheet_name)
    table = Table(displayName=table_name, ref=table_ref)
    table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
    ws.add_table(table)

    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 18
