"""
Forecasting engine.

Deliberately dependency-light: a linear-trend fit via numpy.polyfit rather
than Prophet/statsmodels. This keeps the engine testable without extra
dependencies and is a reasonable default for short-horizon business
metrics. Swapping in Prophet/statsmodels later is a drop-in replacement —
callers only depend on `forecast_series()`'s input/output shape, not on
how the fit is done internally, so nothing else needs to change.

Not suitable for: strongly seasonal data (weekly/yearly cycles), which a
linear fit will underfit. That's flagged in the response's `method` field
so the frontend/AI layer can be honest about it rather than silently
presenting a naive trend as more sophisticated than it is.
"""
from dataclasses import dataclass

import numpy as np
import pandas as pd


class ForecastError(Exception):
    pass


@dataclass
class ForecastPoint:
    period: str
    value: float
    lower_bound: float | None = None
    upper_bound: float | None = None


@dataclass
class ForecastResult:
    method: str
    history: list[ForecastPoint]
    forecast: list[ForecastPoint]
    warning: str | None = None


_FREQ_MAP = {"D": "D", "W": "W", "M": "MS"}
_MIN_POINTS = 3


def forecast_series(
    dates: pd.Series,
    values: pd.Series,
    periods: int,
    freq: str = "M",
) -> ForecastResult:
    """
    dates/values: raw (possibly duplicate-date, unsorted) observations —
    aggregated by summing values per period before fitting.
    periods: number of future periods to forecast.
    freq: "D" (daily), "W" (weekly), "M" (monthly).
    """
    if freq not in _FREQ_MAP:
        raise ForecastError(f"Unsupported frequency '{freq}', use one of {list(_FREQ_MAP)}")
    if periods < 1 or periods > 60:
        raise ForecastError("periods must be between 1 and 60")

    df = pd.DataFrame({"date": pd.to_datetime(dates, errors="coerce"), "value": pd.to_numeric(values, errors="coerce")})
    df = df.dropna(subset=["date", "value"])
    if df.empty:
        raise ForecastError("No valid (date, numeric value) pairs found in the selected columns")

    pandas_freq = _FREQ_MAP[freq]
    grouped = df.set_index("date")["value"].resample(pandas_freq).sum().reset_index()
    grouped.columns = ["date", "value"]
    grouped = grouped.sort_values("date").reset_index(drop=True)

    if len(grouped) < _MIN_POINTS:
        raise ForecastError(
            f"Need at least {_MIN_POINTS} historical periods to forecast, found {len(grouped)}. "
            "Try a coarser frequency (e.g. 'M' instead of 'D')."
        )

    x = np.arange(len(grouped))
    y = grouped["value"].to_numpy()

    # Linear trend fit: y = slope * x + intercept
    slope, intercept = np.polyfit(x, y, 1)
    fitted = slope * x + intercept
    residuals = y - fitted
    residual_std = float(np.std(residuals)) if len(residuals) > 1 else 0.0

    warning = None
    if len(grouped) < 6:
        warning = "Forecast is based on fewer than 6 historical periods — treat it as a rough estimate."

    history = [
        ForecastPoint(period=str(row.date.date()), value=round(float(row.value), 2))
        for row in grouped.itertuples()
    ]

    future_x = np.arange(len(grouped), len(grouped) + periods)
    future_dates = pd.date_range(
        start=grouped["date"].iloc[-1], periods=periods + 1, freq=pandas_freq
    )[1:]
    future_values = slope * future_x + intercept

    forecast = [
        ForecastPoint(
            period=str(date.date()),
            value=round(float(val), 2),
            lower_bound=round(float(val - 1.96 * residual_std), 2),
            upper_bound=round(float(val + 1.96 * residual_std), 2),
        )
        for date, val in zip(future_dates, future_values)
    ]

    return ForecastResult(method="linear_trend", history=history, forecast=forecast, warning=warning)
