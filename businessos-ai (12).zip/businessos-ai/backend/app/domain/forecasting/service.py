"""
Forecasting service — loads the requested columns from a security-filtered
DataFrame and hands them to the pure engine in app.domain.forecasting.engine.
Kept thin on purpose: all forecasting math lives in engine.py so it stays
testable without a database.

RLS/CLS enforcement: data comes from SecurityService.get_secured_dataframe
rather than the raw warehouse table, same as dashboards and Copilot — a
Viewer with row-level restrictions forecasts on their permitted rows only,
and a hidden column simply isn't present to be selected as a date/metric
column (surfacing as the same "column not found" error a genuinely
nonexistent column would produce, which is the right failure mode: the
user doesn't need to be told a column exists but is hidden from them).
"""
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.forecasting.engine import ForecastError, forecast_series
from app.domain.forecasting.schemas import ForecastRequest, ForecastResponse


class ForecastingService:
    def __init__(self, db: Session):
        self.db = db

    def forecast(self, workspace_id: str, payload: ForecastRequest, user_id: str) -> ForecastResponse:
        # Local import: avoids a module-level circular import (security imports
        # datasets/workspaces at module level; this direction stays one-way).
        from app.domain.security.service import SecurityService

        df, _applied, _hidden = SecurityService(self.db).get_secured_dataframe(
            payload.dataset_id, workspace_id, user_id
        )

        if payload.date_column not in df.columns:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Column '{payload.date_column}' not found. Available: {list(df.columns)}",
            )
        if payload.metric_column not in df.columns:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Column '{payload.metric_column}' not found. Available: {list(df.columns)}",
            )

        try:
            result = forecast_series(
                df[payload.date_column],
                df[payload.metric_column],
                periods=payload.periods,
                freq=payload.freq,
            )
        except ForecastError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

        return ForecastResponse(
            method=result.method,
            history=[h.__dict__ for h in result.history],
            forecast=[f.__dict__ for f in result.forecast],
            warning=result.warning,
        )
