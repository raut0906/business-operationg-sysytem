from pydantic import BaseModel, Field


class ForecastRequest(BaseModel):
    dataset_id: str
    date_column: str
    metric_column: str
    periods: int = Field(default=6, ge=1, le=60)
    freq: str = Field(default="M", pattern="^(D|W|M)$")


class ForecastPointOut(BaseModel):
    period: str
    value: float
    lower_bound: float | None = None
    upper_bound: float | None = None


class ForecastResponse(BaseModel):
    method: str
    history: list[ForecastPointOut]
    forecast: list[ForecastPointOut]
    warning: str | None = None
