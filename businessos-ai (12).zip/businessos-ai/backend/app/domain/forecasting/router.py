from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.forecasting.schemas import ForecastRequest, ForecastResponse
from app.domain.forecasting.service import ForecastingService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/forecasts", tags=["forecasting"])


@router.post("", response_model=ForecastResponse)
def create_forecast(
    workspace_id: str,
    payload: ForecastRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return ForecastingService(db).forecast(workspace_id, payload, current_user.id)
