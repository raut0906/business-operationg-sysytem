from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.alerts.schemas import AlertCreate, AlertEvaluation, AlertOut
from app.domain.alerts.service import AlertService
from app.domain.auth.models import User
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/alerts", tags=["alerts"])


@router.post("", response_model=AlertOut, status_code=201)
def create_alert(
    workspace_id: str,
    payload: AlertCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return AlertService(db).create(workspace_id, payload, current_user.id)


@router.get("", response_model=list[AlertOut])
def list_alerts(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return AlertService(db).list_for_workspace(workspace_id, current_user.id)


@router.post("/{alert_id}/evaluate", response_model=AlertEvaluation)
def evaluate_alert(
    workspace_id: str,
    alert_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return AlertService(db).evaluate(alert_id, workspace_id, current_user.id)
