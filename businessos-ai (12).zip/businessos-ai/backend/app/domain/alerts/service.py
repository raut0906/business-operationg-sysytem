from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.alerts.models import Alert
from app.domain.alerts.schemas import AlertCreate, AlertEvaluation
from app.domain.datasets.service import DatasetService
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService


class AlertService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, workspace_id: str, payload: AlertCreate, user_id: str) -> Alert:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        DatasetService(self.db).get_or_404(payload.dataset_id, workspace_id, user_id)

        alert = Alert(workspace_id=workspace_id, **payload.model_dump())
        self.db.add(alert)
        self.db.commit()
        self.db.refresh(alert)
        return alert

    def list_for_workspace(self, workspace_id: str, user_id: str) -> list[Alert]:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        return self.db.query(Alert).filter(Alert.workspace_id == workspace_id).all()

    def evaluate(self, alert_id: str, workspace_id: str, user_id: str) -> AlertEvaluation:
        """
        Evaluates an alert's condition against the current value, computed on
        the requesting user's security-filtered view of the data — a Viewer
        checking an alert's status shouldn't see a current_value derived from
        rows their RLS policy excludes them from.

        The scheduled worker (app/workers/alert_evaluator.py) does NOT call this
        method — it reimplements evaluation directly against the raw warehouse,
        since a background job checking a threshold the alert's Editor+ creator
        already configured is a different trust context than an interactive
        on-demand check by an arbitrary workspace member.
        """
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        alert = self.db.query(Alert).filter(Alert.id == alert_id, Alert.workspace_id == workspace_id).first()
        if not alert:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")

        from app.domain.dashboards.aggregation import AggregationError, aggregate_dataframe
        from app.domain.security.service import SecurityService

        df, _applied, hidden_columns = SecurityService(self.db).get_secured_dataframe(
            alert.dataset_id, workspace_id, user_id
        )
        if alert.metric in hidden_columns:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Metric column '{alert.metric}' is hidden for your role",
            )

        current_value = None
        if not df.empty:
            try:
                # Reuses the widget aggregation function with a constant dimension so the
                # whole (already-filtered) DataFrame collapses into a single aggregate value.
                scalar_df = df.assign(__alert_scope__=1)
                rows = aggregate_dataframe(scalar_df, "__alert_scope__", alert.metric, alert.aggregate)
                current_value = rows[0]["value"] if rows else None
            except AggregationError as exc:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

        is_triggered = False
        if current_value is not None:
            is_triggered = (
                current_value > alert.threshold if alert.condition == "above" else current_value < alert.threshold
            )

        alert.last_triggered_value = current_value
        self.db.commit()

        return AlertEvaluation(alert_id=alert.id, current_value=current_value, is_triggered=is_triggered)
