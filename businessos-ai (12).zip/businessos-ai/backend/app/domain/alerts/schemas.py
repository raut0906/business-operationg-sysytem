from pydantic import BaseModel, Field


class AlertCreate(BaseModel):
    dataset_id: str
    name: str
    metric: str
    aggregate: str = Field(default="SUM", pattern="^(SUM|AVG|COUNT|MIN|MAX)$")
    condition: str = Field(pattern="^(above|below)$")
    threshold: float


class AlertOut(BaseModel):
    id: str
    workspace_id: str
    dataset_id: str
    name: str
    metric: str
    aggregate: str
    condition: str
    threshold: float
    is_active: bool
    last_triggered_value: float | None = None

    model_config = {"from_attributes": True}


class AlertEvaluation(BaseModel):
    alert_id: str
    current_value: float | None
    is_triggered: bool
