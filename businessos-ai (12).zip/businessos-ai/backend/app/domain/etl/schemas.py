from pydantic import BaseModel, Field


class PipelineNode(BaseModel):
    id: str
    type: str = Field(description="One of: source, filter, select_columns, rename, derive, aggregate, sort, dedupe, clean, join, append, pivot, unpivot, normalize")
    config: dict = Field(default_factory=dict)


class PipelineCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    nodes: list[PipelineNode] = Field(default_factory=list)
    schedule_cron: str | None = None


class PipelineUpdate(BaseModel):
    name: str | None = None
    nodes: list[PipelineNode] | None = None
    schedule_cron: str | None = None
    is_active: bool | None = None


class PipelineOut(BaseModel):
    id: str
    workspace_id: str
    name: str
    nodes: list[PipelineNode]
    schedule_cron: str | None = None
    is_active: bool
    last_run_at: str | None = None

    model_config = {"from_attributes": True}


class PipelineRunRequest(BaseModel):
    output_dataset_name: str = Field(min_length=1, description="Name for the resulting dataset in the warehouse")


class NodeLog(BaseModel):
    node_id: str
    node_type: str
    status: str  # success | failed
    message: str
    rows_before: int | None = None
    rows_after: int | None = None
    duration_ms: float | None = None


class PipelineRunOut(BaseModel):
    id: str
    pipeline_id: str
    status: str
    started_at: str | None = None
    finished_at: str | None = None
    rows_processed: int | None = None
    output_dataset_id: str | None = None
    error_message: str | None = None
    logs: list[NodeLog]

    model_config = {"from_attributes": True}
