"""
ETL node execution engine.

Each node is a plain dict: {"id": str, "type": str, "config": {...}}.
The engine executes a linear chain (each node transforms the previous
node's DataFrame) — this covers filter/clean/aggregate/derive/shape
pipelines, which is the large majority of real ETL usage.

`join` and `append` nodes bring in a *second* dataset without requiring a
full branching DAG: their config names another dataset by ID, and the
runner supplies a `load_dataset(dataset_id) -> DataFrame` callable so the
engine can fetch it. This keeps every other node pure (DataFrame + config
in, DataFrame out) while still supporting real two-source operations.
True multi-node branching (where the second input is itself the output of
another node in the same pipeline, not a directly-named dataset) remains
a documented extension beyond this.

Every handler must raise NodeExecutionError with a clear message on bad
input — the pipeline runner catches this to produce useful run logs
instead of a raw traceback.
"""
import operator as _op
from typing import Callable

import pandas as pd


class NodeExecutionError(Exception):
    """Raised by a node handler when its config is invalid or execution fails."""


DatasetLoader = Callable[[str], pd.DataFrame]

_FILTER_OPS: dict[str, Callable | None] = {
    "eq": _op.eq,
    "neq": _op.ne,
    "gt": _op.gt,
    "gte": _op.ge,
    "lt": _op.lt,
    "lte": _op.le,
    "contains": None,  # handled specially in _node_filter, not via a comparison operator
}

_DERIVE_OPS: dict[str, Callable] = {
    "add": _op.add,
    "subtract": _op.sub,
    "multiply": _op.mul,
    "divide": _op.truediv,
}

_AGG_FUNCS = {"sum", "mean", "count", "min", "max"}
_JOIN_TYPES = {"inner", "left", "right", "outer"}


def _require_column(df: pd.DataFrame, column: str, node_type: str) -> None:
    if column not in df.columns:
        raise NodeExecutionError(f"[{node_type}] column '{column}' not found. Available: {list(df.columns)}")


def _node_source(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    # Source node's DataFrame is loaded by the runner before this is called; it's a passthrough here.
    return df


def _node_filter(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    column, op, value = config.get("column"), config.get("operator"), config.get("value")
    if not column or op not in _FILTER_OPS:
        raise NodeExecutionError(f"[filter] requires 'column' and a valid 'operator' from {list(_FILTER_OPS)}")
    _require_column(df, column, "filter")

    if op == "contains":
        return df[df[column].astype(str).str.contains(str(value), na=False)]

    # Attempt numeric comparison first (common case), fall back to string comparison.
    try:
        numeric_value = float(value)
        return df[_FILTER_OPS[op](pd.to_numeric(df[column], errors="coerce"), numeric_value)]
    except (TypeError, ValueError):
        return df[_FILTER_OPS[op](df[column].astype(str), str(value))]


def _node_select_columns(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    columns = config.get("columns") or []
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise NodeExecutionError(f"[select_columns] not found: {missing}")
    return df[columns]


def _node_rename(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    mapping = config.get("mapping") or {}
    missing = [c for c in mapping if c not in df.columns]
    if missing:
        raise NodeExecutionError(f"[rename] not found: {missing}")
    return df.rename(columns=mapping)


def _node_derive(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    new_column, left, op, right = (
        config.get("new_column"), config.get("left_column"), config.get("operator"), config.get("right")
    )
    if not new_column or op not in _DERIVE_OPS:
        raise NodeExecutionError(f"[derive] requires 'new_column' and 'operator' from {list(_DERIVE_OPS)}")
    _require_column(df, left, "derive")

    left_series = pd.to_numeric(df[left], errors="coerce")
    if isinstance(right, str) and right in df.columns:
        right_series = pd.to_numeric(df[right], errors="coerce")
    else:
        try:
            right_series = float(right)
        except (TypeError, ValueError):
            raise NodeExecutionError(f"[derive] 'right' must be a column name or a number, got {right!r}")

    result = df.copy()
    result[new_column] = _DERIVE_OPS[op](left_series, right_series)
    return result


def _node_aggregate(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    group_by = config.get("group_by") or []
    aggregations = config.get("aggregations") or []
    if not group_by or not aggregations:
        raise NodeExecutionError("[aggregate] requires 'group_by' (list) and 'aggregations' (list)")
    for col in group_by:
        _require_column(df, col, "aggregate")

    agg_map = {}
    for agg in aggregations:
        col, func = agg.get("column"), agg.get("func")
        if func not in _AGG_FUNCS:
            raise NodeExecutionError(f"[aggregate] unsupported func '{func}', use one of {_AGG_FUNCS}")
        _require_column(df, col, "aggregate")
        agg_map[col] = func

    result = df.groupby(group_by, as_index=False).agg(agg_map)
    return result


def _node_sort(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    column, ascending = config.get("column"), config.get("ascending", True)
    _require_column(df, column, "sort")
    return df.sort_values(by=column, ascending=bool(ascending))


def _node_dedupe(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    subset = config.get("columns") or None
    if subset:
        for col in subset:
            _require_column(df, col, "dedupe")
    return df.drop_duplicates(subset=subset)


def _node_clean(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    """Drops null rows for given columns, and/or fills nulls with a default value."""
    dropna_columns = config.get("dropna_columns") or []
    fill_value = config.get("fill_value")
    fill_columns = config.get("fill_columns") or []

    result = df
    if dropna_columns:
        for col in dropna_columns:
            _require_column(result, col, "clean")
        result = result.dropna(subset=dropna_columns)
    if fill_columns and fill_value is not None:
        for col in fill_columns:
            _require_column(result, col, "clean")
        result = result.fillna({col: fill_value for col in fill_columns})
    return result


def _node_join(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    """
    Joins the current DataFrame (left) against another dataset (right),
    named by ID in config — not by referencing another node in this
    pipeline. See module docstring for why.
    """
    right_dataset_id = config.get("right_dataset_id")
    left_on, right_on = config.get("left_on"), config.get("right_on")
    how = config.get("how", "inner")

    if not right_dataset_id or not left_on or not right_on:
        raise NodeExecutionError("[join] requires 'right_dataset_id', 'left_on', and 'right_on'")
    if how not in _JOIN_TYPES:
        raise NodeExecutionError(f"[join] 'how' must be one of {_JOIN_TYPES}, got {how!r}")
    if load_dataset is None:
        raise NodeExecutionError("[join] no dataset loader available — this node type requires warehouse access")
    _require_column(df, left_on, "join")

    right_df = load_dataset(right_dataset_id)
    if right_on not in right_df.columns:
        raise NodeExecutionError(
            f"[join] right dataset has no column '{right_on}'. Available: {list(right_df.columns)}"
        )

    # suffixes avoid silently dropping same-named columns from either side
    return df.merge(right_df, left_on=left_on, right_on=right_on, how=how, suffixes=("", "_right"))


def _node_append(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    """
    Appends (row-wise unions) another dataset onto the current one.
    Columns that exist in only one side become null-filled in the other,
    same as a SQL UNION with mismatched schemas — this is intentional
    rather than an error, since real-world "append" use cases often merge
    similar-but-not-identical schemas (e.g. monthly export files that
    gained a column partway through the year).
    """
    other_dataset_id = config.get("other_dataset_id")
    if not other_dataset_id:
        raise NodeExecutionError("[append] requires 'other_dataset_id'")
    if load_dataset is None:
        raise NodeExecutionError("[append] no dataset loader available — this node type requires warehouse access")

    other_df = load_dataset(other_dataset_id)
    combined = pd.concat([df, other_df], ignore_index=True, sort=False)
    if config.get("dedupe", False):
        combined = combined.drop_duplicates()
    return combined


def _node_pivot(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    """
    Reshapes long data into wide: one row per unique combination of `index`
    columns, one column per unique value in `columns`, populated by
    aggregating `values`. E.g. {region, month, revenue} rows -> one row per
    region with a column per month.
    """
    index = config.get("index")
    columns = config.get("columns")
    values = config.get("values")
    agg = (config.get("agg") or "sum").lower()
    if not index or not columns or not values:
        raise NodeExecutionError("[pivot] requires 'index' (list), 'columns' (str), and 'values' (str)")
    if isinstance(index, str):
        index = [index]

    for col in [*index, columns, values]:
        _require_column(df, col, "pivot")
    if agg not in _AGG_FUNCS:
        raise NodeExecutionError(f"[pivot] unsupported agg '{agg}', use one of {_AGG_FUNCS}")

    try:
        result = pd.pivot_table(df, index=index, columns=columns, values=values, aggfunc=agg)
    except Exception as exc:
        raise NodeExecutionError(f"[pivot] failed: {exc}") from exc
    result.columns = [str(c) for c in result.columns]
    return result.reset_index()


def _node_unpivot(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    """
    Reshapes wide data into long: keeps `id_vars` as-is, and melts every
    other listed `value_vars` column into two new columns (a category
    column named `var_name` and a value column named `value_name`). The
    inverse of pivot — e.g. {region, jan, feb, mar} -> {region, month, revenue}.
    """
    id_vars = config.get("id_vars") or []
    value_vars = config.get("value_vars")
    var_name = config.get("var_name", "variable")
    value_name = config.get("value_name", "value")
    if not value_vars:
        raise NodeExecutionError("[unpivot] requires 'value_vars' (list of columns to unpivot)")
    if isinstance(id_vars, str):
        id_vars = [id_vars]

    for col in [*id_vars, *value_vars]:
        _require_column(df, col, "unpivot")

    return pd.melt(df, id_vars=id_vars, value_vars=value_vars, var_name=var_name, value_name=value_name)


def _node_normalize(df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None) -> pd.DataFrame:
    """
    Scales numeric columns in place. method="minmax" rescales each column
    to [0, 1]; method="zscore" rescales to mean 0, std 1. A constant column
    (zero range/std) is left as all-zeros rather than dividing by zero.
    """
    columns = config.get("columns")
    method = (config.get("method") or "minmax").lower()
    if not columns:
        raise NodeExecutionError("[normalize] requires 'columns' (list)")
    if method not in ("minmax", "zscore"):
        raise NodeExecutionError(f"[normalize] unsupported method '{method}', use 'minmax' or 'zscore'")

    result = df.copy()
    for col in columns:
        _require_column(result, col, "normalize")
        series = pd.to_numeric(result[col], errors="coerce")
        if method == "minmax":
            span = series.max() - series.min()
            result[col] = (series - series.min()) / span if span != 0 else 0.0
        else:
            std = series.std()
            result[col] = (series - series.mean()) / std if std and std != 0 else 0.0
    return result


NODE_REGISTRY: dict[str, Callable[..., pd.DataFrame]] = {
    "source": _node_source,
    "filter": _node_filter,
    "select_columns": _node_select_columns,
    "rename": _node_rename,
    "derive": _node_derive,
    "aggregate": _node_aggregate,
    "sort": _node_sort,
    "dedupe": _node_dedupe,
    "clean": _node_clean,
    "join": _node_join,
    "append": _node_append,
    "pivot": _node_pivot,
    "unpivot": _node_unpivot,
    "normalize": _node_normalize,
}


def execute_node(
    node_type: str, df: pd.DataFrame, config: dict, load_dataset: DatasetLoader | None = None
) -> pd.DataFrame:
    handler = NODE_REGISTRY.get(node_type)
    if not handler:
        raise NodeExecutionError(f"Unknown node type '{node_type}'. Supported: {list(NODE_REGISTRY)}")
    return handler(df, config, load_dataset)
