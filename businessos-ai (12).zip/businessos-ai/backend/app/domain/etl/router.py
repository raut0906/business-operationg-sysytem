import json

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.etl.models import Pipeline, PipelineRun
from app.domain.etl.schemas import (
    PipelineCreate,
    PipelineOut,
    PipelineRunOut,
    PipelineRunRequest,
    PipelineUpdate,
)
from app.domain.etl.service import PipelineService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/pipelines", tags=["etl"])


def _to_pipeline_out(pipeline: Pipeline) -> PipelineOut:
    return PipelineOut(
        id=pipeline.id,
        workspace_id=pipeline.workspace_id,
        name=pipeline.name,
        nodes=json.loads(pipeline.nodes_json),
        schedule_cron=pipeline.schedule_cron,
        is_active=pipeline.is_active,
        last_run_at=pipeline.last_run_at,
    )


def _to_run_out(run: PipelineRun) -> PipelineRunOut:
    return PipelineRunOut(
        id=run.id,
        pipeline_id=run.pipeline_id,
        status=run.status,
        started_at=run.started_at,
        finished_at=run.finished_at,
        rows_processed=run.rows_processed,
        output_dataset_id=run.output_dataset_id,
        error_message=run.error_message,
        logs=json.loads(run.logs_json or "[]"),
    )


@router.post("", response_model=PipelineOut, status_code=201)
def create_pipeline(
    workspace_id: str,
    payload: PipelineCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _to_pipeline_out(PipelineService(db).create(workspace_id, payload, current_user.id))


@router.get("", response_model=list[PipelineOut])
def list_pipelines(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return [_to_pipeline_out(p) for p in PipelineService(db).list_for_workspace(workspace_id, current_user.id)]


@router.get("/{pipeline_id}", response_model=PipelineOut)
def get_pipeline(
    workspace_id: str,
    pipeline_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _to_pipeline_out(PipelineService(db).get_or_404(pipeline_id, workspace_id, current_user.id))


@router.patch("/{pipeline_id}", response_model=PipelineOut)
def update_pipeline(
    workspace_id: str,
    pipeline_id: str,
    payload: PipelineUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _to_pipeline_out(PipelineService(db).update(pipeline_id, workspace_id, payload, current_user.id))


@router.delete("/{pipeline_id}", status_code=204)
def delete_pipeline(
    workspace_id: str,
    pipeline_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    PipelineService(db).delete(pipeline_id, workspace_id, current_user.id)


@router.post("/{pipeline_id}/run", response_model=PipelineRunOut, status_code=201)
def run_pipeline(
    workspace_id: str,
    pipeline_id: str,
    payload: PipelineRunRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _to_run_out(PipelineService(db).run(pipeline_id, workspace_id, payload, current_user.id))


@router.get("/{pipeline_id}/runs", response_model=list[PipelineRunOut])
def list_runs(
    workspace_id: str,
    pipeline_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return [_to_run_out(r) for r in PipelineService(db).list_runs(pipeline_id, workspace_id, current_user.id)]
