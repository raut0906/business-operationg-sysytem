"""
Pipeline CRUD plus the run orchestrator.

The orchestrator's job is thin on purpose: load the source dataset, walk
the node list calling app.domain.etl.nodes.execute_node for each step,
record a log entry per node, and write the final DataFrame back into the
warehouse as a new dataset. All transformation logic lives in nodes.py so
it can be unit-tested without touching the DB or HTTP layers.
"""
import json
import time
from datetime import datetime, timezone

import pandas as pd
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.datasets.models import Dataset
from app.domain.datasets.service import DatasetService
from app.domain.etl.models import Pipeline, PipelineRun
from app.domain.etl.nodes import NodeExecutionError, execute_node
from app.domain.etl.schemas import PipelineCreate, PipelineRunRequest, PipelineUpdate
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService
from app.infrastructure import duckdb_client


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class PipelineService:
    def __init__(self, db: Session):
        self.db = db

    # ---- CRUD -----------------------------------------------------------

    def create(self, workspace_id: str, payload: PipelineCreate, user_id: str) -> Pipeline:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        pipeline = Pipeline(
            workspace_id=workspace_id,
            name=payload.name,
            nodes_json=json.dumps([n.model_dump() for n in payload.nodes]),
            schedule_cron=payload.schedule_cron,
        )
        self.db.add(pipeline)
        self.db.commit()
        self.db.refresh(pipeline)
        return pipeline

    def list_for_workspace(self, workspace_id: str, user_id: str) -> list[Pipeline]:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        return self.db.query(Pipeline).filter(Pipeline.workspace_id == workspace_id).all()

    def get_or_404(self, pipeline_id: str, workspace_id: str, user_id: str) -> Pipeline:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        pipeline = (
            self.db.query(Pipeline)
            .filter(Pipeline.id == pipeline_id, Pipeline.workspace_id == workspace_id)
            .first()
        )
        if not pipeline:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Pipeline not found")
        return pipeline

    def update(self, pipeline_id: str, workspace_id: str, payload: PipelineUpdate, user_id: str) -> Pipeline:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        pipeline = self.get_or_404(pipeline_id, workspace_id, user_id)
        if payload.name is not None:
            pipeline.name = payload.name
        if payload.nodes is not None:
            pipeline.nodes_json = json.dumps([n.model_dump() for n in payload.nodes])
        if payload.schedule_cron is not None:
            pipeline.schedule_cron = payload.schedule_cron
        if payload.is_active is not None:
            pipeline.is_active = payload.is_active
        self.db.commit()
        self.db.refresh(pipeline)
        return pipeline

    def delete(self, pipeline_id: str, workspace_id: str, user_id: str) -> None:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        pipeline = self.get_or_404(pipeline_id, workspace_id, user_id)
        self.db.delete(pipeline)
        self.db.commit()

    # ---- Execution --------------------------------------------------------

    def run(self, pipeline_id: str, workspace_id: str, payload: PipelineRunRequest, user_id: str) -> PipelineRun:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        pipeline = self.get_or_404(pipeline_id, workspace_id, user_id)
        nodes = json.loads(pipeline.nodes_json)
        if not nodes:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Pipeline has no nodes")
        if nodes[0]["type"] != "source":
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="First node must be type 'source'")

        run = PipelineRun(pipeline_id=pipeline.id, status="running", started_at=_now_iso())
        self.db.add(run)
        self.db.commit()
        self.db.refresh(run)

        logs: list[dict] = []

        # Local import: avoids a module-level circular import (security imports
        # datasets/workspaces at module level; this direction stays one-way).
        from app.domain.security.service import SecurityService

        def load_dataset(dataset_id: str) -> pd.DataFrame:
            """
            Resolves a dataset ID (used by join/append node configs) to its
            security-filtered DataFrame. Reuses the same 403/404 checks as
            everything else — a join node can't be used to read a dataset from
            a workspace the caller doesn't have access to, and RLS/CLS applies
            here exactly as it does to the pipeline's own source dataset, so a
            join can't be used to sidestep a restriction that would otherwise
            apply.
            """
            df, _applied, _hidden = SecurityService(self.db).get_secured_dataframe(dataset_id, workspace_id, user_id)
            return df

        try:
            source_dataset_id = nodes[0].get("config", {}).get("dataset_id")
            dataset = DatasetService(self.db).get_or_404(source_dataset_id, workspace_id, user_id)
            df, _applied, _hidden = SecurityService(self.db).get_secured_dataframe(
                source_dataset_id, workspace_id, user_id
            )
            logs.append(
                {
                    "node_id": nodes[0]["id"], "node_type": "source", "status": "success",
                    "message": f"Loaded {len(df)} rows from '{dataset.name}'",
                    "rows_before": None, "rows_after": len(df), "duration_ms": 0.0,
                }
            )

            for node in nodes[1:]:
                start = time.perf_counter()
                rows_before = len(df)
                try:
                    df = execute_node(node["type"], df, node.get("config", {}), load_dataset=load_dataset)
                    duration_ms = (time.perf_counter() - start) * 1000
                    logs.append(
                        {
                            "node_id": node["id"], "node_type": node["type"], "status": "success",
                            "message": f"{rows_before} -> {len(df)} rows",
                            "rows_before": rows_before, "rows_after": len(df), "duration_ms": round(duration_ms, 2),
                        }
                    )
                except NodeExecutionError as exc:
                    logs.append(
                        {
                            "node_id": node["id"], "node_type": node["type"], "status": "failed",
                            "message": str(exc), "rows_before": rows_before, "rows_after": None,
                            "duration_ms": round((time.perf_counter() - start) * 1000, 2),
                        }
                    )
                    raise

            output_table_name = duckdb_client.load_dataframe(workspace_id, payload.output_dataset_name, df)
            output_dataset = Dataset(
                workspace_id=workspace_id,
                name=payload.output_dataset_name,
                warehouse_table_name=output_table_name,
                source_type="etl_pipeline",
                row_count=len(df),
                schema_json=json.dumps([{"name": c, "dtype": str(t)} for c, t in df.dtypes.items()]),
            )
            self.db.add(output_dataset)
            self.db.flush()

            run.status = "success"
            run.rows_processed = len(df)
            run.output_dataset_id = output_dataset.id
            run.finished_at = _now_iso()
            run.logs_json = json.dumps(logs)
            pipeline.last_run_at = run.finished_at
            self.db.commit()
            self.db.refresh(run)
            return run

        except Exception as exc:  # noqa: BLE001 - intentionally broad to guarantee the run record always closes out
            run.status = "failed"
            run.finished_at = _now_iso()
            run.error_message = str(exc)
            run.logs_json = json.dumps(logs)
            self.db.commit()
            self.db.refresh(run)
            if isinstance(exc, HTTPException):
                raise
            return run

    def list_runs(self, pipeline_id: str, workspace_id: str, user_id: str) -> list[PipelineRun]:
        self.get_or_404(pipeline_id, workspace_id, user_id)
        return (
            self.db.query(PipelineRun)
            .filter(PipelineRun.pipeline_id == pipeline_id)
            .order_by(PipelineRun.created_at.desc())
            .all()
        )
