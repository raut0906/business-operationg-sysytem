from sqlalchemy import Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.shared.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.infrastructure.db import Base


class Pipeline(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "etl_pipelines"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    # JSON-encoded ordered list of node definitions. See app/domain/etl/nodes.py for the schema
    # each node type expects. v1 executes nodes as a linear chain (each node's output feeds the
    # next); a full DAG with branching/joins is a documented extension point, not implemented here.
    nodes_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    schedule_cron: Mapped[str] = mapped_column(String(100), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_run_at: Mapped[str] = mapped_column(String(50), nullable=True)


class PipelineRun(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "etl_runs"

    pipeline_id: Mapped[str] = mapped_column(ForeignKey("etl_pipelines.id"), index=True, nullable=False)
    # queued | running | success | failed
    status: Mapped[str] = mapped_column(String(20), default="queued")
    started_at: Mapped[str] = mapped_column(String(50), nullable=True)
    finished_at: Mapped[str] = mapped_column(String(50), nullable=True)
    rows_processed: Mapped[int] = mapped_column(Integer, nullable=True)
    output_dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=True)
    error_message: Mapped[str] = mapped_column(Text, nullable=True)
    # JSON-encoded list of {node_id, node_type, status, message, rows_before, rows_after, duration_ms}
    logs_json: Mapped[str] = mapped_column(Text, default="[]")
