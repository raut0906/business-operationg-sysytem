"""
ML domain service — orchestrates training (loading data from the
warehouse, calling the pure engine, persisting the fitted estimator via
joblib) and prediction (loading a persisted estimator and running it on
new rows). All the actual ML logic lives in engine.py; this file is
intentionally just plumbing.
"""
import json
import os

import joblib
import pandas as pd
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.domain.datasets.service import DatasetService
from app.domain.ml.engine import (
    MLTrainingError,
    train_classification,
    train_clustering,
    train_regression,
)
from app.domain.ml.models import MLModel
from app.domain.ml.schemas import MLModelCreate
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService

settings = get_settings()


def _model_artifact_dir(workspace_id: str) -> str:
    path = os.path.join(settings.warehouse_dir, "ml_models", workspace_id)
    os.makedirs(path, exist_ok=True)
    return path


class MLService:
    def __init__(self, db: Session):
        self.db = db

    def train(self, workspace_id: str, payload: MLModelCreate, user_id: str) -> MLModel:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)
        # Confirms the dataset exists/belongs to this workspace before creating the MLModel row.
        DatasetService(self.db).get_or_404(payload.dataset_id, workspace_id, user_id)

        if payload.model_type in ("regression", "classification") and not payload.target_column:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"target_column is required for model_type '{payload.model_type}'",
            )

        ml_model = MLModel(
            workspace_id=workspace_id,
            dataset_id=payload.dataset_id,
            name=payload.name,
            model_type=payload.model_type,
            algorithm="",
            target_column=payload.target_column,
            feature_columns_json=json.dumps(payload.feature_columns),
            status="training",
            created_by=user_id,
        )
        self.db.add(ml_model)
        self.db.commit()
        self.db.refresh(ml_model)

        try:
            # Local import: avoids a module-level circular import (security imports
            # datasets/workspaces at module level; this direction stays one-way).
            from app.domain.security.service import SecurityService

            # RLS/CLS enforcement: trains on the requesting user's security-filtered view of
            # the data, not the raw warehouse table — a Viewer with row-level restrictions
            # can't train a model (or see feature importance) derived from rows they can't see.
            df, _applied, hidden_columns = SecurityService(self.db).get_secured_dataframe(
                payload.dataset_id, workspace_id, user_id
            )
            requested_columns = list(payload.feature_columns) + (
                [payload.target_column] if payload.target_column else []
            )
            blocked = [c for c in requested_columns if c in hidden_columns]
            if blocked:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Columns hidden for your role can't be used to train a model: {blocked}",
                )

            if payload.model_type == "regression":
                result = train_regression(df, payload.feature_columns, payload.target_column, algorithm=payload.algorithm)
            elif payload.model_type == "classification":
                result = train_classification(df, payload.feature_columns, payload.target_column, algorithm=payload.algorithm)
            else:
                result = train_clustering(df, payload.feature_columns, payload.n_clusters)

            artifact_path = os.path.join(_model_artifact_dir(workspace_id), f"{ml_model.id}.joblib")
            joblib.dump(
                {
                    "estimator": result.estimator,
                    "label_encoder": result.label_encoder,
                    "feature_columns": payload.feature_columns,
                },
                artifact_path,
            )

            ml_model.algorithm = result.algorithm
            ml_model.metrics_json = json.dumps(result.metrics)
            ml_model.feature_importance_json = json.dumps(result.feature_importance)
            ml_model.candidates_json = json.dumps(result.candidates)
            ml_model.artifact_path = artifact_path
            ml_model.status = "ready"
            self.db.commit()
            self.db.refresh(ml_model)
            return ml_model

        except MLTrainingError as exc:
            ml_model.status = "failed"
            ml_model.error_message = str(exc)
            self.db.commit()
            self.db.refresh(ml_model)
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    def list_for_workspace(self, workspace_id: str, user_id: str) -> list[MLModel]:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        return self.db.query(MLModel).filter(MLModel.workspace_id == workspace_id).all()

    def get_or_404(self, model_id: str, workspace_id: str, user_id: str) -> MLModel:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        model = self.db.query(MLModel).filter(MLModel.id == model_id, MLModel.workspace_id == workspace_id).first()
        if not model:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Model not found")
        return model

    def predict(self, model_id: str, workspace_id: str, rows: list[dict], user_id: str) -> list:
        ml_model = self.get_or_404(model_id, workspace_id, user_id)
        if ml_model.status != "ready" or not ml_model.artifact_path:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Model is not ready for prediction")
        if ml_model.model_type == "clustering":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Clustering models assign clusters at training time; use the training result's cluster_sizes instead of /predict",
            )

        artifact = joblib.load(ml_model.artifact_path)
        estimator = artifact["estimator"]
        label_encoder = artifact["label_encoder"]
        feature_columns = artifact["feature_columns"]

        input_df = pd.DataFrame(rows)
        missing = [c for c in feature_columns if c not in input_df.columns]
        if missing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Missing required feature columns in prediction input: {missing}",
            )

        X = input_df[feature_columns]
        non_numeric = X.select_dtypes(exclude="number").columns.tolist()
        if non_numeric:
            X = pd.get_dummies(X, columns=non_numeric, drop_first=True)
            # Align columns with what the model was trained on (missing dummy columns -> 0).
            X = X.reindex(columns=estimator.feature_names_in_, fill_value=0)

        raw_predictions = estimator.predict(X)
        if label_encoder is not None:
            return label_encoder.inverse_transform(raw_predictions).tolist()
        return raw_predictions.tolist()
