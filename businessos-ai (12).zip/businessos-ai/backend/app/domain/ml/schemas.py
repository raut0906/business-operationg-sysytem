from pydantic import BaseModel, Field


class MLModelCreate(BaseModel):
    dataset_id: str
    name: str = Field(min_length=1, max_length=255)
    model_type: str = Field(pattern="^(regression|classification|clustering)$")
    feature_columns: list[str] = Field(min_length=1)
    target_column: str | None = None  # required for regression/classification, ignored for clustering
    n_clusters: int = Field(default=3, ge=2, le=20)  # only used for clustering
    # "auto" trains every candidate algorithm for the model_type and keeps the best one (by its
    # primary metric), returning every candidate's metrics in `candidates` for comparison.
    # Otherwise: regression -> linear|random_forest|gradient_boosting,
    #            classification -> logistic|random_forest|gradient_boosting.
    # Ignored for clustering (always KMeans).
    algorithm: str = Field(default="auto")


class ModelCandidate(BaseModel):
    algorithm: str
    metrics: dict


class MLModelOut(BaseModel):
    id: str
    workspace_id: str
    dataset_id: str
    name: str
    model_type: str
    algorithm: str
    target_column: str | None
    feature_columns: list[str]
    metrics: dict
    feature_importance: dict
    candidates: list[ModelCandidate] = Field(default_factory=list)
    status: str
    error_message: str | None = None

    model_config = {"from_attributes": True}


class MLPredictRequest(BaseModel):
    rows: list[dict] = Field(min_length=1, description="List of feature-column -> value dicts to predict on")


class MLPredictResponse(BaseModel):
    predictions: list
