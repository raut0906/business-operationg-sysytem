"""
ML training engine.

Pure functions: DataFrame + column names in, a fitted estimator + metrics
dict out. No DB or file I/O here — the service layer (service.py) handles
persistence via joblib and dataset loading via the warehouse client. This
mirrors the same pattern as app.domain.etl.nodes and
app.domain.forecasting.engine: business logic stays testable without
touching infrastructure.

Multiple algorithms are supported per model type (not just one fixed
choice), and algorithm="auto" trains every candidate and returns the best
one by its primary metric, alongside every candidate's metrics for
comparison — this is what the original brief's "Model Comparison" /
"AutoML" requirement actually asked for, rather than a single hardcoded
estimator per model type.
"""
from dataclasses import dataclass, field
from typing import Literal

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.ensemble import (
    GradientBoostingClassifier,
    GradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    mean_absolute_error,
    precision_score,
    r2_score,
    recall_score,
    root_mean_squared_error,
    silhouette_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

ModelType = Literal["regression", "classification", "clustering"]

REGRESSION_ALGORITHMS = {"linear", "random_forest", "gradient_boosting"}
CLASSIFICATION_ALGORITHMS = {"logistic", "random_forest", "gradient_boosting"}


class MLTrainingError(Exception):
    pass


@dataclass
class TrainingResult:
    model_type: ModelType
    algorithm: str
    metrics: dict
    feature_importance: dict = field(default_factory=dict)
    estimator: object = None  # the fitted sklearn estimator, for the service layer to persist
    label_encoder: object = None  # only set for classification with non-numeric targets
    # Populated only when algorithm="auto": every candidate tried, each as
    # {"algorithm": str, "metrics": dict} — lets the caller show a comparison
    # table rather than only the winning model.
    candidates: list = field(default_factory=list)


_MIN_ROWS = 10


def _prepare_features(df: pd.DataFrame, feature_columns: list[str]) -> pd.DataFrame:
    missing = [c for c in feature_columns if c not in df.columns]
    if missing:
        raise MLTrainingError(f"Feature columns not found: {missing}")
    X = df[feature_columns].copy()
    # One-hot encode any non-numeric feature columns rather than silently dropping them —
    # a common real-world case (e.g. "region" as a feature) shouldn't just be ignored.
    non_numeric = X.select_dtypes(exclude="number").columns.tolist()
    if non_numeric:
        X = pd.get_dummies(X, columns=non_numeric, drop_first=True)
    X = X.fillna(X.mean(numeric_only=True))
    return X


def _feature_importance(model, columns) -> dict:
    """
    Tree ensembles expose feature_importances_ directly. Linear/logistic models
    don't — the closest analog is the absolute coefficient magnitude, which
    isn't the same statistical concept (it's not scale-invariant without
    standardized inputs) but is still the standard "which feature mattered
    more" signal to surface for those model types, so it's labeled as such
    rather than silently omitted.
    """
    if hasattr(model, "feature_importances_"):
        return dict(zip(columns, [round(float(v), 4) for v in model.feature_importances_]))
    if hasattr(model, "coef_"):
        coefs = model.coef_
        coefs = coefs[0] if coefs.ndim > 1 else coefs
        return dict(zip(columns, [round(float(abs(v)), 4) for v in coefs]))
    return {}


def _build_regressor(algorithm: str):
    if algorithm == "linear":
        return LinearRegression()
    if algorithm == "random_forest":
        return RandomForestRegressor(n_estimators=100, random_state=42, max_depth=10)
    if algorithm == "gradient_boosting":
        return GradientBoostingRegressor(random_state=42)
    raise MLTrainingError(f"Unsupported regression algorithm '{algorithm}', use one of {REGRESSION_ALGORITHMS}")


def _build_classifier(algorithm: str):
    if algorithm == "logistic":
        return LogisticRegression(max_iter=1000)
    if algorithm == "random_forest":
        return RandomForestClassifier(n_estimators=100, random_state=42, max_depth=10)
    if algorithm == "gradient_boosting":
        return GradientBoostingClassifier(random_state=42)
    raise MLTrainingError(f"Unsupported classification algorithm '{algorithm}', use one of {CLASSIFICATION_ALGORITHMS}")


def train_regression(
    df: pd.DataFrame, feature_columns: list[str], target_column: str, algorithm: str = "random_forest",
    test_size: float = 0.2,
) -> TrainingResult:
    if target_column not in df.columns:
        raise MLTrainingError(f"Target column '{target_column}' not found")
    if len(df) < _MIN_ROWS:
        raise MLTrainingError(f"Need at least {_MIN_ROWS} rows to train, found {len(df)}")

    X = _prepare_features(df, feature_columns)
    y = pd.to_numeric(df[target_column], errors="coerce")
    valid = y.notna()
    X, y = X[valid], y[valid]
    if len(X) < _MIN_ROWS:
        raise MLTrainingError(f"Fewer than {_MIN_ROWS} rows have a valid numeric target after cleaning")

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)

    if algorithm == "auto":
        candidates = []
        best = None
        for candidate_algo in sorted(REGRESSION_ALGORITHMS):
            result = _fit_regression_candidate(candidate_algo, X, X_train, X_test, y_train, y_test)
            candidates.append({"algorithm": candidate_algo, "metrics": result.metrics})
            if best is None or result.metrics["r2_score"] > best.metrics["r2_score"]:
                best = result
        best.candidates = candidates
        return best

    return _fit_regression_candidate(algorithm, X, X_train, X_test, y_train, y_test)


def _fit_regression_candidate(algorithm: str, X, X_train, X_test, y_train, y_test) -> TrainingResult:
    model = _build_regressor(algorithm)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    metrics = {
        "r2_score": round(float(r2_score(y_test, predictions)), 4),
        "mae": round(float(mean_absolute_error(y_test, predictions)), 4),
        "rmse": round(float(root_mean_squared_error(y_test, predictions)), 4),
        "train_rows": len(X_train),
        "test_rows": len(X_test),
    }
    return TrainingResult(
        model_type="regression", algorithm=algorithm, metrics=metrics,
        feature_importance=_feature_importance(model, X.columns), estimator=model,
    )


def train_classification(
    df: pd.DataFrame, feature_columns: list[str], target_column: str, algorithm: str = "random_forest",
    test_size: float = 0.2,
) -> TrainingResult:
    if target_column not in df.columns:
        raise MLTrainingError(f"Target column '{target_column}' not found")
    if len(df) < _MIN_ROWS:
        raise MLTrainingError(f"Need at least {_MIN_ROWS} rows to train, found {len(df)}")

    X = _prepare_features(df, feature_columns)
    y_raw = df[target_column]
    valid = y_raw.notna()
    X, y_raw = X[valid], y_raw[valid]
    if len(X) < _MIN_ROWS:
        raise MLTrainingError(f"Fewer than {_MIN_ROWS} rows have a valid target after cleaning")
    if y_raw.nunique() < 2:
        raise MLTrainingError("Target column must have at least 2 distinct classes")

    label_encoder = None
    if not pd.api.types.is_numeric_dtype(y_raw):
        label_encoder = LabelEncoder()
        y = pd.Series(label_encoder.fit_transform(y_raw), index=y_raw.index)
    else:
        y = y_raw

    stratify = y if y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=stratify
    )

    if algorithm == "auto":
        candidates = []
        best = None
        for candidate_algo in sorted(CLASSIFICATION_ALGORITHMS):
            result = _fit_classification_candidate(
                candidate_algo, X, X_train, X_test, y_train, y_test, y, label_encoder
            )
            candidates.append({"algorithm": candidate_algo, "metrics": result.metrics})
            if best is None or result.metrics["accuracy"] > best.metrics["accuracy"]:
                best = result
        best.candidates = candidates
        return best

    return _fit_classification_candidate(algorithm, X, X_train, X_test, y_train, y_test, y, label_encoder)


def _fit_classification_candidate(algorithm, X, X_train, X_test, y_train, y_test, y, label_encoder) -> TrainingResult:
    model = _build_classifier(algorithm)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    metrics = {
        "accuracy": round(float(accuracy_score(y_test, predictions)), 4),
        "precision": round(float(precision_score(y_test, predictions, average="weighted", zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, predictions, average="weighted", zero_division=0)), 4),
        "f1_score": round(float(f1_score(y_test, predictions, average="weighted", zero_division=0)), 4),
        "train_rows": len(X_train),
        "test_rows": len(X_test),
        "class_count": int(y.nunique()),
    }
    return TrainingResult(
        model_type="classification", algorithm=algorithm, metrics=metrics,
        feature_importance=_feature_importance(model, X.columns), estimator=model, label_encoder=label_encoder,
    )


def train_clustering(df: pd.DataFrame, feature_columns: list[str], n_clusters: int = 3) -> TrainingResult:
    if len(df) < _MIN_ROWS:
        raise MLTrainingError(f"Need at least {_MIN_ROWS} rows to train, found {len(df)}")
    if n_clusters < 2 or n_clusters > 20:
        raise MLTrainingError("n_clusters must be between 2 and 20")

    X = _prepare_features(df, feature_columns)
    if len(X) < n_clusters:
        raise MLTrainingError(f"Need at least as many rows ({len(X)}) as clusters ({n_clusters})")

    # Standardize so no single large-scale feature dominates distance calculations.
    X_scaled = (X - X.mean()) / X.std().replace(0, 1)

    model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = model.fit_predict(X_scaled)

    metrics = {
        "silhouette_score": round(float(silhouette_score(X_scaled, labels)), 4) if len(set(labels)) > 1 else 0.0,
        "n_clusters": n_clusters,
        "cluster_sizes": {int(k): int(v) for k, v in zip(*np.unique(labels, return_counts=True))},
    }

    return TrainingResult(
        model_type="clustering", algorithm="kmeans", metrics=metrics, estimator=model,
    )
