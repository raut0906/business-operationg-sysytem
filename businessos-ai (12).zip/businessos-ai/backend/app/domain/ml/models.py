from sqlalchemy import ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.shared.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.infrastructure.db import Base


class MLModel(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "ml_models"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    # regression | classification | clustering
    model_type: Mapped[str] = mapped_column(String(30), nullable=False)
    algorithm: Mapped[str] = mapped_column(String(50), nullable=False)
    target_column: Mapped[str] = mapped_column(String(255), nullable=True)  # null for clustering
    # JSON-encoded list[str]
    feature_columns_json: Mapped[str] = mapped_column(Text, nullable=False)
    # JSON-encoded metrics dict (r2/accuracy/silhouette/etc, algorithm-dependent)
    metrics_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    # JSON-encoded {feature: importance} — empty for clustering
    feature_importance_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    # JSON-encoded list of {"algorithm": str, "metrics": dict} — populated only when the model
    # was trained with algorithm="auto"; empty list otherwise.
    candidates_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    # training | ready | failed
    status: Mapped[str] = mapped_column(String(20), default="training")
    error_message: Mapped[str] = mapped_column(Text, nullable=True)
    # Path to the joblib-serialized estimator (+ label encoder if any) on disk.
    artifact_path: Mapped[str] = mapped_column(String(500), nullable=True)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
