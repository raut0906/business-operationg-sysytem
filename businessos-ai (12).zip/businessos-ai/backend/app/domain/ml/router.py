import json

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.ml.models import MLModel
from app.domain.ml.schemas import MLModelCreate, MLModelOut, MLPredictRequest, MLPredictResponse
from app.domain.ml.service import MLService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/ml-models", tags=["ml"])


def _to_out(model: MLModel) -> MLModelOut:
    return MLModelOut(
        id=model.id,
        workspace_id=model.workspace_id,
        dataset_id=model.dataset_id,
        name=model.name,
        model_type=model.model_type,
        algorithm=model.algorithm,
        target_column=model.target_column,
        feature_columns=json.loads(model.feature_columns_json),
        metrics=json.loads(model.metrics_json or "{}"),
        feature_importance=json.loads(model.feature_importance_json or "{}"),
        candidates=json.loads(model.candidates_json or "[]"),
        status=model.status,
        error_message=model.error_message,
    )


@router.post("", response_model=MLModelOut, status_code=201)
def train_model(
    workspace_id: str,
    payload: MLModelCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _to_out(MLService(db).train(workspace_id, payload, current_user.id))


@router.get("", response_model=list[MLModelOut])
def list_models(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return [_to_out(m) for m in MLService(db).list_for_workspace(workspace_id, current_user.id)]


@router.get("/{model_id}", response_model=MLModelOut)
def get_model(
    workspace_id: str,
    model_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _to_out(MLService(db).get_or_404(model_id, workspace_id, current_user.id))


@router.post("/{model_id}/predict", response_model=MLPredictResponse)
def predict(
    workspace_id: str,
    model_id: str,
    payload: MLPredictRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    predictions = MLService(db).predict(model_id, workspace_id, payload.rows, current_user.id)
    return MLPredictResponse(predictions=predictions)
