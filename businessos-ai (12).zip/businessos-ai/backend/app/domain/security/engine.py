"""
Row-level security filter engine.

Same defense-in-depth philosophy as app.domain.semantic.engine and
app.domain.copilot.sql_safety: policy filter strings like
"region == 'West'" or "amount > 100 and region != 'East'" are parsed via
Python's `ast` module and walked by hand — never eval()'d — so only a
narrow, whitelisted grammar of comparisons, boolean combinators, and
literal values can ever execute. Anything else (attribute access, calls,
comprehensions, etc.) is rejected before evaluation starts.

Grammar: NAME (op) LITERAL, combined with `and`/`or`/`not`, where op is
one of ==, !=, <, <=, >, >=, in, not in (against a literal list).
"""
import ast

import pandas as pd

_ALLOWED_COMPARE_OPS = (ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn)


class PolicyExpressionError(Exception):
    pass


def validate_filter_syntax(expression: str) -> None:
    """Raises PolicyExpressionError if the expression isn't valid policy grammar."""
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise PolicyExpressionError(f"Could not parse filter expression: {exc}") from exc
    _validate_node(tree.body)


def _validate_node(node: ast.AST) -> None:
    if isinstance(node, ast.BoolOp):
        if not isinstance(node.op, (ast.And, ast.Or)):
            raise PolicyExpressionError(f"Boolean operator '{type(node.op).__name__}' not allowed")
        for value in node.values:
            _validate_node(value)
        return
    if isinstance(node, ast.UnaryOp):
        if not isinstance(node.op, ast.Not):
            raise PolicyExpressionError(f"Unary operator '{type(node.op).__name__}' not allowed")
        _validate_node(node.operand)
        return
    if isinstance(node, ast.Compare):
        if len(node.ops) != 1 or len(node.comparators) != 1:
            raise PolicyExpressionError("Chained comparisons (e.g. 'a < b < c') are not supported")
        if not isinstance(node.left, ast.Name):
            raise PolicyExpressionError("Left side of a comparison must be a column name")
        if not isinstance(node.ops[0], _ALLOWED_COMPARE_OPS):
            raise PolicyExpressionError(f"Comparison operator '{type(node.ops[0]).__name__}' not allowed")
        comparator = node.comparators[0]
        if isinstance(comparator, ast.List):
            for element in comparator.elts:
                if not isinstance(element, ast.Constant):
                    raise PolicyExpressionError("List elements must be literal constants")
        elif not isinstance(comparator, ast.Constant):
            raise PolicyExpressionError("Right side of a comparison must be a literal constant or list")
        return
    raise PolicyExpressionError(f"Expression contains a disallowed construct: {type(node).__name__}")


def _eval_node(node: ast.AST, df: pd.DataFrame) -> pd.Series:
    if isinstance(node, ast.BoolOp):
        masks = [_eval_node(v, df) for v in node.values]
        result = masks[0]
        for mask in masks[1:]:
            result = (result & mask) if isinstance(node.op, ast.And) else (result | mask)
        return result
    if isinstance(node, ast.UnaryOp):
        return ~_eval_node(node.operand, df)
    if isinstance(node, ast.Compare):
        column = node.left.id
        if column not in df.columns:
            raise PolicyExpressionError(f"Column '{column}' not found. Available: {list(df.columns)}")
        op = node.ops[0]
        comparator = node.comparators[0]
        series = df[column]

        if isinstance(comparator, ast.List):
            values = [elt.value for elt in comparator.elts]
            mask = series.isin(values)
            return ~mask if isinstance(op, ast.NotIn) else mask

        value = comparator.value
        if isinstance(op, ast.Eq):
            return series == value
        if isinstance(op, ast.NotEq):
            return series != value
        if isinstance(op, ast.Lt):
            return series < value
        if isinstance(op, ast.LtE):
            return series <= value
        if isinstance(op, ast.Gt):
            return series > value
        if isinstance(op, ast.GtE):
            return series >= value
    raise PolicyExpressionError(f"Unexpected node during evaluation: {type(node).__name__}")


def apply_row_filter(expression: str, df: pd.DataFrame) -> pd.DataFrame:
    """Validates then applies a row-level security filter, returning only matching rows."""
    validate_filter_syntax(expression)
    tree = ast.parse(expression, mode="eval")
    mask = _eval_node(tree.body, df)
    return df[mask]


def referenced_columns(expression: str) -> list[str]:
    validate_filter_syntax(expression)
    tree = ast.parse(expression, mode="eval")
    columns: list[str] = []

    def _walk(node: ast.AST) -> None:
        if isinstance(node, ast.Compare) and isinstance(node.left, ast.Name):
            if node.left.id not in columns:
                columns.append(node.left.id)
        for child in ast.iter_child_nodes(node):
            _walk(child)

    _walk(tree.body)
    return columns


# ---- Column-level security -------------------------------------------------

_ALLOWED_ACCESS_TYPES = {"full", "masked", "hidden"}


def apply_column_policies(df: pd.DataFrame, column_policies: list[dict]) -> pd.DataFrame:
    """
    column_policies: [{"column": str, "access_type": "full"|"masked"|"hidden"}, ...]
    - "hidden": column is dropped entirely
    - "masked": column values are replaced with a fixed redaction marker
    - "full": column is left untouched
    """
    result = df.copy()
    for policy in column_policies:
        column, access_type = policy["column"], policy["access_type"]
        if access_type not in _ALLOWED_ACCESS_TYPES:
            raise PolicyExpressionError(f"Unknown access_type '{access_type}', use one of {_ALLOWED_ACCESS_TYPES}")
        if column not in result.columns:
            continue  # policy references a column that isn't in this particular result set — skip, don't fail
        if access_type == "hidden":
            result = result.drop(columns=[column])
        elif access_type == "masked":
            result[column] = "***"
    return result
