from sqlalchemy import ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.shared.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.infrastructure.db import Base


class RowLevelPolicy(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """
    Applies a row filter to a dataset for any member at or below the given
    role level. E.g. max_role=VIEWER (0) means only viewers get filtered;
    editors/admins/owners see unfiltered data. Multiple policies on the same
    dataset are combined with AND (all must pass).
    """
    __tablename__ = "row_level_policies"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), index=True, nullable=False)
    # Role (as the shared.rbac.Role IntEnum value) at or below which this policy applies.
    max_role: Mapped[int] = mapped_column(Integer, nullable=False)
    filter_expression: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=True)


class ColumnLevelPolicy(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "column_level_policies"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), index=True, nullable=False)
    max_role: Mapped[int] = mapped_column(Integer, nullable=False)
    column_name: Mapped[str] = mapped_column(String(255), nullable=False)
    # full | masked | hidden
    access_type: Mapped[str] = mapped_column(String(20), nullable=False)
