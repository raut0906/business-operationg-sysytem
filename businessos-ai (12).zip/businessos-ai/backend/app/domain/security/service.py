"""
RLS/CLS domain service.

The core operation is `get_secured_preview`: loads a dataset from the
warehouse, determines the requesting user's role in the workspace, applies
every row-level policy whose max_role is >= the user's role (i.e. the user
qualifies for that restriction), combined with AND, then applies every
matching column-level policy. Higher-privilege users (role above every
policy's max_role) see completely unrestricted data — this mirrors how
RLS/CLS works in real BI tools: restrictions target specific privilege
tiers, they don't apply universally.
"""
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

import pandas as pd

from app.domain.datasets.service import DatasetService
from app.domain.security.engine import (
    PolicyExpressionError,
    apply_column_policies,
    apply_row_filter,
    referenced_columns,
)
from app.domain.security.models import ColumnLevelPolicy, RowLevelPolicy
from app.domain.security.schemas import ColumnLevelPolicyCreate, RowLevelPolicyCreate, SecuredPreview
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService
from app.infrastructure import duckdb_client


class SecurityService:
    def __init__(self, db: Session):
        self.db = db

    # ---- Row-level policies ---------------------------------------------

    def create_row_policy(self, workspace_id: str, payload: RowLevelPolicyCreate, user_id: str) -> RowLevelPolicy:
        # Admin+ only: managing who sees what data is a higher-trust action than ordinary content creation.
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        dataset = DatasetService(self.db).get_or_404(payload.dataset_id, workspace_id, user_id)

        try:
            needed = referenced_columns(payload.filter_expression)
        except PolicyExpressionError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

        schema = duckdb_client.get_table_schema(workspace_id, dataset.warehouse_table_name)
        available = {col["name"] for col in schema}
        missing = [c for c in needed if c not in available]
        if missing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Filter references columns not in dataset '{dataset.name}': {missing}",
            )

        policy = RowLevelPolicy(workspace_id=workspace_id, **payload.model_dump())
        self.db.add(policy)
        self.db.commit()
        self.db.refresh(policy)
        return policy

    def list_row_policies(self, workspace_id: str, user_id: str) -> list[RowLevelPolicy]:
        # Admin+ only: the policy list itself (filter logic, which columns/roles are targeted)
        # is sensitive configuration, not something every Viewer should be able to inspect.
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        return self.db.query(RowLevelPolicy).filter(RowLevelPolicy.workspace_id == workspace_id).all()

    def delete_row_policy(self, policy_id: str, workspace_id: str, user_id: str) -> None:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        policy = (
            self.db.query(RowLevelPolicy)
            .filter(RowLevelPolicy.id == policy_id, RowLevelPolicy.workspace_id == workspace_id)
            .first()
        )
        if not policy:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Policy not found")
        self.db.delete(policy)
        self.db.commit()

    # ---- Column-level policies ---------------------------------------------

    def create_column_policy(
        self, workspace_id: str, payload: ColumnLevelPolicyCreate, user_id: str
    ) -> ColumnLevelPolicy:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        dataset = DatasetService(self.db).get_or_404(payload.dataset_id, workspace_id, user_id)

        schema = duckdb_client.get_table_schema(workspace_id, dataset.warehouse_table_name)
        available = {col["name"] for col in schema}
        if payload.column_name not in available:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Column '{payload.column_name}' not found in dataset '{dataset.name}'",
            )

        policy = ColumnLevelPolicy(workspace_id=workspace_id, **payload.model_dump())
        self.db.add(policy)
        self.db.commit()
        self.db.refresh(policy)
        return policy

    def list_column_policies(self, workspace_id: str, user_id: str) -> list[ColumnLevelPolicy]:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        return self.db.query(ColumnLevelPolicy).filter(ColumnLevelPolicy.workspace_id == workspace_id).all()

    def delete_column_policy(self, policy_id: str, workspace_id: str, user_id: str) -> None:
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.ADMIN)
        policy = (
            self.db.query(ColumnLevelPolicy)
            .filter(ColumnLevelPolicy.id == policy_id, ColumnLevelPolicy.workspace_id == workspace_id)
            .first()
        )
        if not policy:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Policy not found")
        self.db.delete(policy)
        self.db.commit()

    # ---- Secured data access (the reusable primitive) ---------------------------------------------

    def get_secured_dataframe(
        self, dataset_id: str, workspace_id: str, user_id: str
    ) -> tuple[pd.DataFrame, list[str], list[str]]:
        """
        The single shared entry point for "give me this dataset's data, with
        RLS/CLS applied for the requesting user's role." Every consumer that
        reads dataset rows on a user's behalf — dashboard widgets, the AI
        Copilot, and secured-preview itself — should go through this rather
        than loading the warehouse table directly, or security policies only
        protect whichever one feature happened to remember to check them.

        Returns (filtered_and_masked_dataframe, human_readable_applied_policies,
        hidden_column_names) — callers that need to know which columns were
        dropped (e.g. to keep an AI prompt from referencing them) use the third
        element rather than re-deriving it.
        """
        membership = WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)
        dataset = DatasetService(self.db).get_or_404(dataset_id, workspace_id, user_id)

        df = duckdb_client.load_full_table(workspace_id, dataset.warehouse_table_name)
        applied: list[str] = []

        row_policies = (
            self.db.query(RowLevelPolicy)
            .filter(RowLevelPolicy.workspace_id == workspace_id, RowLevelPolicy.dataset_id == dataset_id)
            .all()
        )
        for policy in row_policies:
            if membership.role <= policy.max_role:
                try:
                    df = apply_row_filter(policy.filter_expression, df)
                    applied.append(f"row: {policy.filter_expression}")
                except PolicyExpressionError as exc:
                    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

        column_policies = (
            self.db.query(ColumnLevelPolicy)
            .filter(ColumnLevelPolicy.workspace_id == workspace_id, ColumnLevelPolicy.dataset_id == dataset_id)
            .all()
        )
        applicable_column_policies = [
            {"column": p.column_name, "access_type": p.access_type}
            for p in column_policies
            if membership.role <= p.max_role
        ]
        hidden_columns = [p["column"] for p in applicable_column_policies if p["access_type"] == "hidden"]
        if applicable_column_policies:
            df = apply_column_policies(df, applicable_column_policies)
            applied.extend(f"column: {p['column']} -> {p['access_type']}" for p in applicable_column_policies)

        return df, applied, hidden_columns

    def get_secured_preview(self, dataset_id: str, workspace_id: str, user_id: str, limit: int = 50) -> SecuredPreview:
        df, applied, _hidden = self.get_secured_dataframe(dataset_id, workspace_id, user_id)
        limited = df.head(limit)
        return SecuredPreview(
            columns=list(limited.columns),
            rows=limited.to_dict(orient="records"),
            row_count=len(df),
            policies_applied=applied,
        )
