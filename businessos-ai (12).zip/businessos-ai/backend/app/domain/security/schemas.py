from pydantic import BaseModel, Field


class RowLevelPolicyCreate(BaseModel):
    dataset_id: str
    max_role: int = Field(ge=0, le=3, description="0=Viewer, 1=Editor, 2=Admin, 3=Owner; policy applies at/below this role")
    filter_expression: str = Field(min_length=1, description="e.g. \"region == 'West'\"")
    description: str | None = None


class RowLevelPolicyOut(BaseModel):
    id: str
    workspace_id: str
    dataset_id: str
    max_role: int
    filter_expression: str
    description: str | None

    model_config = {"from_attributes": True}


class ColumnLevelPolicyCreate(BaseModel):
    dataset_id: str
    max_role: int = Field(ge=0, le=3)
    column_name: str = Field(min_length=1)
    access_type: str = Field(pattern="^(full|masked|hidden)$")


class ColumnLevelPolicyOut(BaseModel):
    id: str
    workspace_id: str
    dataset_id: str
    max_role: int
    column_name: str
    access_type: str

    model_config = {"from_attributes": True}


class SecuredPreview(BaseModel):
    columns: list[str]
    rows: list[dict]
    row_count: int
    policies_applied: list[str]
