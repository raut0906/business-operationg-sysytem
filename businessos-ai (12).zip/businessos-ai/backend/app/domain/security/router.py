from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.security.schemas import (
    ColumnLevelPolicyCreate,
    ColumnLevelPolicyOut,
    RowLevelPolicyCreate,
    RowLevelPolicyOut,
    SecuredPreview,
)
from app.domain.security.service import SecurityService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/security", tags=["security"])


@router.post("/row-policies", response_model=RowLevelPolicyOut, status_code=201)
def create_row_policy(
    workspace_id: str,
    payload: RowLevelPolicyCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return SecurityService(db).create_row_policy(workspace_id, payload, current_user.id)


@router.get("/row-policies", response_model=list[RowLevelPolicyOut])
def list_row_policies(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return SecurityService(db).list_row_policies(workspace_id, current_user.id)


@router.delete("/row-policies/{policy_id}", status_code=204)
def delete_row_policy(
    workspace_id: str,
    policy_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    SecurityService(db).delete_row_policy(policy_id, workspace_id, current_user.id)


@router.post("/column-policies", response_model=ColumnLevelPolicyOut, status_code=201)
def create_column_policy(
    workspace_id: str,
    payload: ColumnLevelPolicyCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return SecurityService(db).create_column_policy(workspace_id, payload, current_user.id)


@router.get("/column-policies", response_model=list[ColumnLevelPolicyOut])
def list_column_policies(
    workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return SecurityService(db).list_column_policies(workspace_id, current_user.id)


@router.delete("/column-policies/{policy_id}", status_code=204)
def delete_column_policy(
    workspace_id: str,
    policy_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    SecurityService(db).delete_column_policy(policy_id, workspace_id, current_user.id)


@router.get("/datasets/{dataset_id}/secured-preview", response_model=SecuredPreview)
def get_secured_preview(
    workspace_id: str,
    dataset_id: str,
    limit: int = Query(default=50, ge=1, le=1000),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return SecurityService(db).get_secured_preview(dataset_id, workspace_id, current_user.id, limit=limit)
