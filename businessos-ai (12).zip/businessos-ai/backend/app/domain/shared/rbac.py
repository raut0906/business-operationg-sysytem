"""
Role definitions shared across organizations and workspaces.

Kept as a plain enum + ordering rather than a permissions matrix for the
MVP wedge — a full permission-matrix system (per-action grants) is a
later hardening concern, but the enum and require_role() dependency are
the stable interface the rest of the app should depend on, so that
upgrade doesn't ripple through every router.
"""
from enum import IntEnum

from fastapi import HTTPException, status


class Role(IntEnum):
    VIEWER = 0
    EDITOR = 1
    ADMIN = 2
    OWNER = 3


def require_role(minimum_role: Role):
    """FastAPI dependency factory: raises 403 if the caller's membership role is below minimum_role."""

    def _check(current_role: Role) -> Role:
        if current_role < minimum_role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires role >= {minimum_role.name}",
            )
        return current_role

    return _check
