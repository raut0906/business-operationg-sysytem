import json

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.domain.auth.models import User
from app.domain.inventory.schemas import (
    ABCAnalysisOut,
    InventoryValueOut,
    OrderLine,
    ProductCreate,
    ProductOut,
    PurchaseOrderCreate,
    PurchaseOrderOut,
    ReorderSuggestionOut,
    SalesOrderCreate,
    SalesOrderOut,
    StockLevelOut,
    StockMovementCreate,
    StockMovementOut,
    SupplierCreate,
    SupplierOut,
    WarehouseCreate,
    WarehouseOut,
)
from app.domain.inventory.service import InventoryService
from app.infrastructure.db import get_db

router = APIRouter(prefix="/api/v1/workspaces/{workspace_id}/inventory", tags=["inventory"])


def _po_out(po) -> PurchaseOrderOut:
    return PurchaseOrderOut(
        id=po.id, workspace_id=po.workspace_id, supplier_id=po.supplier_id, status=po.status,
        lines=[OrderLine(**line) for line in json.loads(po.lines_json)],
    )


def _so_out(so) -> SalesOrderOut:
    return SalesOrderOut(
        id=so.id, workspace_id=so.workspace_id, customer_name=so.customer_name, status=so.status,
        lines=[OrderLine(**{k: v for k, v in line.items() if k != "warehouse_id"}) for line in json.loads(so.lines_json)],
    )


# ---- Suppliers -----------------------------------------------------------

@router.post("/suppliers", response_model=SupplierOut, status_code=201)
def create_supplier(workspace_id: str, payload: SupplierCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return InventoryService(db).create_supplier(workspace_id, payload, current_user.id)


@router.get("/suppliers", response_model=list[SupplierOut])
def list_suppliers(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return InventoryService(db).list_suppliers(workspace_id, current_user.id)


# ---- Warehouses -----------------------------------------------------------

@router.post("/warehouses", response_model=WarehouseOut, status_code=201)
def create_warehouse(workspace_id: str, payload: WarehouseCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return InventoryService(db).create_warehouse(workspace_id, payload, current_user.id)


@router.get("/warehouses", response_model=list[WarehouseOut])
def list_warehouses(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return InventoryService(db).list_warehouses(workspace_id, current_user.id)


# ---- Products -----------------------------------------------------------

@router.post("/products", response_model=ProductOut, status_code=201)
def create_product(workspace_id: str, payload: ProductCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return InventoryService(db).create_product(workspace_id, payload, current_user.id)


@router.get("/products", response_model=list[ProductOut])
def list_products(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return InventoryService(db).list_products(workspace_id, current_user.id)


# ---- Stock movements ---------------------------------------------------

@router.post("/movements", response_model=StockMovementOut, status_code=201)
def record_movement(workspace_id: str, payload: StockMovementCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return InventoryService(db).record_movement(workspace_id, payload, current_user.id)


# ---- Purchase orders ---------------------------------------------------

@router.post("/purchase-orders", response_model=PurchaseOrderOut, status_code=201)
def create_purchase_order(workspace_id: str, payload: PurchaseOrderCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return _po_out(InventoryService(db).create_purchase_order(workspace_id, payload, current_user.id))


@router.get("/purchase-orders", response_model=list[PurchaseOrderOut])
def list_purchase_orders(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return [_po_out(po) for po in InventoryService(db).list_purchase_orders(workspace_id, current_user.id)]


@router.post("/purchase-orders/{po_id}/receive", response_model=PurchaseOrderOut)
def receive_purchase_order(
    workspace_id: str, po_id: str, warehouse_id: str = Query(...),
    db: Session = Depends(get_db), current_user: User = Depends(get_current_user),
):
    return _po_out(InventoryService(db).receive_purchase_order(po_id, workspace_id, warehouse_id, current_user.id))


# ---- Sales orders -----------------------------------------------------

@router.post("/sales-orders", response_model=SalesOrderOut, status_code=201)
def create_sales_order(workspace_id: str, payload: SalesOrderCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return _so_out(InventoryService(db).create_sales_order(workspace_id, payload, current_user.id))


@router.get("/sales-orders", response_model=list[SalesOrderOut])
def list_sales_orders(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return [_so_out(so) for so in InventoryService(db).list_sales_orders(workspace_id, current_user.id)]


@router.post("/sales-orders/{so_id}/fulfill", response_model=SalesOrderOut)
def fulfill_sales_order(workspace_id: str, so_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return _so_out(InventoryService(db).fulfill_sales_order(so_id, workspace_id, current_user.id))


# ---- KPIs -----------------------------------------------------------------

@router.get("/kpis/stock-levels", response_model=list[StockLevelOut])
def stock_levels(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    df = InventoryService(db).get_stock_levels(workspace_id, current_user.id)
    return df.to_dict(orient="records")


@router.get("/kpis/inventory-value", response_model=list[InventoryValueOut])
def inventory_value(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    df = InventoryService(db).get_inventory_value(workspace_id, current_user.id)
    return df.to_dict(orient="records")


@router.get("/kpis/abc-analysis", response_model=list[ABCAnalysisOut])
def abc_analysis(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    df = InventoryService(db).get_abc_analysis(workspace_id, current_user.id)
    records = df.rename(columns={"class": "product_class"}).to_dict(orient="records")
    return records


@router.get("/kpis/reorder-suggestions", response_model=list[ReorderSuggestionOut])
def reorder_suggestions(workspace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    suggestions = InventoryService(db).get_reorder_suggestions(workspace_id, current_user.id)
    return [ReorderSuggestionOut(**s.__dict__) for s in suggestions]
