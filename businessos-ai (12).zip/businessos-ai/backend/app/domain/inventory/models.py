from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.domain.shared.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.infrastructure.db import Base


class Supplier(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "inventory_suppliers"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    contact_email: Mapped[str] = mapped_column(String(255), nullable=True)
    lead_time_days: Mapped[int] = mapped_column(Integer, default=7)


class Warehouse(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "inventory_warehouses"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    location: Mapped[str] = mapped_column(String(255), nullable=True)


class Product(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "inventory_products"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    sku: Mapped[str] = mapped_column(String(100), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    category: Mapped[str] = mapped_column(String(255), nullable=True)
    unit_cost: Mapped[float] = mapped_column(Float, default=0.0)
    unit_price: Mapped[float] = mapped_column(Float, default=0.0)
    reorder_point: Mapped[float] = mapped_column(Float, default=0.0)
    safety_stock: Mapped[float] = mapped_column(Float, default=0.0)
    reorder_quantity: Mapped[float] = mapped_column(Float, nullable=True)
    supplier_id: Mapped[str] = mapped_column(ForeignKey("inventory_suppliers.id"), nullable=True)


class StockMovement(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """
    Append-only ledger of stock changes. Current stock is always derived by
    summing quantity per (product, warehouse) rather than stored as a mutable
    counter — this avoids the classic bug class where a stored "current qty"
    drifts out of sync with the movements that are supposed to explain it.
    """
    __tablename__ = "inventory_stock_movements"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    product_id: Mapped[str] = mapped_column(ForeignKey("inventory_products.id"), index=True, nullable=False)
    warehouse_id: Mapped[str] = mapped_column(ForeignKey("inventory_warehouses.id"), index=True, nullable=False)
    # Signed: positive = stock in (purchase receipt, positive adjustment, transfer in),
    # negative = stock out (sale, negative adjustment, transfer out).
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    # purchase_receipt | sale | adjustment | transfer_in | transfer_out
    movement_type: Mapped[str] = mapped_column(String(30), nullable=False)
    reference: Mapped[str] = mapped_column(String(255), nullable=True)
    notes: Mapped[str] = mapped_column(Text, nullable=True)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)


class PurchaseOrder(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "inventory_purchase_orders"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    supplier_id: Mapped[str] = mapped_column(ForeignKey("inventory_suppliers.id"), nullable=False)
    # draft | ordered | received | cancelled
    status: Mapped[str] = mapped_column(String(20), default="draft")
    # JSON-encoded list of {"product_id": str, "quantity": float, "unit_cost": float}
    lines_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)


class SalesOrder(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "inventory_sales_orders"

    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True, nullable=False)
    customer_name: Mapped[str] = mapped_column(String(255), nullable=False)
    # draft | confirmed | fulfilled | cancelled
    status: Mapped[str] = mapped_column(String(20), default="draft")
    # JSON-encoded list of {"product_id": str, "quantity": float, "unit_price": float}
    lines_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
