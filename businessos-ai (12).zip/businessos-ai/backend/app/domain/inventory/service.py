"""
Inventory service layer.

CRUD is straightforward. The interesting part is order fulfillment:
receiving a purchase order or fulfilling a sales order doesn't just flip a
status flag — it appends the corresponding signed entries to the stock
movement ledger, which is the single source of truth for on-hand quantity
(see the docstring on StockMovement for why it's append-only rather than
a mutable counter).

KPI methods pull all movements/products for the workspace into memory and
hand them to the pure functions in engine.py — fine at the row counts a
per-workspace DuckDB-scale business operates at; if this ever needs to
scale to millions of movements, push the aggregation into SQL instead.
"""
import json
from datetime import datetime, timedelta, timezone

import pandas as pd
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.domain.inventory.engine import (
    InventoryCalculationError,
    compute_abc_analysis,
    compute_inventory_value,
    compute_reorder_suggestions,
    compute_stock_levels,
)
from app.domain.inventory.models import (
    Product,
    PurchaseOrder,
    SalesOrder,
    StockMovement,
    Supplier,
    Warehouse,
)
from app.domain.inventory.schemas import (
    OrderLine,
    ProductCreate,
    PurchaseOrderCreate,
    SalesOrderCreate,
    StockMovementCreate,
    SupplierCreate,
    WarehouseCreate,
)
from app.domain.shared.rbac import Role
from app.domain.workspaces.service import WorkspaceService


class InventoryService:
    def __init__(self, db: Session):
        self.db = db

    def _check_membership(self, workspace_id: str, user_id: str) -> None:
        WorkspaceService(self.db).get_membership_or_403(workspace_id, user_id)

    def _require_editor(self, workspace_id: str, user_id: str) -> None:
        """Every mutating inventory action (create/receive/fulfill) requires Editor role or higher."""
        WorkspaceService(self.db).require_role(workspace_id, user_id, Role.EDITOR)

    # ---- Suppliers ----------------------------------------------------

    def create_supplier(self, workspace_id: str, payload: SupplierCreate, user_id: str) -> Supplier:
        self._require_editor(workspace_id, user_id)
        supplier = Supplier(workspace_id=workspace_id, **payload.model_dump())
        self.db.add(supplier)
        self.db.commit()
        self.db.refresh(supplier)
        return supplier

    def list_suppliers(self, workspace_id: str, user_id: str) -> list[Supplier]:
        self._check_membership(workspace_id, user_id)
        return self.db.query(Supplier).filter(Supplier.workspace_id == workspace_id).all()

    # ---- Warehouses -----------------------------------------------------

    def create_warehouse(self, workspace_id: str, payload: WarehouseCreate, user_id: str) -> Warehouse:
        self._require_editor(workspace_id, user_id)
        warehouse = Warehouse(workspace_id=workspace_id, **payload.model_dump())
        self.db.add(warehouse)
        self.db.commit()
        self.db.refresh(warehouse)
        return warehouse

    def list_warehouses(self, workspace_id: str, user_id: str) -> list[Warehouse]:
        self._check_membership(workspace_id, user_id)
        return self.db.query(Warehouse).filter(Warehouse.workspace_id == workspace_id).all()

    # ---- Products ---------------------------------------------------------

    def create_product(self, workspace_id: str, payload: ProductCreate, user_id: str) -> Product:
        self._require_editor(workspace_id, user_id)
        if payload.supplier_id:
            supplier = (
                self.db.query(Supplier)
                .filter(Supplier.id == payload.supplier_id, Supplier.workspace_id == workspace_id)
                .first()
            )
            if not supplier:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="supplier_id not found")

        product = Product(workspace_id=workspace_id, **payload.model_dump())
        self.db.add(product)
        self.db.commit()
        self.db.refresh(product)
        return product

    def list_products(self, workspace_id: str, user_id: str) -> list[Product]:
        self._check_membership(workspace_id, user_id)
        return self.db.query(Product).filter(Product.workspace_id == workspace_id).all()

    def get_product_or_404(self, product_id: str, workspace_id: str, user_id: str) -> Product:
        self._check_membership(workspace_id, user_id)
        product = (
            self.db.query(Product)
            .filter(Product.id == product_id, Product.workspace_id == workspace_id)
            .first()
        )
        if not product:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")
        return product

    # ---- Stock movements (manual: adjustments/transfers) -------------------

    def record_movement(
        self, workspace_id: str, payload: StockMovementCreate, user_id: str
    ) -> StockMovement:
        self._require_editor(workspace_id, user_id)
        self.get_product_or_404(payload.product_id, workspace_id, user_id)
        self._get_warehouse_or_404(payload.warehouse_id, workspace_id)

        movement = StockMovement(workspace_id=workspace_id, created_by=user_id, **payload.model_dump())
        self.db.add(movement)
        self.db.commit()
        self.db.refresh(movement)
        return movement

    def _get_warehouse_or_404(self, warehouse_id: str, workspace_id: str) -> Warehouse:
        warehouse = (
            self.db.query(Warehouse)
            .filter(Warehouse.id == warehouse_id, Warehouse.workspace_id == workspace_id)
            .first()
        )
        if not warehouse:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="warehouse_id not found")
        return warehouse

    # ---- Purchase orders (receiving creates positive stock movements) -----

    def create_purchase_order(
        self, workspace_id: str, payload: PurchaseOrderCreate, user_id: str
    ) -> PurchaseOrder:
        self._require_editor(workspace_id, user_id)
        for line in payload.lines:
            self.get_product_or_404(line.product_id, workspace_id, user_id)

        po = PurchaseOrder(
            workspace_id=workspace_id,
            supplier_id=payload.supplier_id,
            status="draft",
            lines_json=json.dumps([line.model_dump() for line in payload.lines]),
            created_by=user_id,
        )
        self.db.add(po)
        self.db.commit()
        self.db.refresh(po)
        return po

    def list_purchase_orders(self, workspace_id: str, user_id: str) -> list[PurchaseOrder]:
        self._check_membership(workspace_id, user_id)
        return self.db.query(PurchaseOrder).filter(PurchaseOrder.workspace_id == workspace_id).all()

    def receive_purchase_order(self, po_id: str, workspace_id: str, warehouse_id: str, user_id: str) -> PurchaseOrder:
        """Marks a PO received and posts one positive stock movement per line into the given warehouse."""
        self._require_editor(workspace_id, user_id)
        self._get_warehouse_or_404(warehouse_id, workspace_id)
        po = (
            self.db.query(PurchaseOrder)
            .filter(PurchaseOrder.id == po_id, PurchaseOrder.workspace_id == workspace_id)
            .first()
        )
        if not po:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Purchase order not found")
        if po.status == "received":
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Purchase order already received")

        lines = json.loads(po.lines_json)
        for line in lines:
            self.db.add(
                StockMovement(
                    workspace_id=workspace_id,
                    product_id=line["product_id"],
                    warehouse_id=warehouse_id,
                    quantity=line["quantity"],
                    movement_type="purchase_receipt",
                    reference=po.id,
                    created_by=user_id,
                )
            )
        po.status = "received"
        self.db.commit()
        self.db.refresh(po)
        return po

    # ---- Sales orders (fulfilling creates negative stock movements) -------

    def create_sales_order(self, workspace_id: str, payload: SalesOrderCreate, user_id: str) -> SalesOrder:
        self._require_editor(workspace_id, user_id)
        self._get_warehouse_or_404(payload.warehouse_id, workspace_id)
        for line in payload.lines:
            self.get_product_or_404(line.product_id, workspace_id, user_id)

        so = SalesOrder(
            workspace_id=workspace_id,
            customer_name=payload.customer_name,
            status="draft",
            lines_json=json.dumps([{**line.model_dump(), "warehouse_id": payload.warehouse_id} for line in payload.lines]),
            created_by=user_id,
        )
        self.db.add(so)
        self.db.commit()
        self.db.refresh(so)
        return so

    def list_sales_orders(self, workspace_id: str, user_id: str) -> list[SalesOrder]:
        self._check_membership(workspace_id, user_id)
        return self.db.query(SalesOrder).filter(SalesOrder.workspace_id == workspace_id).all()

    def fulfill_sales_order(self, so_id: str, workspace_id: str, user_id: str) -> SalesOrder:
        self._require_editor(workspace_id, user_id)
        so = (
            self.db.query(SalesOrder)
            .filter(SalesOrder.id == so_id, SalesOrder.workspace_id == workspace_id)
            .first()
        )
        if not so:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sales order not found")
        if so.status == "fulfilled":
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Sales order already fulfilled")

        lines = json.loads(so.lines_json)
        for line in lines:
            self.db.add(
                StockMovement(
                    workspace_id=workspace_id,
                    product_id=line["product_id"],
                    warehouse_id=line["warehouse_id"],
                    quantity=-abs(line["quantity"]),
                    movement_type="sale",
                    reference=so.id,
                    created_by=user_id,
                )
            )
        so.status = "fulfilled"
        self.db.commit()
        self.db.refresh(so)
        return so

    # ---- KPIs ---------------------------------------------------------------

    def _movements_df(self, workspace_id: str) -> pd.DataFrame:
        rows = self.db.query(StockMovement).filter(StockMovement.workspace_id == workspace_id).all()
        if not rows:
            return pd.DataFrame(columns=["product_id", "warehouse_id", "quantity", "movement_type", "created_at"])
        return pd.DataFrame(
            [
                {
                    "product_id": r.product_id, "warehouse_id": r.warehouse_id,
                    "quantity": r.quantity, "movement_type": r.movement_type, "created_at": r.created_at,
                }
                for r in rows
            ]
        )

    def _products_df(self, workspace_id: str) -> pd.DataFrame:
        rows = self.db.query(Product).filter(Product.workspace_id == workspace_id).all()
        return pd.DataFrame(
            [
                {
                    "product_id": p.id, "unit_cost": p.unit_cost, "unit_price": p.unit_price,
                    "reorder_point": p.reorder_point, "safety_stock": p.safety_stock,
                    "reorder_quantity": p.reorder_quantity,
                }
                for p in rows
            ]
        )

    def get_stock_levels(self, workspace_id: str, user_id: str) -> pd.DataFrame:
        self._check_membership(workspace_id, user_id)
        return compute_stock_levels(self._movements_df(workspace_id))

    def get_inventory_value(self, workspace_id: str, user_id: str) -> pd.DataFrame:
        self._check_membership(workspace_id, user_id)
        levels = compute_stock_levels(self._movements_df(workspace_id))
        products = self._products_df(workspace_id)
        if products.empty or levels.empty:
            return pd.DataFrame(columns=["product_id", "warehouse_id", "quantity_on_hand", "unit_cost", "inventory_value"])
        return compute_inventory_value(products, levels)

    def get_abc_analysis(self, workspace_id: str, user_id: str, lookback_days: int = 365) -> pd.DataFrame:
        """ABC by trailing sales value (quantity sold * unit_price) over lookback_days."""
        self._check_membership(workspace_id, user_id)
        movements = self._movements_df(workspace_id)
        products = self._products_df(workspace_id)
        if movements.empty or products.empty:
            return pd.DataFrame(columns=["product_id", "annual_usage_value", "cumulative_pct", "class"])

        cutoff = datetime.now(timezone.utc) - timedelta(days=lookback_days)
        movements["created_at"] = pd.to_datetime(movements["created_at"], utc=True, errors="coerce")
        sales = movements[(movements["movement_type"] == "sale") & (movements["created_at"] >= cutoff)]
        sold_qty = sales.groupby("product_id")["quantity"].sum().abs().rename("qty_sold").reset_index()

        merged = products.merge(sold_qty, on="product_id", how="left")
        merged["qty_sold"] = merged["qty_sold"].fillna(0)
        merged["annual_usage_value"] = merged["qty_sold"] * merged["unit_price"]

        try:
            return compute_abc_analysis(merged[["product_id", "annual_usage_value"]])
        except InventoryCalculationError as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    def get_reorder_suggestions(self, workspace_id: str, user_id: str):
        self._check_membership(workspace_id, user_id)
        levels = compute_stock_levels(self._movements_df(workspace_id))
        products = self._products_df(workspace_id)
        if products.empty:
            return []
        if levels.empty:
            levels = pd.DataFrame(columns=["product_id", "warehouse_id", "quantity_on_hand"])
        return compute_reorder_suggestions(products, levels)
