from pydantic import BaseModel, Field


class SupplierCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    contact_email: str | None = None
    lead_time_days: int = Field(default=7, ge=0)


class SupplierOut(BaseModel):
    id: str
    workspace_id: str
    name: str
    contact_email: str | None
    lead_time_days: int

    model_config = {"from_attributes": True}


class WarehouseCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    location: str | None = None


class WarehouseOut(BaseModel):
    id: str
    workspace_id: str
    name: str
    location: str | None

    model_config = {"from_attributes": True}


class ProductCreate(BaseModel):
    sku: str = Field(min_length=1, max_length=100)
    name: str = Field(min_length=1, max_length=255)
    category: str | None = None
    unit_cost: float = Field(default=0.0, ge=0)
    unit_price: float = Field(default=0.0, ge=0)
    reorder_point: float = Field(default=0.0, ge=0)
    safety_stock: float = Field(default=0.0, ge=0)
    reorder_quantity: float | None = None
    supplier_id: str | None = None


class ProductOut(BaseModel):
    id: str
    workspace_id: str
    sku: str
    name: str
    category: str | None
    unit_cost: float
    unit_price: float
    reorder_point: float
    safety_stock: float
    reorder_quantity: float | None
    supplier_id: str | None

    model_config = {"from_attributes": True}


class StockMovementCreate(BaseModel):
    product_id: str
    warehouse_id: str
    quantity: float = Field(description="Positive = stock in, negative = stock out")
    movement_type: str = Field(pattern="^(purchase_receipt|sale|adjustment|transfer_in|transfer_out)$")
    reference: str | None = None
    notes: str | None = None


class StockMovementOut(BaseModel):
    id: str
    workspace_id: str
    product_id: str
    warehouse_id: str
    quantity: float
    movement_type: str
    reference: str | None
    notes: str | None

    model_config = {"from_attributes": True}


class OrderLine(BaseModel):
    product_id: str
    quantity: float = Field(gt=0)
    unit_cost: float | None = None  # purchase orders
    unit_price: float | None = None  # sales orders


class PurchaseOrderCreate(BaseModel):
    supplier_id: str
    lines: list[OrderLine] = Field(min_length=1)


class PurchaseOrderOut(BaseModel):
    id: str
    workspace_id: str
    supplier_id: str
    status: str
    lines: list[OrderLine]

    model_config = {"from_attributes": True}


class SalesOrderCreate(BaseModel):
    customer_name: str = Field(min_length=1, max_length=255)
    warehouse_id: str
    lines: list[OrderLine] = Field(min_length=1)


class SalesOrderOut(BaseModel):
    id: str
    workspace_id: str
    customer_name: str
    status: str
    lines: list[OrderLine]

    model_config = {"from_attributes": True}


class StockLevelOut(BaseModel):
    product_id: str
    warehouse_id: str
    quantity_on_hand: float


class InventoryValueOut(BaseModel):
    product_id: str
    warehouse_id: str
    quantity_on_hand: float
    unit_cost: float
    inventory_value: float


class ABCAnalysisOut(BaseModel):
    product_id: str
    annual_usage_value: float
    cumulative_pct: float
    product_class: str


class ReorderSuggestionOut(BaseModel):
    product_id: str
    quantity_on_hand: float
    reorder_point: float
    suggested_order_quantity: float
