"""
Inventory KPI engine.

Pure functions over plain DataFrames — no DB, no ORM models — so the
business math (stock levels, inventory value, ABC classification, reorder
suggestions, turnover) can be unit-tested without touching the database,
matching the same pattern as every other engine.py in this codebase.
"""
from dataclasses import dataclass

import pandas as pd


class InventoryCalculationError(Exception):
    pass


def compute_stock_levels(movements: pd.DataFrame) -> pd.DataFrame:
    """
    movements: columns [product_id, warehouse_id, quantity] where quantity
    is signed (positive = stock in, negative = stock out).
    Returns: [product_id, warehouse_id, quantity_on_hand]
    """
    required = {"product_id", "warehouse_id", "quantity"}
    missing = required - set(movements.columns)
    if missing:
        raise InventoryCalculationError(f"movements is missing columns: {missing}")
    if movements.empty:
        return pd.DataFrame(columns=["product_id", "warehouse_id", "quantity_on_hand"])

    result = (
        movements.groupby(["product_id", "warehouse_id"], as_index=False)["quantity"]
        .sum()
        .rename(columns={"quantity": "quantity_on_hand"})
    )
    return result


def compute_inventory_value(
    products: pd.DataFrame, stock_levels: pd.DataFrame
) -> pd.DataFrame:
    """
    products: columns [product_id, unit_cost]
    stock_levels: columns [product_id, warehouse_id, quantity_on_hand]
    Returns: [product_id, warehouse_id, quantity_on_hand, unit_cost, inventory_value]
    """
    for col in ("product_id", "unit_cost"):
        if col not in products.columns:
            raise InventoryCalculationError(f"products is missing column: {col}")

    merged = stock_levels.merge(products[["product_id", "unit_cost"]], on="product_id", how="left")
    merged["unit_cost"] = merged["unit_cost"].fillna(0)
    merged["inventory_value"] = merged["quantity_on_hand"] * merged["unit_cost"]
    return merged


def compute_abc_analysis(products: pd.DataFrame) -> pd.DataFrame:
    """
    Classic ABC analysis by annual usage value.

    products: columns [product_id, annual_usage_value] (typically annual
    quantity sold * unit cost or unit price, computed by the caller).
    Returns products sorted descending by value with a `class` column:
    'A' = top ~80% of cumulative value, 'B' = next ~15%, 'C' = remaining ~5%.
    """
    if "annual_usage_value" not in products.columns or "product_id" not in products.columns:
        raise InventoryCalculationError("products must have 'product_id' and 'annual_usage_value' columns")
    if products.empty:
        return products.assign(cumulative_pct=pd.Series(dtype=float), **{"class": pd.Series(dtype=str)})

    df = products.sort_values("annual_usage_value", ascending=False).reset_index(drop=True).copy()
    total = df["annual_usage_value"].sum()
    if total <= 0:
        df["cumulative_pct"] = 0.0
        df["class"] = "C"
        return df

    df["cumulative_pct"] = (df["annual_usage_value"].cumsum() / total * 100).round(2)
    df["class"] = df["cumulative_pct"].apply(lambda pct: "A" if pct <= 80 else ("B" if pct <= 95 else "C"))
    return df


@dataclass
class ReorderSuggestion:
    product_id: str
    quantity_on_hand: float
    reorder_point: float
    suggested_order_quantity: float


def compute_reorder_suggestions(
    products: pd.DataFrame, stock_levels: pd.DataFrame
) -> list[ReorderSuggestion]:
    """
    products: columns [product_id, reorder_point, safety_stock, reorder_quantity]
    stock_levels: columns [product_id, quantity_on_hand] (already summed across warehouses)

    Flags any product whose total on-hand quantity is at or below its
    reorder_point, suggesting an order up to safety_stock + reorder_quantity.
    """
    required = {"product_id", "reorder_point"}
    missing = required - set(products.columns)
    if missing:
        raise InventoryCalculationError(f"products is missing columns: {missing}")

    totals = stock_levels.groupby("product_id", as_index=False)["quantity_on_hand"].sum()
    merged = products.merge(totals, on="product_id", how="left")
    merged["quantity_on_hand"] = merged["quantity_on_hand"].fillna(0)

    suggestions = []
    for row in merged.itertuples():
        if row.quantity_on_hand <= row.reorder_point:
            safety_stock = getattr(row, "safety_stock", 0) or 0
            reorder_qty = getattr(row, "reorder_quantity", None)
            suggested = reorder_qty if reorder_qty else max(row.reorder_point + safety_stock - row.quantity_on_hand, 0)
            suggestions.append(
                ReorderSuggestion(
                    product_id=row.product_id,
                    quantity_on_hand=float(row.quantity_on_hand),
                    reorder_point=float(row.reorder_point),
                    suggested_order_quantity=float(suggested),
                )
            )
    return suggestions


def compute_turnover_ratio(cogs: float, average_inventory_value: float) -> float | None:
    """Inventory turnover = Cost of Goods Sold / Average Inventory Value over the same period."""
    if average_inventory_value <= 0:
        return None
    return round(cogs / average_inventory_value, 4)
