"""
Centralized application configuration.

All environment-dependent values are read here and nowhere else, so the
rest of the codebase never touches os.environ directly (12-factor app
principle, and it makes testing trivial via Settings overrides).
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    app_name: str = "BusinessOS AI"
    environment: str = "development"
    debug: bool = True

    # Database (system of record)
    database_url: str = "sqlite:///./businessos.db"

    # Per-workspace analytical warehouse files live under this directory.
    # In production this should be a mounted volume, not local disk.
    warehouse_dir: str = "./warehouse_data"

    # Uploaded raw files (CSV/XLSX) before being loaded into the warehouse.
    upload_dir: str = "./uploads"

    # Auth
    jwt_secret_key: str = "CHANGE_ME_IN_PRODUCTION"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    # Redis (cache / job queue backing) - optional for local dev
    redis_url: str = "redis://localhost:6379/0"

    # AI Copilot — provider is chosen by ai_provider; the corresponding API key must be set
    # via environment variable (never hardcoded). "none" disables Copilot endpoints gracefully
    # rather than crashing, so the rest of the platform works without an AI key configured.
    ai_provider: str = "none"  # "openai" | "anthropic" | "none"
    ai_model: str = "gpt-4o-mini"
    openai_api_key: str = ""
    anthropic_api_key: str = ""

    # Key used to encrypt connector credentials (connection strings, DB passwords) at rest.
    # MUST be set to a real random secret in production — falls back to deriving from
    # jwt_secret_key otherwise, which is fine for local dev but not a real security boundary.
    connector_encryption_key: str = ""

    # CORS
    allowed_origins: list[str] = ["http://localhost:3000"]


@lru_cache
def get_settings() -> Settings:
    """Settings are cached because reading env vars on every request is wasteful."""
    return Settings()
