"""
AI Gateway — the single point through which every AI call in the platform
flows, per the architecture doc's "one interface, swappable providers"
decision. Copilot, executive summaries, forecasting explanations, etc.
should all call `AIGateway.complete()` rather than hitting OpenAI/Anthropic
SDKs directly, so provider swaps, cost tracking, and prompt-safety checks
happen in exactly one place.

No provider SDK is used (keeps the dependency footprint small) — plain
HTTPS calls via httpx against each provider's REST API instead.
"""
import httpx
from fastapi import HTTPException, status

from app.core.config import get_settings

settings = get_settings()


class AIGatewayError(Exception):
    pass


class AIGateway:
    def __init__(self):
        self.provider = settings.ai_provider
        self.model = settings.ai_model

    def is_configured(self) -> bool:
        if self.provider == "openai":
            return bool(settings.openai_api_key)
        if self.provider == "anthropic":
            return bool(settings.anthropic_api_key)
        return False

    def complete(self, system_prompt: str, user_prompt: str, max_tokens: int = 800) -> str:
        """Returns the raw text completion. Raises AIGatewayError on any failure."""
        if not self.is_configured():
            raise AIGatewayError(
                f"AI provider '{self.provider}' is not configured. "
                "Set AI_PROVIDER and the matching API key environment variable."
            )
        if self.provider == "openai":
            return self._complete_openai(system_prompt, user_prompt, max_tokens)
        if self.provider == "anthropic":
            return self._complete_anthropic(system_prompt, user_prompt, max_tokens)
        raise AIGatewayError(f"Unsupported AI provider '{self.provider}'")

    def _complete_openai(self, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
        try:
            response = httpx.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {settings.openai_api_key}"},
                json={
                    "model": self.model,
                    "max_tokens": max_tokens,
                    "temperature": 0,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt},
                    ],
                },
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
            return data["choices"][0]["message"]["content"]
        except httpx.HTTPError as exc:
            raise AIGatewayError(f"OpenAI request failed: {exc}") from exc
        except (KeyError, IndexError) as exc:
            raise AIGatewayError(f"Unexpected OpenAI response shape: {exc}") from exc

    def _complete_anthropic(self, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
        try:
            response = httpx.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": settings.anthropic_api_key,
                    "anthropic-version": "2023-06-01",
                },
                json={
                    "model": self.model,
                    "max_tokens": max_tokens,
                    "system": system_prompt,
                    "messages": [{"role": "user", "content": user_prompt}],
                },
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
            return data["content"][0]["text"]
        except httpx.HTTPError as exc:
            raise AIGatewayError(f"Anthropic request failed: {exc}") from exc
        except (KeyError, IndexError) as exc:
            raise AIGatewayError(f"Unexpected Anthropic response shape: {exc}") from exc


def get_ai_gateway() -> AIGateway:
    return AIGateway()


def require_configured_gateway(gateway: AIGateway) -> None:
    if not gateway.is_configured():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "AI Copilot is not configured on this deployment. "
                "An administrator needs to set AI_PROVIDER and the corresponding API key."
            ),
        )
