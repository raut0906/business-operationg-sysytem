"""
Per-workspace analytical warehouse backed by DuckDB.

Each workspace gets its own DuckDB file. This gives free tenant isolation
(no risk of a query crossing workspace boundaries at the DB layer) and
matches embedded-OLAP performance needs without provisioning a shared
warehouse cluster for a customer's first few uploaded files.

DuckDB connections are opened per-operation rather than held open, since
DuckDB file-based connections are single-writer; a connection pool would
add complexity with no benefit at this scale.
"""
import os
import re

import duckdb
import pandas as pd

from app.core.config import get_settings

settings = get_settings()


def _workspace_db_path(workspace_id: str) -> str:
    os.makedirs(settings.warehouse_dir, exist_ok=True)
    return os.path.join(settings.warehouse_dir, f"{workspace_id}.duckdb")


def _safe_table_name(name: str) -> str:
    """Prevent SQL injection / filesystem issues via table names derived from user input."""
    cleaned = re.sub(r"[^a-zA-Z0-9_]", "_", name.strip())
    if not cleaned or cleaned[0].isdigit():
        cleaned = f"t_{cleaned}"
    return cleaned.lower()


def load_dataframe(workspace_id: str, table_name: str, df: pd.DataFrame) -> str:
    """Load a pandas DataFrame into the workspace's warehouse as a table. Returns final table name."""
    safe_name = _safe_table_name(table_name)
    con = duckdb.connect(_workspace_db_path(workspace_id))
    try:
        con.register("_incoming_df", df)
        con.execute(f'CREATE OR REPLACE TABLE "{safe_name}" AS SELECT * FROM _incoming_df')
    finally:
        con.close()
    return safe_name


def load_full_table(workspace_id: str, table_name: str) -> pd.DataFrame:
    """
    Reads an entire table into memory as a DataFrame.

    Used by the ETL engine, which needs the full dataset to transform —
    unlike preview_table (dashboard/UI use), which is deliberately capped.
    For datasets beyond what fits in memory comfortably, the ETL engine
    should be moved to push-down SQL execution instead; that's a later
    optimization, not needed for the node types implemented here.
    """
    safe_name = _safe_table_name(table_name)
    con = duckdb.connect(_workspace_db_path(workspace_id), read_only=True)
    try:
        return con.execute(f'SELECT * FROM "{safe_name}"').fetchdf()
    finally:
        con.close()


def table_exists(workspace_id: str, table_name: str) -> bool:
    safe_name = _safe_table_name(table_name)
    con = duckdb.connect(_workspace_db_path(workspace_id), read_only=True)
    try:
        row = con.execute(
            "SELECT count(*) FROM information_schema.tables WHERE table_name = ?", [safe_name]
        ).fetchone()
        return bool(row and row[0] > 0)
    finally:
        con.close()


def preview_table(workspace_id: str, table_name: str, limit: int = 50) -> dict:
    safe_name = _safe_table_name(table_name)
    con = duckdb.connect(_workspace_db_path(workspace_id), read_only=True)
    try:
        result = con.execute(f'SELECT * FROM "{safe_name}" LIMIT {int(limit)}').fetchdf()
        row_count = con.execute(f'SELECT COUNT(*) FROM "{safe_name}"').fetchone()[0]
    finally:
        con.close()
    return {
        "columns": list(result.columns),
        "rows": result.to_dict(orient="records"),
        "row_count": row_count,
    }


def run_aggregate_query(workspace_id: str, table_name: str, dimension: str, metric: str, agg: str = "SUM") -> dict:
    """
    Runs a simple, safe aggregation for dashboard widgets:
    SELECT dimension, AGG(metric) FROM table GROUP BY dimension.

    Column/aggregate identifiers are validated against an allowlist pattern
    (not string-interpolated from arbitrary user text) to avoid SQL injection —
    this is the pattern every future semantic-layer query builder should follow.
    """
    allowed_aggs = {"SUM", "AVG", "COUNT", "MIN", "MAX"}
    agg_upper = agg.upper()
    if agg_upper not in allowed_aggs:
        raise ValueError(f"Unsupported aggregate: {agg}")

    safe_table = _safe_table_name(table_name)
    safe_dim = _safe_table_name(dimension)
    safe_metric = _safe_table_name(metric)

    con = duckdb.connect(_workspace_db_path(workspace_id), read_only=True)
    try:
        query = (
            f'SELECT "{safe_dim}" AS dimension, {agg_upper}("{safe_metric}") AS value '
            f'FROM "{safe_table}" GROUP BY "{safe_dim}" ORDER BY value DESC LIMIT 500'
        )
        result = con.execute(query).fetchdf()
    finally:
        con.close()
    return {"data": result.to_dict(orient="records")}


def get_metric_value(workspace_id: str, table_name: str, metric: str, agg: str = "SUM") -> float | None:
    """Single scalar value used by alert evaluation."""
    allowed_aggs = {"SUM", "AVG", "COUNT", "MIN", "MAX"}
    agg_upper = agg.upper()
    if agg_upper not in allowed_aggs:
        raise ValueError(f"Unsupported aggregate: {agg}")

    safe_table = _safe_table_name(table_name)
    safe_metric = _safe_table_name(metric)
    con = duckdb.connect(_workspace_db_path(workspace_id), read_only=True)
    try:
        row = con.execute(f'SELECT {agg_upper}("{safe_metric}") FROM "{safe_table}"').fetchone()
    finally:
        con.close()
    return row[0] if row else None


def run_readonly_sql(workspace_id: str, sql: str) -> dict:
    """
    Executes an already-validated, already-safe SQL string on a read-only
    connection. Callers (currently only the AI Copilot) are responsible for
    passing SQL that has already been through app.domain.copilot.sql_safety
    — this function does not re-validate, it only guarantees the connection
    itself cannot perform writes (DuckDB enforces this at the engine level
    in read_only mode).
    """
    con = duckdb.connect(_workspace_db_path(workspace_id), read_only=True)
    try:
        result = con.execute(sql).fetchdf()
    finally:
        con.close()
    return {"columns": list(result.columns), "rows": result.to_dict(orient="records")}


def get_table_schema(workspace_id: str, table_name: str) -> list[dict]:
    """Returns [{"name": col, "type": duckdb_type}, ...] for prompting the AI Copilot."""
    safe_name = _safe_table_name(table_name)
    con = duckdb.connect(_workspace_db_path(workspace_id), read_only=True)
    try:
        rows = con.execute(f'DESCRIBE "{safe_name}"').fetchall()
    finally:
        con.close()
    return [{"name": r[0], "type": r[1]} for r in rows]


def run_sql_on_dataframe(df: pd.DataFrame, table_name: str, sql: str) -> dict:
    """
    Executes already-validated, already-safe SQL against an in-memory DataFrame
    rather than the persisted workspace warehouse file.

    This is what makes it possible to enforce row/column-level security on the
    AI Copilot's generated queries: the caller first produces a security-filtered
    DataFrame (see app.domain.security.service.get_secured_dataframe — hidden
    rows already dropped, masked columns already redacted), registers it here
    under the same table name the LLM was told about, and the query runs against
    that in-memory view instead of ever touching the real warehouse table. The
    persisted warehouse file is never opened for this call, so there is no way
    for the generated SQL to reach unfiltered data even if the security layer
    were bypassed elsewhere.
    """
    safe_name = _safe_table_name(table_name)
    con = duckdb.connect(":memory:")
    try:
        con.register(safe_name, df)
        result = con.execute(sql).fetchdf()
    finally:
        con.close()
    return {"columns": list(result.columns), "rows": result.to_dict(orient="records")}
