"""
BusinessOS AI — API Gateway entrypoint.

This is intentionally thin: it wires domain routers together and sets up
cross-cutting concerns (CORS, table creation for local dev). All actual
logic lives in app/domain/*/service.py. Keeping main.py free of business
logic is what lets domains be split into separate deployables later
without touching this file's structure.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.domain.alerts.router import router as alerts_router
from app.domain.auth.router import router as auth_router
from app.domain.connectors.router import router as connectors_router
from app.domain.copilot.router import router as copilot_router
from app.domain.dashboards.router import router as dashboards_router
from app.domain.datasets.router import router as datasets_router
from app.domain.etl.router import router as etl_router
from app.domain.forecasting.router import router as forecasting_router
from app.domain.inventory.router import router as inventory_router
from app.domain.ml.router import router as ml_router
from app.domain.organizations.router import router as organizations_router
from app.domain.reports.router import router as reports_router
from app.domain.security.router import router as security_router
from app.domain.semantic.router import router as semantic_router
from app.domain.workspaces.router import router as workspaces_router
from app.infrastructure.db import Base, engine

settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    description="BusinessOS AI — connect data, warehouse it, transform it, ask it questions, dashboard it, alert on it.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(organizations_router)
app.include_router(workspaces_router)
app.include_router(datasets_router)
app.include_router(connectors_router)
app.include_router(semantic_router)
app.include_router(security_router)
app.include_router(etl_router)
app.include_router(dashboards_router)
app.include_router(copilot_router)
app.include_router(forecasting_router)
app.include_router(ml_router)
app.include_router(inventory_router)
app.include_router(reports_router)
app.include_router(alerts_router)


@app.on_event("startup")
def on_startup() -> None:
    # For the MVP wedge, create_all is used instead of Alembic migrations to keep
    # local setup to one command. Switch to Alembic before any production deploy
    # that needs zero-downtime schema changes.
    Base.metadata.create_all(bind=engine)


@app.get("/health", tags=["system"])
def health_check() -> dict:
    return {"status": "ok", "service": settings.app_name}
