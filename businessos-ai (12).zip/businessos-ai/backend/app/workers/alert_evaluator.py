"""
Scheduled alert evaluation.

For the MVP wedge this runs as a simple cron-invoked script
(`python -m app.workers.alert_evaluator`). Once alert volume justifies it,
swap the `if __name__` block for a Celery periodic task without touching
the evaluation logic itself, which already lives in AlertService.

Notification delivery (email/Slack/webhook) is intentionally stubbed here —
wiring a real provider is a later task, not part of this wedge.
"""
import logging

from app.domain.alerts.models import Alert
from app.infrastructure import duckdb_client
from app.infrastructure.db import SessionLocal

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("alert_evaluator")


def notify(alert: Alert, current_value: float) -> None:
    """Placeholder notification sink — logs only. Replace with email/Slack/webhook dispatch."""
    logger.info(
        "ALERT TRIGGERED: '%s' (workspace=%s) metric=%s value=%.2f threshold=%.2f condition=%s",
        alert.name, alert.workspace_id, alert.metric, current_value, alert.threshold, alert.condition,
    )


def run_once() -> int:
    """Evaluates every active alert once. Returns the number of alerts that triggered."""
    db = SessionLocal()
    triggered_count = 0
    try:
        from app.domain.datasets.models import Dataset  # local import avoids circular import at module load

        alerts = db.query(Alert).filter(Alert.is_active.is_(True)).all()
        for alert in alerts:
            dataset = db.query(Dataset).filter(Dataset.id == alert.dataset_id).first()
            if not dataset:
                continue
            try:
                current_value = duckdb_client.get_metric_value(
                    alert.workspace_id, dataset.warehouse_table_name, alert.metric, alert.aggregate
                )
            except Exception:
                logger.exception("Failed evaluating alert %s", alert.id)
                continue

            if current_value is None:
                continue

            is_triggered = (
                current_value > alert.threshold if alert.condition == "above" else current_value < alert.threshold
            )
            alert.last_triggered_value = current_value
            if is_triggered:
                triggered_count += 1
                notify(alert, current_value)

        db.commit()
    finally:
        db.close()
    return triggered_count


if __name__ == "__main__":
    count = run_once()
    logger.info("Alert evaluation complete. %d alert(s) triggered.", count)
