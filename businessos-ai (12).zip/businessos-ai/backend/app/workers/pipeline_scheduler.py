"""
Scheduled ETL pipeline execution.

Run via cron every few minutes: `python -m app.workers.pipeline_scheduler`.
Uses croniter to determine whether a pipeline is due, based on its
schedule_cron field and last_run_at timestamp. Each due pipeline is run
with an auto-generated output dataset name (`{pipeline_name}_output`) —
for a named output per run, use the API's /run endpoint directly instead.
"""
import logging
from datetime import datetime, timezone

from croniter import croniter

from app.domain.etl.models import Pipeline
from app.domain.etl.schemas import PipelineRunRequest
from app.domain.etl.service import PipelineService
from app.infrastructure.db import SessionLocal

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pipeline_scheduler")


def _is_due(pipeline: Pipeline, now: datetime) -> bool:
    if not pipeline.schedule_cron:
        return False
    if not pipeline.last_run_at:
        return True
    last_run = datetime.fromisoformat(pipeline.last_run_at)
    try:
        upcoming = croniter(pipeline.schedule_cron, last_run).get_next(datetime)
    except (ValueError, KeyError):
        logger.error("Pipeline %s has an invalid cron expression: %s", pipeline.id, pipeline.schedule_cron)
        return False
    return now >= upcoming


def run_due_pipelines() -> int:
    db = SessionLocal()
    executed = 0
    try:
        now = datetime.now(timezone.utc)
        pipelines = db.query(Pipeline).filter(Pipeline.is_active.is_(True)).all()
        service = PipelineService(db)
        for pipeline in pipelines:
            if not _is_due(pipeline, now):
                continue
            logger.info("Running scheduled pipeline '%s' (%s)", pipeline.name, pipeline.id)
            try:
                # System-triggered run bypasses the per-request membership check by using
                # the pipeline's own workspace/creator context rather than a live user session.
                run = service.run(
                    pipeline.id,
                    pipeline.workspace_id,
                    PipelineRunRequest(output_dataset_name=f"{pipeline.name}_output"),
                    user_id=_first_workspace_owner(db, pipeline.workspace_id),
                )
                executed += 1
                logger.info("Pipeline '%s' finished with status=%s", pipeline.name, run.status)
            except Exception:
                logger.exception("Scheduled run failed for pipeline %s", pipeline.id)
    finally:
        db.close()
    return executed


def _first_workspace_owner(db, workspace_id: str) -> str:
    """
    Scheduled runs have no HTTP request/session, so there's no 'current user'.
    We attribute the run to the workspace's earliest member for RBAC-check purposes.
    A dedicated system/service-account identity is the correct long-term fix, tracked
    as a hardening item rather than solved here.
    """
    from app.domain.workspaces.models import WorkspaceMembership

    membership = (
        db.query(WorkspaceMembership)
        .filter(WorkspaceMembership.workspace_id == workspace_id)
        .order_by(WorkspaceMembership.created_at.asc())
        .first()
    )
    if not membership:
        raise RuntimeError(f"Workspace {workspace_id} has no members; cannot attribute scheduled run")
    return membership.user_id


if __name__ == "__main__":
    count = run_due_pipelines()
    logger.info("Scheduler pass complete. %d pipeline(s) executed.", count)
