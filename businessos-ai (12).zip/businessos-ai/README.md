# BusinessOS AI — Phases 1-15 (Wedge, ETL, Copilot, Forecasting, Reports (PDF+Excel), ML Studio, Inventory, Connectors, Semantic Layer, RLS/CLS, RBAC, full RLS/CLS enforcement audit, ETL reshaping nodes, AutoML/Model Comparison)

This is the working slice of BusinessOS AI, built phase by phase. No placeholder code — every endpoint listed below is fully implemented. One package, one zip.

## Phase tracker

| Phase | Module | Status |
|---|---|---|
| 1 | Wedge: auth, orgs/workspaces, datasets, dashboards, alerts | ✅ |
| 2 | ETL Studio | ✅ |
| 3 | AI Copilot | ✅ |
| 4 | Forecasting + Reports | ✅ |
| 5 | ML Studio | ✅ |
| 6 | Inventory Management | ✅ |
| 6.5 | ETL join/append nodes | ✅ |
| 7 | Database Connectors (SQLite/PostgreSQL/MySQL) | ✅ |
| **8** | **Semantic Layer (reusable metrics & dimensions)** | ✅ |
| 8.5 | Semantic metrics wired into dashboard widgets | ✅ |
| 9 | Row-Level Security & Column-Level Security | ✅ |
| **10** | **Role-Level Security (RBAC enforcement across all endpoints)** | ✅ |
| 11 | RLS/CLS enforced on dashboard widgets and AI Copilot, not just secured-preview | ✅ |
| **12** | **Full audit + closure: Forecasting, ML training, ETL (source + join/append), and direct metric evaluation all now route through secured data** | ✅ |
| **13** | **ETL reshaping nodes: pivot, unpivot, normalize** + a permanent security-invariant regression test | ✅ |
| **14** | **AutoML / Model Comparison for ML Studio** — trains multiple algorithms per model type and picks the best, or lets you choose one specifically | ✅ |
| **15** | **Excel (XLSX) report export** — a second report format alongside PDF, sharing the same secured data-gathering path | ✅ (this update) |
| 16+ | Notebooks (sandboxed Python), OAuth-based SaaS connectors (Shopify, GA, etc.) | not started |

## What's actually here

- **Auth**: register/login/JWT (access + refresh), password hashing via bcrypt
- **Organizations & Workspaces**: multi-tenant hierarchy with role-based membership (Viewer/Editor/Admin/Owner)
- **Datasets**: CSV/XLSX upload → schema inference → loaded into a per-workspace **DuckDB** warehouse file
- **Database Connectors**: connect a SQLite, PostgreSQL, or MySQL database, test the connection, browse its schema, and sync any table into the warehouse as a dataset — reuses the exact same warehouse-loading path as file upload, so a connector and a CSV upload both just become "a dataset" to every downstream feature (ETL, dashboards, Copilot, ML, forecasting). Credentials are Fernet-encrypted at rest, never stored or logged in plaintext.
- **Semantic Layer**: define reusable, named business metrics ("Gross Profit" = `SUM(revenue) - SUM(cost)`) and dimensions once per dataset, evaluated safely — metric formulas are parsed into a restricted AST and walked by hand rather than ever calling Python's `eval()`, so only arithmetic over `SUM/AVG/COUNT/MIN/MAX(column)` calls is possible; anything else (attribute access, comprehensions, other function calls) is rejected before evaluation starts. Column existence is validated at metric-creation time, not first use. **Dashboard widgets can reference a semantic metric + dimension directly** instead of raw columns — the widget evaluates the metric expression once per dimension slice (e.g. Gross Profit by Region) via the same safe engine.
- **Row-Level Security & Column-Level Security**: define per-dataset filters ("region == 'West'") that apply to members at or below a chosen role, and per-column policies (hidden/masked/full) — both use the same safe-AST-parsing approach as the semantic layer engine (no `eval()`), and were both stress-tested against real adversarial expressions. A secured-preview endpoint shows any user exactly what they'd see under their own role's policies.
- **Role-Level Security (RBAC)**: every mutating action across the entire app is now gated by workspace role, enforced through one shared `WorkspaceService.require_role()` call rather than ad-hoc checks per domain. Policy:

  | Action type | Required role |
  |---|---|
  | Reads (list, get, preview, evaluate, predict) | Any member (Viewer+) |
  | Create/update content — datasets, ETL pipelines, dashboards/widgets, alerts, ML models, inventory records | Editor+ |
  | Delete content — ETL pipelines | Admin+ |
  | Connector credentials (create/delete) | Admin+ (higher bar — handles sensitive DB credentials) |
  | Connector sync (writes a new dataset) | Editor+ |
  | Semantic layer metrics/dimensions (create) | Editor+ |
  | Semantic layer metrics/dimensions (delete) | Admin+ |
  | RLS/CLS policy management (create/list/delete) | Admin+ across the board — controlling what other users can see is the most sensitive action in the app |

  Previously most endpoints only checked "is this person a member of the workspace at all" — a Viewer could create dashboards, train ML models, or even manage security policies. That gap is now closed.
- **ETL Studio**: visual pipeline builder — filter/select/rename/derive/aggregate/sort/dedupe/clean/join/append/**pivot/unpivot/normalize** nodes, cron-schedulable. Pivot and unpivot are verified inverses of each other (round-tripped real data through both and confirmed the values survive exactly); normalize supports minmax and z-score scaling with correct divide-by-zero handling for constant columns.
- **AI Copilot**: NL-to-SQL (defense-in-depth SQL safety validator), executive summaries, chart suggestions — provider-agnostic (OpenAI/Anthropic)
- **Forecasting**: linear-trend forecasting with confidence bands
- **ML Studio**: regression (linear / RandomForest / gradient boosting), classification (logistic / RandomForest / gradient boosting), and KMeans clustering — with real **AutoML / Model Comparison**: pick `algorithm="auto"` to train every candidate for the model type and automatically keep the best by its primary metric (R² for regression, accuracy for classification), with every candidate's full metrics returned for comparison, or specify one algorithm directly. Feature importance works for tree models (native) and linear/logistic models (coefficient magnitude, labeled as such since it's a different statistical concept). Real metrics, `/predict` endpoint.
- **Reports**: real PDF generation of any dashboard via reportlab, plus a real **Excel (XLSX) export** via openpyxl — a Summary sheet plus one sheet per widget, each with an actual Excel Table object (not just raw cells, so filtering/sorting works immediately) and correct handling of illegal/duplicate/over-length sheet names. Both formats share the exact same secured data-gathering step, so RLS/CLS applies identically to whichever format is requested.
- **Dashboards**: bar/line/pie/table/kpi widgets backed by real aggregate SQL
- **Alerts**: threshold-based, cron-evaluable
- **Inventory Management**: suppliers, warehouses, products, append-only stock ledger, purchase/sales orders, KPIs (stock levels, valuation, ABC analysis, reorder suggestions)
- **Frontend**: Next.js + TypeScript covering every module above, including a Connectors page (add connector → test connection → browse schema → sync a table into a dataset)

## What's intentionally NOT here yet

Notebooks (sandboxed Python execution — deliberately deferred; building a genuinely safe arbitrary-code sandbox is a significant security engineering task on its own) and OAuth-based SaaS connectors (Shopify, Google Analytics, Meta Ads — these need real OAuth app registrations, not something buildable/testable in a sandbox) are next.

**Full audit performed this round**: rather than trusting that Forecasting and ML Studio were the only gaps, I grepped every domain service for every unfiltered-warehouse-read function (`load_full_table`, `preview_table`, `get_metric_value`, `run_aggregate_query`, `run_readonly_sql`), not just the one I'd already found once. That search turned up **six bypasses, not two**:
- **Forecasting** and **ML Studio training** — now use `get_secured_dataframe`; ML training also explicitly rejects hidden feature/target columns
- **ETL pipelines** — both the source-dataset node *and* the join/append node's second-dataset loader now go through security filtering, closing a real laundering path (a restricted user could otherwise join in an unrestricted dataset and write the combined result out as a new dataset they could then read freely)
- **Semantic layer's direct `/metrics/{id}/evaluate` endpoint** — now checks referenced columns against hidden-column policies
- **The most severe one: `DatasetService.preview()`** — this was a **direct, trivial bypass around the entire RLS/CLS system**. The dedicated secured-preview endpoint could apply every policy correctly, and any Viewer could simply ignore it and call the ordinary dataset preview endpoint instead to see completely unfiltered data. Now both routes share the same secured primitive.
- **Alert evaluation** — the interactive `evaluate()` endpoint's `current_value` is now computed on the caller's security-filtered view (the scheduled background worker intentionally still evaluates against raw data, since it's checking a threshold the alert's Editor+ creator already configured — a different trust context than an arbitrary member's on-demand check)

After this pass, grepping for every one of those five unfiltered-read function names across every domain service returns exactly one match in the whole codebase: inside `SecurityService` itself, which is where the single unfiltered read is supposed to happen, centrally, before anything else touches the result.

This invariant is now enforced by a **permanent regression test**, not just a one-time manual grep: `backend/tests/test_security_invariants.py` statically scans every `app/domain/*/service.py` file for calls to any of the five unfiltered-read functions and fails if anything outside `security/service.py` calls one. It needs no database or app dependencies to run, so it stays cheap to keep in CI forever. I verified it both ways before trusting it — confirmed it passes cleanly against the current codebase, then injected a fake violation into a real file, confirmed the test caught it and named the exact file and function, then restored the file and confirmed a clean pass again (with a `grep -c` check afterward to make sure nothing was left behind).

**Previously flagged gap, now closed**: RLS/CLS was originally enforced only through the secured-preview endpoint. It's now enforced everywhere data reaches a user on their own behalf:
- **Dashboard widgets**: `DashboardService.get_widget_data` routes through the same `SecurityService.get_secured_dataframe` primitive as secured-preview. Aggregation was rewritten from a raw SQL `GROUP BY` into a pandas function (`app/domain/dashboards/aggregation.py`) specifically so row filtering can happen *before* aggregation — filtering an already-aggregated SUM after the fact would still leak the excluded rows' contribution to the total.
- **AI Copilot**: `ask()`, `summarize()`, and `suggest_chart()` all build their prompts from the security-filtered DataFrame's actual columns (a hidden column is never even mentioned to the model, so it can't be requested), and `ask()`'s generated SQL executes against an in-memory DuckDB instance holding only the filtered/masked data (`duckdb_client.run_sql_on_dataframe`) — the persisted warehouse file is never opened for that query, so there's no path for the generated SQL to reach unfiltered data.

## Honesty note on verification

This sandbox has no network access, so I could not `pip install` / `npm install` and boot the actual servers end-to-end. numpy, reportlab, scikit-learn, joblib, pandas, and **cryptography** all happened to already be available in this sandbox — but **SQLAlchemy itself is not installed here**, which is worth being precise about:

- **Credential encryption** (`app/domain/connectors/crypto.py`): actually tested with real Fernet encryption — encrypted a fake connection string, confirmed the plaintext password/host don't appear anywhere in the ciphertext, decrypted it back and confirmed an exact match, and confirmed a tampered ciphertext is correctly rejected rather than silently returning garbage. (The only thing stubbed was the `pydantic_settings`-based config import, which isn't installed here either — the encryption logic itself is 100% real.)
- **Semantic layer metric engine** (`app/domain/semantic/engine.py`): this one got the most adversarial testing of anything in the project so far, because it's the riskiest piece — user-supplied formula strings parsed via Python's `ast` module rather than `eval()`. Tested 4 valid expressions (confirmed exact arithmetic results by hand) and **12 adversarial expressions** designed to try to break out of the sandbox: `__import__('os').system(...)`, attribute access (`.__class__`), `exec()`, list comprehensions, `lambda`, conditional expressions, `open('/etc/passwd')`, `globals()`, wrong argument counts, disallowed operators (`**`), and passing a string literal instead of a column name. **Every single one was correctly rejected**, plus missing-column and division-by-zero were also correctly caught. Then extended with grouped evaluation (a metric computed separately per dimension slice, which is what a dashboard widget actually needs) and re-verified against hand-calculated per-group values, including a tie-sorting case and an empty-DataFrame edge case.
- **RLS/CLS policy engine** (`app/domain/security/engine.py`): same AST-based safety approach, same adversarial rigor. Tested 5 valid row filters (equality, comparison, AND-combination, `in`, `not`) against hand-verified row counts, plus **10 adversarial expressions**: attribute-method calls (`.upper()`), list comprehensions, `exec`, `lambda`, chained comparisons, arithmetic on the left side of a comparison, a bare literal comparison, `open()`, and a call as the right-hand side — **all 10 correctly rejected**. Column-level policies (hidden/masked/full) were tested separately, including the case where a policy references a column absent from a given result set (correctly skipped rather than erroring) and an invalid access_type (correctly rejected).
- **RBAC (`WorkspaceService.require_role`)**: the `Role` IntEnum ordering that every permission check depends on was verified directly (`VIEWER(0) < EDITOR(1) < ADMIN(2) < OWNER(3)`, and every boundary case — a Viewer denied Editor-level actions, an Admin granted Editor-level actions, an Owner granted everything). The `require_role` method itself is a thin wrapper around SQLAlchemy queries, so — like every other DB-touching service method in this project — it's syntax-checked only, not executed end-to-end; what's real-tested is the comparison logic it relies on. I re-ran all ten prior real-logic test suites after applying RBAC across 10 service files to confirm the authorization changes didn't touch any business logic — they didn't; all ten still pass.
- **Secured widget aggregation** (`app/domain/dashboards/aggregation.py`): tested SUM/AVG/COUNT against hand-calculated values, a masked-metric-column case (correctly detected and rejected rather than silently aggregating the string `"***"`), a missing-column case, an unsupported-aggregate case, and — notably — a masked-*dimension*-column case, confirming all rows correctly collapse into a single `"***"` bucket rather than erroring (masking a grouping column should merge indistinguishable groups, not break the query). Then, separately, **I tested the actual end-to-end security property this work exists for**: built a dataset where the excluded region's revenue was 7x larger than the permitted region's, ran it through RLS-filter-then-aggregate exactly as the real code path does, and confirmed the restricted total was exactly the permitted rows' sum with zero contribution from the excluded rows — not just "some filtering happened," but confirmed no numeric leakage through the aggregate. Alert evaluation reuses this same function via a constant-dimension trick (grouping by a column of all-1s to collapse the whole filtered DataFrame into one scalar) — I verified that trick works correctly before trusting it, since I improvised it on the spot rather than pulling it from an existing tested path.
- **Connector engine** (`app/domain/connectors/engine.py`): this file imports SQLAlchemy at module level, so it could not be imported or executed at all in this sandbox — not even the connection-string builder. I separately re-implemented and tested just that one pure function's logic (dialect validation, default ports, sqlite path handling, missing-credential rejection) as a standalone snippet to at least verify that piece's correctness — **this is not the same as testing the actual file**, and I want to be direct about that distinction rather than blur it.
- **ETL reshaping nodes** (pivot/unpivot/normalize): pivot tested against hand-calculated values for a region×month revenue table; unpivot tested as pivot's inverse, then round-tripped (pivot → unpivot) and confirmed every value matched the original long-format data exactly; normalize tested for both minmax (0/50/100 → exactly 0.0/0.5/1.0) and z-score (confirmed mean≈0, std≈1 on real data) methods, plus the constant-column edge case (a column with zero variance correctly returns all zeros instead of dividing by zero). Four error cases — missing required config keys for pivot and unpivot, an invalid normalize method, and a nonexistent pivot index column — all correctly rejected.
- **AutoML / Model Comparison**: trained all three regression candidates (linear/RandomForest/gradient boosting) on a clean linear signal and confirmed AutoML correctly picked linear regression as the winner (R²=0.9994, beating both tree ensembles) — and confirmed its learned coefficient (≈3.0) matched the true underlying relationship (`y = 3·x1 + noise`) almost exactly, which is about as strong a sanity check as this kind of test can give. Did the same for classification on a linearly-separable signal (logistic regression correctly won with perfect accuracy over both tree ensembles at ~92-97%). Verified single-algorithm mode is unchanged and fully backward compatible (`algorithm="random_forest"` still the default, still returns an empty `candidates` list). Verified coefficient-based feature importance is populated correctly for both linear and logistic models. Invalid algorithm name correctly rejected.
- **XLSX report builder** (`app/domain/reports/xlsx_builder.py`): generated a real workbook, then parsed it back with openpyxl and confirmed the summary sheet title, the executive summary text, and every single data cell across all three test rows matched the source data exactly — plus confirmed a real Excel `Table` object was created (not just raw cells) with the correct cell range, and an empty widget correctly shows "No data." instead of an empty table. Sheet-name sanitization was tested separately: illegal characters (`[]:*?/\`) replaced correctly, names over Excel's 31-character limit truncated correctly, and duplicate sheet names deduped correctly. One real bug caught in the process: my first test had a hand-typed expected string for the sanitized-characters case that was simply wrong (miscounted underscores) — I didn't assume the code was right when the assertion failed, I printed the actual output, confirmed the *code's* behavior was correct and consistent (one `_` per illegal character), and fixed my test's expected value instead of quietly loosening the assertion.
- **Inventory KPI engine, ML engine, forecasting engine, PDF builder, ETL node engine (including join/append), SQL safety validator**: all re-verified again on this build, still passing.
- All 87 backend Python files pass `python3 -m py_compile`.
- Frontend TypeScript was hand-reviewed (full `tsc` check needs `node_modules`, which needs network).

**What I still could not verify here**: the actual DuckDB read/write cycle, the live HTTP request/response cycle end-to-end, real database connections of any kind (SQLite/Postgres/MySQL), real calls to OpenAI/Anthropic, and React rendering in a browser. The connectors module in particular has had less real-execution scrutiny than everything else in this project so far — **test it locally against a real database before relying on it**, and tell me what breaks.

## Quick Start (Docker — recommended)

```bash
docker compose up --build
```
- Backend: http://localhost:8000 (docs at `/docs`)
- Frontend: http://localhost:3000

## Quick Start (without Docker)

**Backend:**
```bash
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # sqlite by default, no Postgres needed for local dev
uvicorn app.main:app --reload
```

**Frontend:**
```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

**Alert evaluation (run manually or via cron):**
```bash
cd backend
python -m app.workers.alert_evaluator
```

**ETL pipeline scheduler (run manually or via cron, e.g. every 5 min):**
```bash
cd backend
python -m app.workers.pipeline_scheduler
```

**Security invariant test (no database needed — run this after any change touching a domain service):**
```bash
cd backend
python -m tests.test_security_invariants
```

## Enabling AI Copilot (optional)

Copilot endpoints return HTTP 503 with a clear message until configured. To enable:
```bash
# in backend/.env
AI_PROVIDER=openai        # or "anthropic"
AI_MODEL=gpt-4o-mini      # or e.g. claude-3-5-haiku-latest
OPENAI_API_KEY=sk-...     # or ANTHROPIC_API_KEY=...
```

## Try the full loop

1. Sign up at http://localhost:3000/signup
2. Create an Organization, then a Workspace
3. Upload a CSV (include a date column and a numeric column for forecasting to work), **or** go to **Connectors** → add a SQLite/PostgreSQL/MySQL connector → test the connection → browse its schema → sync a table into a dataset
4. Go to **ETL Studio** → new pipeline → the `source` node is pre-added; add a `filter`, `derive`, or `aggregate` node, edit its config JSON, click **Run pipeline** → watch the run log show rows in/out per node, and a new dataset appear
5. (If Copilot is configured) go to **AI Copilot** → ask a question in plain English, generate an executive summary, or get a chart suggestion
6. Go to **Forecasting** → pick the dataset, enter your date and metric column names, run a forecast → see history + projected trend on one chart
7. Go to **ML Studio** → pick a dataset, name a model, choose regression/classification/clustering, list feature columns and (for regression/classification) a target column → train → see real metrics and feature importance → for regression/classification, try **Predict** with a JSON row
8. Go to **Dashboards** → create a Dashboard, add a widget (pick the numeric column as metric, text column as dimension) → click **Download PDF report** or **Download Excel report** to get a real file — Excel opens with a Summary sheet and one filterable/sortable table per widget
9. Watch the bar chart render from a real DuckDB aggregate query
10. Go to **Inventory** → add a supplier, a warehouse, and a product → create a purchase order and **Receive** it (posts stock in) → create a sales order and **Fulfill** it (posts stock out) → check the **KPIs** tab for inventory value, ABC analysis, and reorder suggestions
11. Go to **Semantic Layer** → pick a dataset → define a metric like `SUM(revenue) - SUM(cost)` named "Gross Profit" → click **Evaluate** to see the real computed value → optionally define a dimension too
12. Go to **Security** → add a row-level policy (e.g. `region == 'West'`, applies to Viewer) or a column-level policy (mask a sensitive column for Viewers) → use **Preview as yourself** to see what your own role currently sees

## Project layout

```
backend/app/
  core/           config, security (JWT/bcrypt), FastAPI dependencies
  infrastructure/ Postgres session (system of record), DuckDB client (per-workspace warehouse), AI Gateway
  domain/         one folder per bounded context — models.py, schemas.py, service.py, router.py
    connectors/   crypto.py (Fernet credential encryption) + engine.py (generic SQLAlchemy schema discovery/extraction) + sync-into-warehouse wiring
    semantic/     engine.py (AST-based safe metric expression parser/evaluator, unit-testable without DB/HTTP) + metric/dimension CRUD
    security/     engine.py (AST-based safe RLS filter + CLS column policy engine, unit-testable without DB/HTTP) + service.py's get_secured_dataframe (the shared primitive dashboards/Copilot both use) + policy CRUD + secured-preview
    dashboards/   aggregation.py (pure pandas aggregation, unit-testable without DB/HTTP — lets widgets aggregate already-security-filtered data) + widget/dashboard CRUD
    etl/          nodes.py (pure transformation functions incl. join/append, unit-testable without DB/HTTP) + pipeline orchestration
    copilot/      sql_safety.py (validates all AI-generated SQL before execution) + NL-to-SQL/summary/chart service
    forecasting/  engine.py (pure numpy trend-fitting, unit-testable without DB/HTTP) + dataset wiring
    ml/           engine.py (pure scikit-learn training, unit-testable without DB/HTTP) + persistence/prediction wiring
    reports/      pdf_builder.py (pure reportlab PDF generation, unit-testable without DB/HTTP) + dashboard wiring
    inventory/    engine.py (pure pandas KPI math, unit-testable without DB/HTTP) + CRUD/order-fulfillment wiring
  workers/        scheduled jobs (alert evaluation, pipeline scheduling)
backend/tests/    test_security_invariants.py — static-analysis regression test with no DB/app dependencies
frontend/
  app/            Next.js App Router pages (auth + dashboards + Connectors + Semantic Layer + Security + ETL Studio + AI Copilot + Forecasting + ML Studio + Inventory)
  components/     AppNav, WidgetChart (ECharts wrapper)
  lib/            typed API client, zustand store
```

## Next step

Tell me which slice to build next (Notebooks, OAuth-based SaaS connectors, PPTX/Excel report formats, forecasting/ML training on security-filtered data too), or report anything that breaks when you run this — I'll fix it before moving forward.
